# CMDGLAS OVERLAY - OPERATOR CARD
**TM-CMDGLAS-OVL-2 - 6 AUG 2026**

The CmdGlas tablet as a see-through window on top of Star Citizen. No browser
frame, no address bar, and the mouse passes straight through it to the game.

---

## 0. FASTEST WAY IN - NO DOWNLOAD

You do not need this package to use CmdGlas.

1. Open **https://cmdglas.com** in Chrome.

2. That is the full tablet.

3. On an iPad, open the same address in Safari, then **Share -> Add to Home
   Screen**. Opening it from that icon removes Safari's address bar.

**Use this download only if you want the tablet floating OVER the game.**

---

## 1. WHAT THIS IS, AND WHAT IT IS NOT

**IS**

1. A window with no browser around it.

2. Transparent, so the game shows through.

3. Always on top, including over a borderless-fullscreen game.

4. Click-through on demand - the mouse goes to the game, not the overlay.

**IS NOT**

1. It does not read the game's memory.

2. It does not send keystrokes or mouse input to the game.

3. It does not hook, inject into, or attach to the game process.

**No danger.** It is a window that draws itself on top. Nothing about it touches
Star Citizen.

**NOTE.** It holds no copy of the tablet. It loads cmdglas.com live, so you are
always on the current build with nothing to update.

---

## 2. MATERIAL REQUIRED

1. Windows PC

2. Node.js - https://nodejs.org (the LTS button; default options are fine)

3. About 100 MB of free disk for Electron

---

## 3. INSTALL - ONCE

1. Unzip **CmdGlas-Overlay.zip** anywhere you like. Your Desktop is fine.

2. Open the unzipped **CmdGlas-Overlay** folder.

3. Double-click **0 - FIRST TIME SETUP.bat**.

4. Wait for it to finish, then press any key to close.

**CAUTION.** If it says npm was not found, Node.js is not installed yet. Install
it from the link above and run the setup again. Nothing else on the PC is
changed either way.

---

## 4. START IT - EVERY TIME

1. Double-click **1 - RUN OVERLAY.bat**.

2. The tablet appears with no frame and no address bar.

3. Start Star Citizen.

**CAUTION - SET THE GAME TO BORDERLESS WINDOWED.**

1. In Star Citizen, open **Settings**.

2. Select **Graphics**.

3. Set **Display Mode** to **Borderless Windowed**.

Exclusive fullscreen hides every other window on Windows, including this one.
That is a Windows rule, not a setting in this app.

---

## 5. HOTKEYS

| Keys | What it does |
|---|---|
| **Ctrl + Shift + F12** | Click-through on / off |
| **Ctrl + Shift + Num 0** | Hide / show the overlay |
| **Ctrl + Shift + PageDown** | Reload the tablet |
| **Ctrl + Shift + `** | Cycle see-through level |
| **Ctrl + Shift + Num 8** | Fully solid |
| **Ctrl + Shift + Num -** | 75% |
| **Ctrl + Shift + Num \*** | 50% |
| **Ctrl + Shift + Num /** | 25% |
| **Ctrl + Alt + Shift + H** | HUD only / whole tablet |
| **Ctrl + Alt + Shift + K** | Settings window |

**Click-through ON** - the mouse goes to the game. You can see the tablet, not
touch it. This is how it starts.

**Click-through OFF** - you can use the tablet. The game stops receiving those
clicks.

---

## 6. MOVE AND RESIZE IT

1. Press **Ctrl + Shift + F12** so click-through is off.

2. Drag the window edges to resize.

3. To move it, drag any empty part of the tablet background.

4. It remembers where you put it.

---

## 7. SETTINGS

Press **Ctrl + Alt + Shift + K**, or edit **overlay.config.json** beside the
.bat files.

| Setting | Meaning |
|---|---|
| `url` | which page the overlay loads - leave it on cmdglas.com |
| `dimLevel` | 100 is solid, 25 is very see-through |
| `clickThroughOnStart` | true starts out of the game's way |
| `hotkeys` | change any of the keys above |

**NOTE.** Restart the overlay after editing the file by hand.

---

## 8. IF IT DOES NOT APPEAR

1. Check the taskbar - it is not hidden from it.

2. Press **Ctrl + Shift + Num 0** twice.

3. Confirm the game is in Borderless Windowed.

4. Confirm cmdglas.com opens in a normal browser.

**NOTE.** If a hotkey does nothing, another program already owns that
combination. The console window prints `HOTKEY NOT AVAILABLE` and names it.
Change it in `overlay.config.json`.

---

## 9. WHAT IS NOT BUILT YET

1. **No installer.** It runs from this folder with Node.js present. Packaging it
   into a signed `.exe` is a separate job - without code signing every user gets
   a SmartScreen warning, which is worse than no installer.

2. **No auto-update for the shell itself.** The tablet inside it updates on its
   own; this wrapper does not. Re-download the zip when a new one is announced.

---

*CmdGlas is an unofficial Star Citizen companion and is not affiliated with
Cloud Imperium Games.*
