# CMDGLAS TRANSPARENT HUD — INSTALLATION AND OPERATOR CARD
**TM-CMDGLAS-OVL-2 · 4 AUG 2026 · overlay v1.2.16**

A transparent, always-on-top window that runs the CmdGlas tablet with no browser
around it. No address bar, no title bar, and the mouse can pass straight through
it to the game.

---

## 0. WHAT IT IS, AND WHAT IT IS NOT

**IS**

1. A window with no browser frame around it.

2. Transparent, so the game shows through.

3. Always on top, including over a borderless-windowed game.

4. Click-through on demand — the mouse goes to the game, not the overlay.

**IS NOT**

1. It does not read the game's memory.

2. It does not send keystrokes or mouse input to the game.

3. It does not hook, inject into, or attach to the game process.

**No danger.** It is a window that draws itself on top. Nothing about it touches
Star Citizen, and nothing about it is anti-cheat relevant.

**NOTE.** It holds no copy of the tablet. It loads cmdglas.com, so you are always
on the current build.

---

## 1. MATERIAL REQUIRED

1. Windows PC.

2. Node.js — https://nodejs.org — installed once.

3. About 100 MB of free disk for Electron.

4. Star Citizen set to **Borderless Windowed** (§7).

**NOTE.** No control server, no account and no install beyond this folder are
required. If you run your own CmdGlas control server you can point the overlay at
it with the `url` setting in §8.

---

## 2. INSTALL — RUN ONCE

1. [PC – browser] Download **CmdGlas-Overlay.zip** from
   **cmdglas.com/CmdGlas-Overlay.zip**

2. [PC – File Explorer] Right-click the zip, select **Extract All**, and put the
   folder somewhere permanent — your Desktop is fine.

3. [PC – File Explorer] Open the extracted **CmdGlas-Overlay** folder.

4. [PC – File Explorer] Double-click **0 - FIRST TIME SETUP.bat**.

5. [PC – setup window] Wait. It downloads Electron into this folder only, about a
   minute on a normal line.

6. [PC – setup window] Press any key to close it.

**CAUTION.** If it says npm was not found, install Node.js first and run it again.
Nothing else on the PC is changed either way.

**NOTE.** Windows may warn about a downloaded zip. Extract it and the .bat files
run normally. Nothing here is code-signed — see §10.

---

## 3. START IT

1. [PC – File Explorer] Double-click **1 - RUN OVERLAY.bat** for the whole tablet.

2. [PC – File Explorer] Double-click **2 - RUN HUD ONLY.bat** to go straight to
   the floating HUD.

3. [PC – overlay window] The tablet appears with no frame and no address bar.

**NOTE.** The window starts INTERACTIVE — your mouse works on it. Click-through is
something you turn on for flight, in §4.

---

## 4. CLICK-THROUGH

**Ctrl + Shift + F12** turns it on and off.

**Click-through ON** — an amber bar reads `CLICK-THROUGH ON · MOUSE GOES TO GAME ·
CTRL+SHIFT+F12` across the top of the window. The mouse goes to the game. You can
see the tablet, not touch it.

**Click-through OFF** — no amber bar. The tablet takes the mouse and the game does
not receive those clicks.

**CAUTION.** If the buttons appear dead, look for the amber bar. That bar means
Windows is not delivering your mouse to this window at all, by design.

---

## 5. HOTKEYS

| Keys | What it does |
|---|---|
| **Ctrl + Shift + F12** | Click-through on / off |
| **Ctrl + Alt + Shift + V** | Hide / show the window |
| **Ctrl + Alt + Shift + H** | Swap between the whole tablet and the HUD |
| **Ctrl + Shift + PageDown** | Reload the tablet |
| **Ctrl + Shift + `** | Cycle brightness 25 / 50 / 75 / 100 |
| **Ctrl + Shift + Num /** | Brightness 25% |
| **Ctrl + Shift + Num \*** | Brightness 50% |
| **Ctrl + Shift + Num -** | Brightness 75% |
| **Ctrl + Shift + Num 8** | Brightness 100% |
| **Ctrl + Alt + Shift + K** | Open the hotkey editor |

**NOTE.** Every combination is checked at startup against Windows, and against
your own Star Citizen keybind export if the overlay can find one. If a key is
already taken the overlay says so on screen and names it. Change it with
**Ctrl + Alt + Shift + K** or in `overlay.config.json` (§8).

---

## 6. THE WINDOW STRIP, AND HOW TO SHUT IT DOWN

The strip across the top of the window is dim on purpose so it does not compete
with the tablet's own row. **Move the mouse over it and it lights up.**

**Whole tablet:** DRAG TO MOVE · MAX · FIT · HOTKEYS · ✕ CLOSE

**HUD:** DRAG TO MOVE · DOCK TABLET · MAX · FIT · HOTKEYS

To shut down from the HUD:

1. [PC – overlay strip] Move the mouse over the top strip.

2. [PC – overlay strip] Click **DOCK TABLET**.

3. [PC – overlay strip] Click **✕ CLOSE**.

**NOTE.** There is no ✕ CLOSE in the HUD on purpose. Dock first, close second.

**NOTE.** To undock, use the tablet's own **UNDOCK** button in the bottom control
row. That is the only undock control there is.

**MOVE AND RESIZE.** Drag the strip to move the window. Drag any of the four
corner grips to resize. Both only work while click-through is OFF. The window
remembers where you put it, and the HUD and the whole tablet each remember their
own size.

---

## 7. CAUTION — SET THE GAME TO BORDERLESS WINDOWED

1. [PC – Star Citizen] Open **Settings**.

2. [PC – Star Citizen] Select **Graphics**.

3. [PC – Star Citizen] Set **Display Mode** to **Borderless Windowed**.

**Exclusive fullscreen hides every other window on Windows, including this one.**
That is a Windows rule, not a setting in this app.

---

## 8. SETTINGS FILE

Edit **overlay.config.json** beside the .bat files. Restart the overlay after
editing it.

| Setting | Meaning |
|---|---|
| `url` | which page the overlay loads. Absent means cmdglas.com |
| `fallbackUrl` | used if `url` cannot be reached |
| `clickThroughOnStart` | `false` starts interactive. `true` starts with the mouse going to the game |
| `dimTarget` | `window`, `content` or `hud` — what the brightness keys act on |
| `dimLevel` | 25, 50, 75 or 100 |
| `showDragBar` | `false` removes the top strip entirely |
| `shrinkOnCompact` | the window shrinks to fit when the tablet collapses its rows |
| `hotkeys` | every combination in §5 |

---

## 9. IF IT DOES NOT APPEAR

1. [PC – taskbar] Check the taskbar. The window is not hidden from it.

2. [PC – keyboard] Press **Ctrl + Alt + Shift + V** twice.

3. [PC – Star Citizen] Confirm the game is in Borderless Windowed.

4. [PC – overlay window] If it opens black, press **Ctrl + Shift + PageDown** to
   reload.

**NOTE.** If a hotkey does nothing, another program already owns that combination.
The console window prints `HOTKEY NOT AVAILABLE` and names it.

---

## 10. WHAT IS NOT BUILT YET

1. **No installer.** It runs from this folder with Node.js present. Packaging it
   into a signed `.exe` is a separate job — without code signing every user gets a
   SmartScreen warning, which is worse than no installer.

2. **No auto-update for the shell.** The tablet inside it is always current
   because it is loaded from the website; this wrapper is not. Re-download the zip
   when a new one is announced.

3. **No editing of your game binds.** The overlay reads your Star Citizen export
   to warn about conflicts. It will never write to it.

---

## 11. FEEDBACK

Use it, then say what broke. COMMS pill on the tablet, or wherever you found this.
A screenshot of anything that looks wrong is worth more than a description.
