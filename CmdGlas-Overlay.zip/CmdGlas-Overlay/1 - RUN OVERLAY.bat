@echo off
REM ===========================================================================
REM  CmdGlas Overlay  -  normal launcher (the LIVE tablet)
REM  Loads whatever "url" is set in overlay.config.json.
REM ===========================================================================
cd /d "%~dp0"
if not exist "node_modules\electron\dist\electron.exe" (
  echo.
  echo   Electron is not installed yet.
  echo   Run "0 - FIRST TIME SETUP.bat" once, then try again.
  echo.
  pause
  exit /b 1
)
echo Starting CmdGlas Overlay ...
start "" "node_modules\electron\dist\electron.exe" .
exit /b 0
