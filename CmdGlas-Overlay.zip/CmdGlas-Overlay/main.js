// =============================================================================
//  CmdGlas Overlay  -  transparent, always-on-top shell for the command tablet
//  v1.2  -  3 AUG 2026
//
//  WHAT CHANGED IN 1.2, all of it from T using the thing:
//    1. "i cant move it"
//         -> a drag strip across the top, shown only when it can be used.
//            (This existed in the 1.1 source but was NEVER INSTALLED - his PC was
//             still running 1.0, 7014 bytes, which is why the strip never came.)
//    2. "when detached i need to be able to increase the size of the hud to
//        fullscreen by dragging"
//         -> four corner grips that resize the window, plus a MAX button.
//            A TRANSPARENT window has no grabbable edge - Windows hit-testing
//            passes straight through the clear pixels - so the grips are drawn in
//            the page and drive setBounds directly. That is the only way.
//    3. "let the user hide everything underneath the assist nav my rig row. once
//        hidden close the tablet in around the new size"
//         -> the window now shrinks to fit when the tablet reports COMPACT, and
//            goes back to the size it was when it reports FULL.
//    4. "some people have your hotkeys as inflight keybinds" /
//       "make the hotkeys customizable during setup"
//         -> a hotkey editor with a live conflict check against the pilot's own
//            Star Citizen export. Press a combination and it tells you, before
//            you keep it, whether the game already uses it.
//
//  A BUG THIS VERSION FIXES, FOUND BY CHECKING RATHER THAN BY IT BREAKING.
//  T's config had  dim100: "Control+Shift+numenter".  There is no "numenter" in
//  Electron's accelerator vocabulary, so that hotkey registered as nothing and
//  failed silently - the only sign was a line in a console nobody sees. 1.2
//  validates every combo at startup and puts the result ON SCREEN.
//
//  WHAT IT STILL DOES NOT DO: read game memory, send input, hook the game, or
//  touch anything anti-cheat cares about. It is a window that draws on top.
//
//  v1.2.14  -  4 AUG 2026.  T: "when i selected the buttons inside your hud
//  nothing happened."  THE BUTTONS WERE NEVER DEAD. clickThroughOnStart was true
//  and a HUD-only launch therefore called setIgnoreMouseEvents(true) at startup,
//  so Windows never delivered his mouse to the window at all. The only tell was a
//  toast that had already faded after six seconds.
//    (a) A PERSISTENT amber badge (#cg-ovl-ctbadge) is shown for as long as
//        click-through is on, and it names the key that turns it off.
//    (b) The badge is whitelisted in the HUD-only sweep's skip() - the sweep
//        inline-hides every unknown top-level node, which would have hidden the
//        one element whose whole job is to be visible (RULE 18 family).
//    (c) clickThroughOnStart now defaults to FALSE. The HUD starts interactive;
//        click-through is a thing you turn ON for flight, not a thing you have to
//        discover is already on.
//  v1.2.15  -  4 AUG 2026.  T: "remove the cmdglas overlay title from the top
//  left. there is no visual seperation between drag to move whole tablet and the
//  gather and buy and notes."
//    (a) The "CMDGLAS OVERLAY" title is gone from the drag strip.
//    (b) The strip is the WINDOW's row, not the tablet's, and it now looks like
//        it: at rest only the shadow of its words shows and its cloud drops to
//        ~1/5 weight, so the tablet's own tab row is the only lit thing up there.
//        Hovering anywhere on the strip brings the whole row up at once.
//  v1.2.16  -  4 AUG 2026.  T: "why is there a hud only button on the tablet
//  that doesn't work when the tablet is open ... too many controls as it stands
//  now."  Three controls read as undock in whole-tablet mode; two of them were.
//    (a) The strip's HUD ONLY button is not rendered while the tablet is docked.
//        The tablet's own UNDOCK (bottom row) is the only undock control.
//    (b) In HUD-only that same strip button returns, labelled DOCK TABLET - the
//        one action the HUD cannot otherwise reach. Ctrl+Alt+Shift+H does it too.
//    (c) The "HUD" caret is relabelled OPTS in whole-tablet mode. It was
//        never an undock control: the tablet's own title attribute on it reads
//        "HUD settings - transparency, brightness, colour".
//  VERIFY LESSON, PAID FOR: CDP/synthetic clicks BYPASS setIgnoreMouseEvents.
//  A sweep of synthetic clicks reported every control firing while T's real mouse
//  did nothing. Click-through behaviour is NEVER verified from synthetic clicks.
// =============================================================================
'use strict';
const { app, BrowserWindow, globalShortcut, screen, ipcMain, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const KM = require('./keymap.js');
/* ===== CG767_ERRLOG - THE OVERLAY FINALLY HAS AN ERROR LOG =============
   Register G #18: "the overlay has no error log at all ... every ghost
   chased this session was chased without one." The CLEAR-button crash
   (CHEV50) was never named for exactly this reason. Everything fatal now
   lands in overlay_error.log beside this file, appended, never rotated by
   code - T can delete the file whenever he likes. */
const CG_ERRLOG = path.join(__dirname, 'overlay_error.log');
function cgLogErr(tag, info){
  try{ fs.appendFileSync(CG_ERRLOG, new Date().toISOString()+' ['+tag+'] '+String(info).slice(0,4000)+'\n'); }catch(_e){}
}
process.on('uncaughtException', function(e){ cgLogErr('main-uncaught', (e&&e.stack)||e); });
process.on('unhandledRejection', function(e){ cgLogErr('main-rejection', (e&&e.stack)||e); });

const CONFIG_FILE = path.join(__dirname, 'overlay.config.json');
// The keybind export lives with the control server, one level up from this folder.
// Both spellings are tried because the Tools copy is the one the sync writes.
const SC_BIND_CANDIDATES = [
  path.join(__dirname, '..', 'MASTER_KEYBINDS.json'),
  path.join(__dirname, '..', 'Tools', 'MASTER_KEYBINDS.json'),
  path.join(__dirname, 'MASTER_KEYBINDS.json')
];

const DEFAULTS = {
  /* PUBLIC BY DEFAULT. A fresh install needs no control server, no Node, no local
     files - it loads the published tablet. T's own config points at his localhost
     because he runs the server and it carries the newest build; that is a CHOICE in
     his config file, not a requirement of the app. */
  url: 'https://cmdglas.com/',
  fallbackUrl: 'https://cmdglas.com/',
  hudOnly: false,
  dimTarget: 'window',            // window | content | hud
  dimLevel: 100,                  // 25 | 50 | 75 | 100
  /* v1.2.14: was true. A HUD-only launch then began with the mouse passing
     straight through to the game, which reads exactly like dead buttons.
     Start interactive; Ctrl+Shift+F12 turns click-through on for flight. */
  clickThroughOnStart: false,
  showDragBar: true,
  shrinkOnCompact: true,          // follow the tablet's COMPACT switch
  minWidth: 320,
  minHeight: 200,
  /* v1.2.15, 9 AUG 2026 (T, on an iPad running Duet Display: "everything is tiny...
     the whole tablet has the need to squint").
     MEASURED: through Duet the iPad is an EXTENDED MONITOR of the PC, so this is the
     PC build - not one pointer:coarse rule in the tablet applies - and the tablet's
     own fitter then scales itself down to the window on top of that. Two shrinks
     stacked. Electron gives a zoom away for free and 87 KB of this file had never
     used it: setZoomFactor / zoomFactor / zoomLevel appeared ZERO times.
     This scales the WHOLE overlay window, the fitter's output included, and only
     this window - the tablet on the main monitor is untouched. */
  zoomFactor: 1.0,                // 0.5 to 3.0, saved on every change
  hotkeys: {
    toggleClickThrough: 'Control+Alt+2',
    toggleVisible:      'Control+Alt+3',
    reload:             'Control+Alt+4',
    dimCycle:           'Control+Alt+5',
    settings:           'Control+Alt+6',
    dim25:              'Control+Alt+7',
    dim50:              'Control+Alt+8',
    dim75:              'Control+Alt+9',
    dim100:             'Control+Alt+0',
    toggleHudOnly:      'Control+Alt+Shift+H',
    toggleCorners:      '',
    zoomIn:             'Control+Alt+Shift+=',
    zoomOut:            'Control+Alt+Shift+-',
    zoomReset:          'Control+Alt+Shift+0'
  }
};
// Plain English for the editor. The key order here is the row order on screen.
const ACTION_LABELS = {
  toggleClickThrough: ['Click through on / off', 'When ON the mouse passes through to the game. Turn it OFF to use the tablet.'],
  toggleVisible:      ['Hide / show the overlay', 'Gets the whole thing out of the way without closing it.'],
  reload:             ['Reload the tablet',       'Pulls the newest build from the control server.'],
  settings:           ['Open these settings',     'This window.'],
  dimCycle:           ['Brightness - next step',  'Steps 25 - 50 - 75 - 100 and round again.'],
  dim25:              ['Brightness 25%',          ''],
  dim50:              ['Brightness 50%',          ''],
  dim75:              ['Brightness 75%',          ''],
  dim100:             ['Brightness 100%',         'Back to solid. Worth keeping somewhere you can find by feel.'],
  toggleHudOnly:      ['HUD only / whole tablet',  'HUD only shows just the floating HUD. The whole tablet is one key away.'],
  toggleCorners:      ['Corner dots on / off',     'Four dots, one at each corner of the HUD, so you can see where the display area ends. Floating HUD only. Stays how you left it after a reload.']
};
const STEPS = [25, 50, 75, 100];

let win = null, setWin = null, cfg = JSON.parse(JSON.stringify(DEFAULTS));
/* PT-005: true only for the initial Personal HUD launch.  The native window
   remains hidden until its injected HUD has been drawn. */
let personalHudInitialReveal = false;
/* PT-012 — approved for a private development tablet → 4 Game Overlay only.  This is still
   guarded by the Personal HUD URL below, so neither docked Personal tablet,
   iPad, nor Public Tablet can receive the overlay-only font. */
const personalHudRailFontEnabled = true;
const PERSONAL_HUD_MICHROMA_FILE = '';
let clickThrough = true, scBinds = { ok: false }, startupReport = [];
let fullBounds = null, compactNow = false, rzAnchor = null;
let sizeState = { full: null, hud: null };

// Every move of the window goes through here and says WHY. When something ends up
// the wrong size the log is a record instead of a guess - which is the only way to
// tell "compact shrank it" from "a resize grip did" after the fact.
function setBounds(b, why) {
  if (!win) return;
  const n = { x: Math.round(b.x), y: Math.round(b.y), width: Math.round(b.width), height: Math.round(b.height) };
  win.setBounds(n, false);
  console.log('BOUNDS ' + why + ' ' + n.x + ',' + n.y + ' ' + n.width + 'x' + n.height);
}

// ---------------------------------------------------------------------------
//  config
// ---------------------------------------------------------------------------
/* A URL given on the command line or in CG_URL beats the config file. That is how
   "3 - RUN OVERLAY (TEST BUILD).bat" points the same app at the TEST tablet without
   touching overlay.config.json - so the test launcher and the normal launcher can
   never fight over one setting. */
function urlOverride() {
  try {
    for (const a of process.argv) {
      const m = /^--url=(.+)$/.exec(a);
      if (m && m[1]) return m[1];
    }
    if (process.env.CG_URL) return process.env.CG_URL;
  } catch (e) {}
  return null;
}
function hudOnlyArg() {
  try { return process.argv.indexOf('--hud') >= 0 || process.env.CG_HUD === '1'; }
  catch (e) { return false; }
}

function loadConfig() {
  let c = JSON.parse(JSON.stringify(DEFAULTS));
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      const u = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
      Object.assign(c, u);
      c.hotkeys = Object.assign({}, DEFAULTS.hotkeys, u.hotkeys || {});
    } else {
      fs.writeFileSync(CONFIG_FILE, JSON.stringify(DEFAULTS, null, 2), 'utf8');
    }
  } catch (e) { console.error('config unreadable, using defaults:', e.message); }
  if (STEPS.indexOf(c.dimLevel) < 0) c.dimLevel = 100;
  if (['window', 'content', 'hud'].indexOf(c.dimTarget) < 0) c.dimTarget = 'window';
  const ov = urlOverride();
  if (ov) { c.url = ov; c.__urlFromArg = true; }
  if (hudOnlyArg()) { c.hudOnly = true; c.__hudFromArg = true; }
  return c;
}
function saveConfig() {
  // write to a temp file and rename, so a crash mid-write cannot leave a
  // half-written config that stops the overlay starting next time
  try {
    const tmp = CONFIG_FILE + '.tmp';
    const out = JSON.parse(JSON.stringify(cfg));
    delete out.__urlFromArg; delete out.__hudFromArg;
    if (cfg.__urlFromArg) delete out.url;          // a test URL must never become the saved one
    if (cfg.__hudFromArg) delete out.hudOnly;      // nor a --hud launch
    fs.writeFileSync(tmp, JSON.stringify(out, null, 2), 'utf8');
    fs.renameSync(tmp, CONFIG_FILE);
    return true;
  } catch (e) { console.error('could not save config:', e.message); return false; }
}

const STATE_FILE = path.join(app.getPath('userData'), 'window-state.json');
function loadState() { try { return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); } catch (e) { return null; } }
function saveState() {
  if (!win) return;
  try {
    fs.mkdirSync(path.dirname(STATE_FILE), { recursive: true });
    // never save the SHRUNK size as the window's own size, or COMPACT would be
    // sticky across restarts and there would be no way back to the full layout
    const b = fullBounds || win.getBounds();
    const prev = loadState() || {};
    const out = cfg.hudOnly
      ? Object.assign({}, prev, { hudW: b.width, hudH: b.height, x: b.x, y: b.y })
      : Object.assign({}, prev, { width: b.width, height: b.height, x: b.x, y: b.y });
    fs.writeFileSync(STATE_FILE, JSON.stringify(out), 'utf8');
  } catch (e) {}
}

function findScBinds() {
  for (const p of SC_BIND_CANDIDATES) {
    if (fs.existsSync(p)) return KM.loadStarCitizenBinds(fs, p);
  }
  return { ok: false, path: SC_BIND_CANDIDATES[0], count: 0, index: new Map(), error: 'no MASTER_KEYBINDS.json found' };
}

// ---------------------------------------------------------------------------
//  the page-side furniture: drag strip, toast, dimmer, resize grips, compact
//  reporter.  All of it injected, because the tablet HTML knows nothing about
//  being in an overlay and should not have to.
// ---------------------------------------------------------------------------
const OVL_CSS = `
/* the portrait gate is for phones, not for a window the pilot sized themselves */
#cg-rotate-lock{ display:none !important; }
/* v1.2.12 - T: "the bright pill on top of the hud ... needs to be borderless and
   fade to black like everything else in the tablet but with a small pulse in the
   cloud it sits on. sharp and easier readable, more contrast."
   The solid blue bar becomes the HUD's own language: no border, no fill - a soft
   cloud that breathes (4s, subtle), crisp bright text on a dark contact shadow. */
#cg-ovl-drag{
  /* CG767_TOPLINE - T (with his post-restart picture): "line up drag to move
     max min etc onto the tablet outline like CMDGLAS on the bottom." The row
     drops 4px and slims so its text centreline rides the frame's top stroke,
     the way CMDGLAS letters ride the bottom one. Measured against his
     1647-wide screenshot at his current zoom (GATE V: basis recorded). */
  /* CG767_DRAGBAND - 17 AUG 2026 S27. T: "the grab and drag is extremely
     unreliable. fix it." MEASURED CAUSE: after ROWKEYS the handle was an
     invisible 18px strip starting 22px down - most grabs missed it. The
     handle is now the WHOLE top band, edge to edge, 0-52px deep; the keys
     keep their seat via padding, and they stay no-drag so they still click.
     The band above and beside them all drags. */
  position:fixed; left:0; right:0; top:0; height:52px; padding-top:14px; box-sizing:border-box; z-index:2147483646;
  -webkit-app-region:drag; display:none; align-items:center; justify-content:center;
  gap:12px; font:800 10px/1 'Rajdhani','Segoe UI',sans-serif; letter-spacing:2px;
  color:rgba(234,246,255,.22); background:none; border:0;
  text-shadow:0 1px 2px rgba(0,7,14,.95), 0 0 3px rgba(0,10,20,.8);
  cursor:move; user-select:none; transition:color .16s ease, opacity .28s ease;
  /* CG767_ROWFADE - 17 AUG 2026 S27. T: "the drag to move max min row needs
     to fade into the background when not set upon by mouse."
     v1.2.15 already dimmed the INK to .22 at rest; this fades the whole row
     to a ghost. NOT opacity 0: if the row were fully invisible and hover
     ever failed to deliver over this drag strip, the controls would be
     unfindable - "text disappears" is a forbidden failure mode. .06 keeps a
     findable ghost. Hover on this exact element is proven live (the v1.2.15
     whole-row brighten has worked since it shipped). Restore: delete the
     opacity lines. */
  opacity:.06; }
#cg-ovl-drag:hover{ color:#eaf6ff; opacity:1; }
/* CG767_NOCLOUD - 17 AUG 2026. T: "the hud visibility background keeps
   flashing with a dark outline. that has to go" and "the scan effect in the
   hud controls menu and the tablet controls menu still cover the entire hud."
   MEASURED: this ::before was a window-wide dark band (left -4% to right -4%,
   top -140% to bottom -90% of the 30px bar = ~100px tall across the whole
   window), breathing .16<->.24 every 4s FOREVER (the flashing dark outline -
   both menus open directly under its bottom edge), and snapping to opacity 1
   whenever the pointer crossed the bar band (the full-width scan he sees
   working either menu). The cloud is paint only: drag still works (app-region
   is on the bar), the row's words still brighten on hover. Restore from
   main.js.bak_pre_NOCLOUD_20260817. */
#cg-ovl-drag::before{ content:none; }
/* v1.2.15 - T: "there is no visual seperation between drag to move whole tablet
   and the gather and buy and notes."
   THE TWO ROWS WERE THE SAME BRIGHTNESS AND THE SAME CLOUD, so they read as one
   six-item bar. This row belongs to the WINDOW, not to the tablet, so at rest it
   is only the shadow of its own words - the cloud drops to a fifth of its old
   weight and the text keeps its dark contact shadow with almost no fill. Reach
   for it and the whole row comes up together, so nothing has to be hunted for.
   The tablet's own row is untouched and is now the only lit thing up there. */
@keyframes cgOvlBreathe{
  0%,100%{ opacity:.16; } 50%{ opacity:.24; } }
/* CG767_NOCLOUD: hover-snap retired with the cloud above */
#cg-ovl-drag.on{ display:flex; }
#cg-ovl-drag span{ color:rgba(159,194,214,.22); transition:color .16s ease; }
#cg-ovl-drag button{
  -webkit-app-region:no-drag; cursor:pointer; font:800 10px/1 'Rajdhani','Segoe UI',sans-serif;
  letter-spacing:1.8px; color:rgba(223,242,255,.22); background:none; border:0; padding:5px 9px;
  text-shadow:0 1px 2px rgba(0,7,14,.95);
  transition:color .16s ease, text-shadow .16s ease; }
/* HOVER ANYWHERE ON THE ROW LIGHTS THE WHOLE ROW. Lighting only the one button
   under the pointer would still leave the others invisible, and you cannot aim
   at a word you cannot see. */
#cg-ovl-drag:hover span{ color:#9fc2d6; }
#cg-ovl-drag:hover button{ color:#dff2ff;
  text-shadow:0 1px 2px rgba(0,7,14,.95), 0 0 5px rgba(90,200,255,.35); }
#cg-ovl-drag button:hover{ color:#ffffff;
  text-shadow:0 1px 2px rgba(0,7,14,.95), 0 0 9px rgba(140,225,255,.9); }
/* v1.2.19 - T: "move the regular time out of the hud pill and undocked hud. move it
   to the top left corner of the tablet on the same line as drag to move max fit
   hotkeys etc. leave UTC in the HUD pill."
   margin-right:auto is what puts it hard left and pushes the existing controls to
   the right - the row is justify-content:center, so without it the clock would land
   in the middle of the group.
   IT IS NOT DIMMED LIKE THE BUTTONS. The rest of this row is deliberately almost
   invisible until you reach for it (v1.2.15) because it is furniture you only touch
   occasionally. A clock is the opposite: its whole job is to be readable without
   being touched. So it sits at the row's size, font and tracking, but it keeps its
   ink at rest. To make it behave like the buttons instead, change the color below to
   rgba(159,194,214,.22) - that is the exact one line.
   It carries -webkit-app-region:drag like the rest of the strip, so it is part of the
   drag handle and not a dead spot. */
#cg-ovl-clk{
  -webkit-app-region:drag; margin-right:auto; padding-left:4px;
  font:800 10px/1 'Rajdhani','Segoe UI',sans-serif; letter-spacing:2px;
  color:#9fc2d6; text-shadow:0 1px 2px rgba(0,7,14,.95), 0 0 3px rgba(0,10,20,.8);
  user-select:none; transition:color .16s ease; }
#cg-ovl-drag:hover #cg-ovl-clk{ color:#eaf6ff; }
/* CG767_NOTOPCLK - 17 AUG 2026. T (with the picture): "the tablet i'm looking
   at has a secondary time location" -> "top left time" -> remove it. The
   clock was HIS OWN v1.2.19 ask ("to the top left corner ... leave UTC in the
   HUD pill") - the new order supersedes it, both recorded. visibility, not
   display: the span's margin-right:auto is what holds DRAG TO MOVE / MAX /
   FIT / HOTKEYS / CLOSE on the right - removing its box would re-centre the
   whole row (GATE Y). The ticker keeps writing to an invisible node; cost is
   one string compare per second. Restore: delete this one rule. */
/* CG767_CENTERTOP - T, 17 AUG: "move drag to move max min hotkeys and close
   to the very top centered on the fake camera hole." The hidden clock still
   held margin-right:auto, which shoved the whole group right; with it gone the
   row's own justify-content:center centers the controls on the frame's camera
   notch. */
#cg-ovl-clk{ visibility:hidden !important; margin-right:0 !important; }
/* CG767_ROWKEYS - 17 AUG 2026 S27. T: "remove the writing Drag to move and
   center the max min buttons."
   The label span is hidden; the clock goes display:none (visibility kept
   its ghost width and would bias the centre by half a clock). The row is
   already justify-content:center, so the buttons centre themselves.
   DRAGGING STILL WORKS: app-region:drag is on the row band, not the label -
   grab anywhere on the strip that is not a button. Restore: delete these
   two lines. */
#cg-ovl-drag > span:not(#cg-ovl-clk){ display:none !important; }
#cg-ovl-clk{ display:none !important; }
/* CG767_ROWORDER - T: "move min to left and max to right in the max min line."
   Flex order only - the DOM, the click wiring and data-a stay untouched. */
#cg-ovl-drag button[data-a="hud"]{ order:1; }
#cg-ovl-drag button[data-a="fit"]{ order:2; }
#cg-ovl-drag button[data-a="max"]{ order:3; }
#cg-ovl-drag button[data-a="settings"]{ order:4; }
#cg-ovl-drag button[data-a="close"]{ order:5; }
/* v1.2.15 - HUD-only has no shutdown control. Dock, then close. */
#cg-ovl-drag.cg-hudmode button[data-a="close"]{ display:none !important; }
/* v1.2.16 - T: "too many controls as it stands now."  MEASURED in whole-tablet:
   THREE controls read as undock and only two were - the strip's HUD ONLY (83x20),
   the tablet's own UNDOCK (44x12, bottom row) and the HUD caret, which is not an
   undock control at all. T's ruling: the tablet's own UNDOCK is the one that
   survives, so the strip's button is not rendered while the tablet is docked. In
   HUD-only it comes back as the DOCK control, which is the one thing the HUD has
   no other way to do. */
#cg-ovl-drag:not(.cg-hudmode) button[data-a="hud"]{ display:none !important; }
/* v1.2.16 - THE CARET IS NOT A HUD BUTTON. Its own title attribute in the tablet
   source says "HUD settings - transparency, brightness, colour", and it reads
   "HUD" with a chevron, which is why it looked like a HUD ONLY button that did
   nothing. Relabelled, not hidden - the panel behind it is real.
   WHOLE-TABLET ONLY: in HUD-only the tablet drives this same ::before itself for
   the tint glow (4 rules, all guarded by cg-hudonly/cg-holo - checked), and
   "HUD" is the right word when you are already in the HUD. The selector carries
   the id and outweighs the tablet's own #sc-home-widgets rule (RULE 18).
   MEASURED, first attempt failed: the guard was :not(.cg-hudonly):not(.cg-holo)
   and NOTHING applied - the tablet runs classList.toggle('cg-holo', m!=='panel'),
   so cg-holo is ON in normal use and my own guard was switching my rule off. The
   cg-holo ::before rules it was meant to avoid all require a .cg-pop-float
   ancestor, and RULE 20 says the overlay never spawns a float, so they cannot
   collide in here. Guard dropped. */
html:not(.cg-hudonly) body #sc-home-widgets .ops-pill.b385 .cg-hs-chev{
  font-size:0 !important; }
html:not(.cg-hudonly) body #sc-home-widgets .ops-pill.b385 .cg-hs-chev::before{
  /* MEASURED: 'HUD OPTIONS' at 9px came out 106px wide against the 43px the
     caret had, and the tab row does not reflow around it - the label printed
     straight over the STREAM tab. 'OPTIONS' at 8px was still 72px and still
     overlapped. MEASURED BUDGET IS THE 43px THE OLD LABEL HAD - the tab row does
     not reflow, so the label has to fit the hole, not just say the right thing.
     'OPTS' is what fits. The full sentence is still on the button's own title
     attribute: "HUD settings - transparency, brightness, colour".
     v1.2.17, 4 AUG 2026 - T: "don't abbreviate options as opts. find a different
     abbreviation." He chose CFG. Three characters against OPTS's four, same 8px
     Rajdhani, so it cannot be wider than the label it replaces and the 43px budget
     above still holds. Nothing else in this rule changes. */
  content:'CFG' !important;
  font:700 8px 'Rajdhani','Segoe UI',sans-serif !important; letter-spacing:.6px !important;
  background:none !important; box-shadow:none !important; }
html:not(.cg-hudonly) body #sc-home-widgets .ops-pill.b385 .cg-hs-chev{
  padding-left:6px !important; padding-right:6px !important; }
html:not(.cg-hudonly) body #sc-home-widgets .ops-pill.b385 .cg-hs-chev .cv{
  font-size:8px !important; }
/* v1.2.16 - T: "fix offset too close to frame". The strip sat at top:2px, so
   its caps ran into the window edge. Lane moved to top:10px and every
   clearance below it moved with it - 26 -> 44 here, 28 -> 44 inline. */
/* CG767_TOPBAND - 17 AUG 2026. T (with picture): "remove that tall space
   between the top of the tablet hud pill and make it reach to the very top
   corner of the tablet. move drag to move max FIT (rename to min) Hotkeys and
   close onto the tablet perimiter band." The 44px lane inset is retired; the
   control row now RIDES the tablet's own top band instead of owning a band of
   its own. v1.2.16's clearance concern is void - the row no longer needs a
   cleared lane, it sits on the frame. */
body.cg-ovl-draggable{ padding-top:0 !important; box-sizing:border-box; }
#cg-ovl-toast{
  position:fixed; left:50%; top:38px; transform:translateX(-50%); z-index:2147483647;
  padding:9px 16px; border-radius:9px; pointer-events:none; opacity:0; max-width:80vw;
  transition:opacity .18s ease; font:800 12.5px/1.45 'Rajdhani','Segoe UI',sans-serif;
  letter-spacing:1.6px; color:#04141d; text-align:center;
  background:linear-gradient(180deg,#a6f2ff,#33b5e6); box-shadow:0 4px 16px rgba(0,0,0,.5); }
#cg-ovl-toast.warn{ background:linear-gradient(180deg,#ffd479,#e0a000); }
#cg-ovl-toast.on{ opacity:1; }
/* THE RESIZE GRIPS. A transparent window has no edge Windows can grab, so the
   corners are drawn here and they drive setBounds themselves. Shown only when
   click-through is off, so they can never sit over the game while flying. */
.cg-ovl-rz{
  position:fixed; width:38px; height:38px; z-index:2147483645; display:none;
  -webkit-app-region:no-drag; }
body.cg-ovl-draggable .cg-ovl-rz{ display:block; }
/* v1.2.6 - T: "the resize control dissapeard" + earlier "draw a little bit of
   attention to the 3 dots with a recize symbol. it's super easy to miss especially
   with the star darkeness background". Same language as the tablet's browser grip:
   soft halo, three dots, a resize arrow. Bottom-right carries the arrow. */
body.cg-ovl-draggable .cg-ovl-rz{
  background: radial-gradient(50% 50% at 55% 55%, rgba(90,190,240,.20), transparent 72%); }
#cg-ovl-rz-se::before{ content:'\u2921'; position:absolute; left:-2px; top:-4px;
  font:700 17px sans-serif; color:rgba(175,238,255,.95);
  text-shadow:0 0 8px rgba(120,215,255,.95); pointer-events:none; }
#cg-ovl-rz-se:hover::before{ color:#ffffff; }
/* T: "no triangles". The grips used to be L-shaped brackets, which are corners of a
   box - the exact thing the slab is trying not to look like. They are soft dots now:
   round, no angle anywhere, and they only exist while click-through is off. */
.cg-ovl-rz::after{
  content:''; position:absolute; inset:9px; border-radius:50%; display:none;   /* CG767_GRIPDOTS - T: "corner glows are still there" - the grip dots are the corner glows. Hidden, never removed: the grips still resize. */
  background:
    radial-gradient(circle 3px at 78% 78%, rgba(200,250,255,.95), transparent 70%),
    radial-gradient(circle 3px at 78% 40%, rgba(180,240,255,.85), transparent 70%),
    radial-gradient(circle 3px at 40% 78%, rgba(180,240,255,.85), transparent 70%); }
.cg-ovl-rz:hover::after{
  background:
    radial-gradient(circle 3px at 78% 78%, #ffffff, transparent 70%),
    radial-gradient(circle 3px at 78% 40%, rgba(225,252,255,1), transparent 70%),
    radial-gradient(circle 3px at 40% 78%, rgba(225,252,255,1), transparent 70%); }
/* v1.2.14 - THE CLICK-THROUGH BADGE. A toast is an event; click-through is a
   STATE, and a state needs a tell that stays. Amber, not cyan: this is the
   tablet's only "you cannot touch me" condition and it must not read as chrome.
   pointer-events:none so it can never eat a click in the interactive state, and
   it lives in the same top-centre lane as the drag strip - the two are mutually
   exclusive by construction (setDragBar(!clickThrough) / setCtBadge(clickThrough)). */
#cg-ovl-ctbadge{
  position:fixed; left:50%; top:10px; transform:translateX(-50%); z-index:2147483647;
  display:none; pointer-events:none; padding:6px 15px; border-radius:8px;
  font:800 11px/1.35 'Rajdhani','Segoe UI',sans-serif; letter-spacing:1.7px;
  color:#2a1a00; text-align:center; white-space:nowrap;
  background:linear-gradient(180deg,#ffd479,#e0a000);
  box-shadow:0 3px 14px rgba(0,0,0,.55); }
#cg-ovl-ctbadge.on{ display:block; }
/* CG767_RZTOP - 17 AUG 2026. T (tablet view): "the corner drag dots aren't
   lined up with the corners." The top grip pair sat 28px down - a relic of
   the old drag band owning that strip - while the bottom pair hugs at 2px.
   All four now seat 2px off their true corners. The grips carry their own
   app-region, so overlapping the drag band's corners costs nothing; resize
   wins inside the 38px box, drag everywhere else on the band. */
#cg-ovl-rz-nw{ left:2px; top:2px; cursor:nwse-resize; }
#cg-ovl-rz-ne{ right:2px; top:2px; cursor:nesw-resize; }
#cg-ovl-rz-sw{ left:2px; bottom:2px; cursor:nesw-resize; }
#cg-ovl-rz-se{ right:2px; bottom:2px; cursor:nwse-resize; }
`;

// Everything the page sends back to main goes through console.log with this
// prefix. It is a one-way channel that needs no preload and no node integration
// in the tablet page - the tablet stays an ordinary web page.
const OVL_JS = `
(function(){
  var TAG='CGOVL\\u00a7';
  function send(o){ try{ console.log(TAG+JSON.stringify(o)); }catch(e){} }
  window.__cgOvlSend=send;

  if(!document.getElementById('cg-ovl-drag')){
    var d=document.createElement('div'); d.id='cg-ovl-drag';
    /* v1.2.15 - T: "remove the cmdglas overlay title from the top left."
       The app does not need to announce itself on every frame of his screen. */
    /* v1.2.19 - the local clock is FIRST so it owns the left end of the row. */
    d.innerHTML='<span id="cg-ovl-clk" title="Local time">--:--</span>'
      +'<span>DRAG TO MOVE</span>'
      +'<button type="button" data-a="hud" id="cg-ovl-hudbtn">HUD ONLY</button>'
      +'<button type="button" data-a="max">MAX</button>'
      +'<button type="button" data-a="fit" title="Snap to the smallest fully readable size">MIN</button>'
      +'<button type="button" data-a="settings">HOTKEYS</button>'
      +'<button type="button" data-a="close" title="Close the overlay window">\u2715 CLOSE</button>'; /* v1.2.3 - T: "the tablet needs a way to be closed from the onscreen tablet surface" */
    document.body.appendChild(d);
    d.addEventListener('click', function(e){
      var b=e.target.closest && e.target.closest('button[data-a]');
      if(b) send({act:b.getAttribute('data-a')});
    });
    /* v1.2.19 - 24 hour local time, the tablet's own format (two digit hour, colon,
       two digit minute). One interval, and it only writes when the string actually
       changes, so it is not a repaint every second. This is the one timer in here
       that is meant to be permanent - a clock cannot be event driven (RULE 17 is
       about timers that fight layout, and this one touches nothing but its own text). */
    (function(){
      var el=document.getElementById('cg-ovl-clk'), was='';
      function two(n){ return (n<10?'0':'')+n; }
      function tick(){
        try{
          if(!el||!el.isConnected) el=document.getElementById('cg-ovl-clk');
          if(!el) return;
          var t=new Date(), s=two(t.getHours())+':'+two(t.getMinutes());
          if(s!==was){ el.textContent=s; was=s; }
        }catch(e){}
      }
      tick(); setInterval(tick,1000);
    })();
  }
  if(!document.getElementById('cg-ovl-toast')){
    var t=document.createElement('div'); t.id='cg-ovl-toast'; document.body.appendChild(t);
  }
  /* v1.2.14 - the persistent click-through tell. Built once, shown by class. */
  if(!document.getElementById('cg-ovl-ctbadge')){
    var cb=document.createElement('div'); cb.id='cg-ovl-ctbadge';
    cb.textContent='CLICK-THROUGH ON \\u00b7 MOUSE GOES TO GAME \\u00b7 CTRL+SHIFT+F12';
    document.body.appendChild(cb);
  }
  ['nw','ne','sw','se'].forEach(function(c){
    if(document.getElementById('cg-ovl-rz-'+c)) return;
    var g=document.createElement('div'); g.className='cg-ovl-rz'; g.id='cg-ovl-rz-'+c;
    document.body.appendChild(g);
    var live=false, raf=0, last=null;
    g.addEventListener('pointerdown', function(e){
      e.preventDefault(); live=true;
      try{ g.setPointerCapture(e.pointerId); }catch(_){}
      send({rz:'start', edge:c, sx:e.screenX, sy:e.screenY});
    });
    g.addEventListener('pointermove', function(e){
      if(!live) return;
      last={sx:e.screenX, sy:e.screenY};
      if(raf) return;
      raf=requestAnimationFrame(function(){ raf=0; if(last) send({rz:'move', sx:last.sx, sy:last.sy}); });
    });
    function end(e){ if(!live) return; live=false; if(raf){cancelAnimationFrame(raf);raf=0;} send({rz:'end'}); }
    g.addEventListener('pointerup', end);
    g.addEventListener('pointercancel', end);
  });

  /* THE START PAGE. The tablet opens on a cover screen with an ENTER TABLET button.
     That is right in a browser and wrong in an overlay - the pilot launched the app,
     they have already "entered". T, exactly: "the run test bat just opened the entire
     tablet start screen in app format. i don't know what's going on."
     window.scCoverGo() is the tablet's own dismiss function (it clears the .hide class
     AND the inline display:none the fade leaves behind), so this uses that rather than
     poking at the element - one code path, no second way to be wrong. */
  function enterTablet(){
    try{
      var c=document.getElementById('cover-screen');
      if(!c) return true;
      /* judge by what is PAINTED, not by the class. Coming back from HUD-only the
         .hide class is still on the cover but the inline display:none has been
         restored away, so a class check said "already dismissed" while the start
         page was on screen. MEASURED: cover computed display 'flex' with .hide set. */
      var cs=getComputedStyle(c);
      if(cs.display==='none') return true;
      if(typeof window.scCoverGo==='function'){ window.scCoverGo(); return true; }
      var b=document.getElementById('cover-enter'); if(b){ b.click(); return true; }
      c.classList.add('hide'); c.style.display='none'; return true;
    }catch(e){ return false; }
  }
  window.__cgOvlEnter=enterTablet;
  enterTablet();
  /* the cover can be re-shown by the tablet's own START PAGE button; only dismiss it
     on the way in, bounded, never on a permanent timer */
  var _n=0, _iv=setInterval(function(){ if(enterTablet()||++_n>25) clearInterval(_iv); }, 300);

  /* UNDOCK MEANS SOMETHING ELSE IN AN APP.
     T: "when i'm using run overlay.bat and then want to pop out the hud via undock,
     undock runs the run hud only .bat. and vice versa?" - yes, that is the right
     design and this is where it is done.

     In a BROWSER, build 430's UNDOCK has to spawn a second window, because a browser
     tab cannot float. In the OVERLAY the window is ALREADY the floating window, so
     spawning another one is pure cost: a second thing to position, a second thing to
     lose. So in here UNDOCK is intercepted and turned into "this window becomes the
     HUD". DOCK / RTB turns it back into the whole tablet. Same window, both ways.

     Captured on the way DOWN (capture:true) so build 430's own listener never runs -
     stopping it after the fact would leave a second window already opening. */
  document.addEventListener('click', function(e){
    var b=e.target && e.target.closest && e.target.closest('.cg-undock-btn,.cg-pop-fdock,.cg-pop-rtb');
    if(!b) return;
    var pop=b.getAttribute && b.getAttribute('data-pop');
    if(pop && pop!=='ops') return;            /* only the HUD - other pills keep their own behaviour */
    e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
    send({act:'hud', want:'toggle'});
  }, true);

  document.addEventListener('keydown', function(e){
    /* the tablet binds Ctrl+Alt+1 to undock. Same substitution, same reason. */
    if(e.ctrlKey && e.altKey && !e.shiftKey && (e.code==='Digit1'||e.key==='1')){
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
      send({act:'hud', want:'toggle'});
    }
  }, true);

  window.__cgOvlHudBtn=function(hudOn){
    var b=document.getElementById('cg-ovl-hudbtn');
    /* v1.2.16 - one label, one job. The button is only rendered in HUD-only now
       (CSS above), and in HUD-only the only thing it can do is dock. It used to
       carry both labels because it used to be shown in both modes. */
    if(b) b.textContent = 'DOCK TABLET';
    /* v1.2.15 - T: "remove the close button and undock button from the hud. the
       only option can be to dock the hud and then close the tablet. for
       shutdown."  There is no quitting from the HUD: dock first, close second.
       The button is not disabled, it is not rendered - a disabled control still
       invites the click. */
    var d=document.getElementById('cg-ovl-drag');
    if(d) d.classList.toggle('cg-hudmode', !!hudOn);
  };

  window.__cgOvlDrag=function(on){
    var d=document.getElementById('cg-ovl-drag'); if(!d) return;
    d.classList.toggle('on', !!on);
    document.body.classList.toggle('cg-ovl-draggable', !!on);
    /* v1.2.5 - T's screenshot 3 AUG 2026: in HUD-only the sweep zeroes body padding
       with inline !important, so the strip sat ON TOP of the tab row and the tabs
       "vanished". The hud itself steps down while the strip is visible. */
    var hud=document.querySelector('.cg-ho-hud');
    if(hud){ if(on){ hud.style.setProperty('margin-top','44px','important'); }
             else { hud.style.removeProperty('margin-top'); } }
  };
  /* v1.2.14 - state, not event: this one has no timer and does not fade. */
  window.__cgOvlCtBadge=function(on){
    var b=document.getElementById('cg-ovl-ctbadge'); if(!b) return;
    b.classList.toggle('on', !!on);
    /* SAME LANE AS THE DRAG STRIP, SO THE SAME 28px STEP. MEASURED on the first
       v1.2.14 render: the badge sat across the HUD's tab row (GATHER & BUY /
       NOTES / CONTRACTS ...) exactly as the strip did before v1.2.5. Stepping the
       HUD down for the badge too also means the HUD no longer JUMPS when
       click-through is toggled - one goes, the other arrives, same height. */
    var hud=document.querySelector('.cg-ho-hud'); if(!hud) return;
    if(on){ hud.style.setProperty('margin-top','44px','important'); }
    else {
      /* only clear it if the strip is not the one holding it - setDragBar(true)
         runs BEFORE setCtBadge(false) on the way out of click-through */
      var d=document.getElementById('cg-ovl-drag');
      if(!d || !d.classList.contains('on')) hud.style.removeProperty('margin-top');
    }
  };
  window.__cgOvlToast=function(msg, warn, ms){
    var t=document.getElementById('cg-ovl-toast'); if(!t) return;
    t.textContent=msg; t.classList.toggle('warn', !!warn); t.classList.add('on');
    clearTimeout(t.__h); t.__h=setTimeout(function(){ t.classList.remove('on'); }, ms||1100);
  };
  window.__cgOvlDim=function(target, pct){
    var id='cg-ovl-dim', st=document.getElementById(id);
    if(!st){ st=document.createElement('style'); st.id=id; document.head.appendChild(st); }
    var o=(pct/100);
    if(target==='hud'){
      st.textContent='#sc-home-widgets .ops-pill.b385{opacity:'+o+' !important}';
    }else if(target==='content'){
      st.textContent='html,body,#content,#tab-home,#tab-home #home-scroll,'
        +'#tab-home .hm-wrap,#tab-home .hm-cols{background:transparent !important;'
        +'background-image:none !important}'
        +'#content{opacity:'+o+' !important}';
    }else{ st.textContent=''; }
  };

  /* COMPACT. The tablet owns the setting (build 693 puts .cg-compact on <html>);
     the overlay only follows it.

     WHAT NOT TO DO, LEARNED BY DOING IT. The first version reported the absolute
     height of the control bar and let main resize to that. It GREW the window from
     900 to 1212 instead of shrinking it, because the tablet scales its home screen
     to fit the window - so the height main was chasing changed every time main
     changed the window, and the two ran away from each other. MEASURED: onebar
     bottom 1210 at 900 px tall, 1386 after the window grew to 1212.

     So the page reports the DELTA instead: how many pixels compact actually
     removes. That number does not depend on the window size, so there is no loop.
     It is measured by forcing the layout both ways inside ONE frame - two reads,
     no paint between them, so nothing flickers on screen. */
  function hiddenPx(){
    var bar=document.getElementById('cg-onebar'); if(!bar) return 0;
    var r=document.documentElement, was=r.classList.contains('cg-compact');
    function bottom(){
      var b=0, ids=['cg-onebar','cg-theme-row536','cg-social-row','cg-affil-note'];
      for(var i=0;i<ids.length;i++){
        var e=document.getElementById(ids[i]);
        if(!e) continue;
        var cs=getComputedStyle(e); if(cs.display==='none') continue;
        b=Math.max(b, e.getBoundingClientRect().bottom);
      }
      return b;
    }
    r.classList.add('cg-compact');    var withCompact=bottom();
    r.classList.remove('cg-compact'); var withFull=bottom();
    if(was) r.classList.add('cg-compact');
    var d=Math.round(withFull-withCompact);
    return (d>0 && d<2000) ? d : 0;
  }
  var lastState=null;
  function report(force){
    /* CG767 15 AUG: hiddenPx() toggles .cg-compact on <html> to measure - two
       full-page restyles in one task. Invisible on a healthy GPU; on the
       driver that crashed 14 AUG (overlay_error.log, GPU exitCode 34) each
       probe presents as a full-window flash. HUD-only mode has no compact
       shrink to report, so the probe stands down there and resumes on dock. */
    try{ if(document.documentElement.classList.contains('cg-hudonly')) return; }catch(e){}
    var c=document.documentElement.classList.contains('cg-compact');
    if(!force && c===lastState) return;
    lastState=c;
    send({compact:c, hiddenPx:hiddenPx()});
  }
  if(!window.__cgOvlObs){
    window.__cgOvlObs=new MutationObserver(function(){ report(false); });
    window.__cgOvlObs.observe(document.documentElement,{attributes:true,attributeFilter:['class']});
  }
  window.__cgOvlFit=function(){ report(true); };
  /* the home screen finishes laying out after the fonts and the fit pass, so the
     first measurement is taken a moment later - twice, not on a loop */
  setTimeout(function(){ report(true); }, 1500);
  setTimeout(function(){ report(true); }, 6000);
  send({ready:true});
})();
`;

// ---------------------------------------------------------------------------
//  HUD ONLY
//
//  T: "i want app hud only. address bar hud has to go."
//
//  The app used to open the whole tablet and leave the pilot to press Ctrl+Alt+1 to
//  pop the HUD out of it - three steps to reach the one thing he wanted. HUD ONLY
//  opens straight into the floating HUD instead.
//
//  IT DOES NOT USE THE TABLET'S UNDOCK. Build 430's undock spawns a second window
//  (Document PiP, a popup, or an in-page float) which is exactly the machinery that
//  is not wanted here - the overlay window IS already the floating window. So this
//  simply hides everything in the page except the HUD and lets the HUD fill the
//  window. Fewer moving parts, and nothing to fight with build 430's own sweep.
//
//  HOW THE HIDING WORKS, AND WHY IT IS NOT A LIST OF IDs. Marking "hide #topbar,
//  #sc-tools-row, #cg-onebar ..." breaks the first time a block adds a new element.
//  Instead it walks UP from the HUD to <body>, marks every ancestor as KEEP, then
//  hides every child of a KEEP element that is not itself KEEP. Structure-independent:
//  anything added to the home screen later is hidden automatically because it will
//  not be on the path to the HUD.
// ---------------------------------------------------------------------------
const OVL_ROUND_CSS = `
/* v1.2.11 - T: "the tablet outer corners aren't rounded. they have corners squares."
   The window is frameless and transparent; its shape IS whatever the page paints,
   and the tablet paints to the rectangle's edge. clip-path on the root rounds the
   ENTIRE page - including fixed-position layers, which plain border-radius+overflow
   cannot clip. Whole-tablet mode only: the HUD is free-floating glass already. */
html:not(.cg-hudonly){ clip-path: inset(0 round 22px); }
`;

const HUDONLY_CSS = `
/* v1.2.8 - T: "this is already undocked so why is the undocked button showing".
   In the app the intercepted button DOCKS you back, but its label never changed
   for HUD-only. Relabelled here with CSS (stateless - the tablet's own button
   sweep rewrites textContent, it cannot rewrite a pseudo-element). */
html.cg-hudonly .cg-undock-btn{ font-size:0 !important; }
html.cg-hudonly .cg-undock-btn::after{
  content:'DOCK TABLET';
  font:700 9px 'Rajdhani','Segoe UI',sans-serif; letter-spacing:1.1px;
  color:#9fbdd2; text-shadow:0 1px 2px rgba(0,7,14,.9); }
/* THE HIDING IS DONE WITH INLINE STYLES IN HUDONLY_JS, not here - see the note in
   that block. What is left here is only the LOOK, which nothing in the tablet fights
   over, so ordinary rules are enough. */
html.cg-hudonly #cg-rotate-lock,
html.cg-hudonly #sc-spacebg,
html.cg-hudonly #sc-lshape,
html.cg-hudonly #topbar,
html.cg-hudonly #sc-zoom-bar,
html.cg-hudonly #sc-right-bar,
html.cg-hudonly #sc-appbar,
html.cg-hudonly #cg-cmdlog,
html.cg-hudonly #cg-credit,
html.cg-hudonly #cg-affil-note,
html.cg-hudonly #scv-build{ display:none !important; }
/* THE LIGHT BAND, FOUND BY PROBING RATHER THAN GUESSING. body::before is a
   radial-gradient glow and body::after is a repeating-linear-gradient scanline
   field - the tablet's own atmosphere. Inline styles cannot touch a pseudo-element,
   which is why the sweep over every real element left alpha at 232 out of 255.
   MEASURED: elementsFromPoint in the gap returned nothing but transparent elements,
   and the paint was coming from underneath all of them. */
html.cg-hudonly body::before,
html.cg-hudonly body::after,
html.cg-hudonly #sc-spacebg::before,
html.cg-hudonly #sc-spacebg::after,
html.cg-hudonly .hm-wrap::before,
html.cg-hudonly .hm-wrap::after,
/* the pill paints its own gradient through .wg::before - that was the last solid
   thing left inside the HUD after the body atmosphere went. MEASURED: corner alpha
   0, middle alpha 229, so the paint was inside the pill, not behind it. */
html.cg-hudonly .cg-ho-hud::before,
html.cg-hudonly .cg-ho-hud::after,
html.cg-hudonly #sc-home-widgets .cg-ho-hud::before,
html.cg-hudonly #sc-home-widgets .cg-ho-hud::after,
html.cg-hudonly .cg-ho-hud .pill-body::before,
html.cg-hudonly .cg-ho-hud .pill-body::after{
  content: none !important; background: none !important; display: none !important; }
html.cg-hudonly #cover-screen{ display:none !important; }
html.cg-hudonly .cg-ho-hud *{
  text-shadow: 0 0 5px rgba(150,235,255,.9), 0 0 14px rgba(70,180,245,.5) !important; }
html.cg-hudonly .cg-ho-hud .pill-body,
html.cg-hudonly .cg-ho-hud .ops4-body,
html.cg-hudonly .cg-ho-hud .ops4-list,
html.cg-hudonly #sc-home-widgets .cg-ho-hud .pill-body{
  background: transparent !important; background-image: none !important;
  border: 0 !important; box-shadow: none !important; }
html.cg-hudonly .cg-ho-hud .ops4-row{ border-bottom: 0 !important; }
/* a scrollbar is a piece of window furniture and there is no window */
html.cg-hudonly .cg-ho-hud *::-webkit-scrollbar{ width:0 !important; height:0 !important; }
html.cg-hudonly .cg-ho-hud *{ scrollbar-width: none !important; }
/* THE SETTINGS PANEL IS EXEMPT. The sweep strips every background inside the HUD to
   make it a hologram, and it stripped the settings panel too - unreadable over a
   bright scene. A panel you opened deliberately is not part of the projection. */
html.cg-hudonly .cg-ho-hud .cg-hs-panel{
  background: rgba(6,16,26,.93) !important;
  border: 1px solid rgba(120,190,225,.4) !important;
  box-shadow: 0 8px 26px rgba(0,0,0,.65) !important; }
html.cg-hudonly .cg-ho-hud button,
html.cg-hudonly .cg-ho-hud .ops4-tab,
html.cg-hudonly #sc-home-widgets .cg-ho-hud button,
html.cg-hudonly #sc-home-widgets .cg-ho-hud .ops4-tab{
  background: transparent !important; background-image: none !important;
  box-shadow: none !important; color:#a8e6fb !important;
  border: 1px solid rgba(130,225,255,.28) !important; }
html.cg-hudonly .cg-ho-hud .ops4-tab.on,
html.cg-hudonly #sc-home-widgets .cg-ho-hud .ops4-tab.on{
  color:#eaffff !important; border-color: rgba(170,245,255,.8) !important;
  background: rgba(120,220,255,.14) !important; }
html.cg-hudonly .cg-ho-hud .cg-undock-btn,
html.cg-hudonly #sc-home-widgets .cg-ho-hud .cg-undock-btn{ display:none !important; }
/* the drag strip needs its 26 px when it is showing, or it sits on the tab row */
html.cg-hudonly body.cg-ovl-draggable .cg-ho-hud,
html.cg-hudonly body.cg-ovl-draggable #sc-home-widgets .cg-ho-hud{
  margin-top: 44px !important; height: calc(100% - 44px) !important; }
html.cg-hudonly body.cg-ovl-draggable{ padding-top: 0 !important; }
`;

const HUDONLY_JS = `
(function(){
  /* INLINE STYLES, NOT CLASSES - and that is the whole lesson of this file.
     A class rule cannot beat an id rule no matter how many !importants it carries,
     and the tablet is full of them: #sc-home-widgets .wg{display:flex !important}
     (1,1,0) beat html.cg-hudonly .cg-ho-hide (0,2,0) and the widgets stayed on
     screen. An inline !important beats every stylesheet rule there is.
     Everything touched is tagged with data-cgho so it can be put back exactly. */
  var MARK='data-cgho';
  function set(el, prop, val){
    if(!el.hasAttribute(MARK)) el.setAttribute(MARK,'1');
    el.style.setProperty(prop, val, 'important');
  }
  function restore(){
    var base=document.getElementById('cg-ho-base'); if(base) base.remove();
    var _wo=document.getElementById('cg-ho-widthowner'); if(_wo) _wo.remove();
    document.querySelectorAll('['+MARK+']').forEach(function(el){
      ['display','width','height','max-width','max-height','min-height','margin',
       'padding','background','background-image','border','box-shadow','overflow',
       'box-sizing','border-radius','position','inset','transform','flex','zoom',
       'min-width','max-width','background-origin','background-clip',
       'transform-origin','overflow'].forEach(function(p){
        el.style.removeProperty(p);
      });
      el.removeAttribute(MARK);
      if(!el.getAttribute('style')) el.removeAttribute('style');
    });
  }
  function skip(el){
    if(!el || !el.tagName) return true;
    if(el.tagName==='SCRIPT'||el.tagName==='STYLE'||el.tagName==='LINK') return true;
    /* v1.2.14 - the badge joins the drag strip and the toast on this list. The
       sweep below inline-hides every body child that is not on the path to the
       HUD, and on the first build of this badge it did exactly that: badgeOn was
       true and the element carried display:none from the sweep. The one node that
       exists to be seen has to be exempt from the hiding pass. */
    if(el.id==='cg-ovl-drag'||el.id==='cg-ovl-toast'||el.id==='cg-ovl-ctbadge') return true;
    if(el.classList && el.classList.contains('cg-ovl-rz')) return true;
    return false;
  }
  window.__cgHudOnly=function(on){
    restore();
    document.documentElement.classList.toggle('cg-hudonly', !!on);
    /* restore() puts back everything it touched, and the start page was one of them -
       so it has to be dismissed again on the way out, or turning HUD-only off drops
       the pilot back on the cover screen. */
    if(!on){
      try{ if(window.__cgOvlEnter) window.__cgOvlEnter(); }catch(e){}
      /* v1.2.18, 4 AUG 2026.  T: "when i undocked and then redocked the hud from the
         tablet it wouldn't show anything below the 2nd pill line (ingame tools),
         aspect ratio gets messed up."

         PROVEN FROM THE CODE, both sides read before writing this:
         The tablet's SC-FIT pass owns FOUR INLINE STYLES on html/body -
             documentElement.style.zoom            (0.5 .. 1.8, from the window size)
             body.style.minWidth  = 1700px
             body.style.maxWidth  = computed from the window and the zoom
             body.style.marginLeft / marginRight = auto
         Going into HUD-only, set() overwrites zoom, min-width, max-width, margin,
         width and height on html and body. Coming out, restore() calls
         el.style.removeProperty() on that same list - which DELETES the property
         outright. It does not put SC-FIT's values back, because it never had them.
         So after a redock html has no zoom, and body has no 1700px floor, no width
         cap and no auto margins. That is the wrong aspect ratio and the missing rows.

         Nothing re-applies them on its own: SC-FIT only re-runs on a resize event
         (150ms debounce) or when body[data-portable] flips, and RULE 20 means the
         redock happens in the SAME window - so no resize is ever fired.

         FIX: fire one. SC-FIT's own maths is the authority on what the zoom and the
         width cap should be at this window size; this reimplements none of it, it
         just tells the tablet the layout changed. The repeats cover the pill being
         rebuilt asynchronously after the dock; SC-FIT's own 150ms debounce collapses
         them into about two real passes. Bounded, no permanent timer (RULE 17).

         NOTE FOR THE NEXT EDITOR: this file embeds its injected payload in a template
         literal, so a backtick anywhere in a comment in here terminates the string and
         the whole file stops parsing. Do not use them.

         NOT VERIFIED ON T'S SCREEN. Reversible: delete this block, leaving the
         __cgOvlEnter line above it. */
      try{
        [0,60,200,500,1000,2000].forEach(function(ms){
          setTimeout(function(){
            try{ window.dispatchEvent(new Event('resize')); }catch(e){}
          }, ms);
        });
      }catch(e){}
      return true;
    }
    var hud=document.querySelector('#sc-home-widgets .ops-pill.b385');
    if(!hud) return false;                       /* page not ready - the caller retries */
    hud.classList.add('cg-ho-hud');

    var node=hud, chain=[];
    while(node && node!==document.body){ chain.push(node); node=node.parentElement; }
    var keep=new Set(chain);

    /* hide every sibling on the path up, and every body child that is not on it */
    chain.forEach(function(el){
      var p=el.parentElement; if(!p) return;
      [].forEach.call(p.children, function(sib){
        if(keep.has(sib)||skip(sib)) return;
        set(sib,'display','none');
      });
    });
    [].forEach.call(document.body.children, function(el){
      if(keep.has(el)||skip(el)) return;
      set(el,'display','none');
    });

    /* the ancestors give up their own box so the HUD can fill the window */
    chain.forEach(function(el){
      if(el===hud) return;
      set(el,'width','100%'); set(el,'height','100%');
      /* max-width:none was wrong - it let the tablet's own min-widths win and the HUD
         laid out at 1700px inside a 940px window. Cap to the window and allow shrink. */
      set(el,'max-width','100%'); set(el,'max-height','100%');
      set(el,'min-width','0'); set(el,'min-height','0');
      set(el,'margin','0'); set(el,'padding','0');
      set(el,'background','transparent'); set(el,'background-image','none');
      set(el,'border','0'); set(el,'box-shadow','none');
      set(el,'overflow','visible'); set(el,'box-sizing','border-box');
      set(el,'transform','none'); set(el,'flex','1 1 auto');
      /* v1.2.1: the tablet's per-tab zoom (.zoom-wrapper, sc_tab_zooms) survived the
         sweep and inflated the layout (MEASURED: 1700 -> 1889px in a 940px window,
         content clipped right - T's screenshot 3 AUG 2026). Ancestors carry no zoom
         in HUD-only; restore() already removes 'zoom'. */
      set(el,'zoom','1');
      /* .hm-cols is a GRID with fixed columns - width:100% on it does not make the one
         surviving child span the row, so the HUD stayed in a narrow left column at
         520px inside a 940px window. Forcing block layout on the ancestors is what
         actually lets the HUD fill. MEASURED before/after. */
      set(el,'display','block');
    });
    ['html','body'].forEach(function(sel){
      var e=document.querySelector(sel); if(!e) return;
      set(e,'background','transparent'); set(e,'background-image','none');
      set(e,'margin','0'); set(e,'padding','0'); set(e,'overflow','hidden');
      set(e,'width','100%'); set(e,'height','100%');
      /* the tablet's FIT pass puts a zoom on <html> (measured 1.456 at 2600px wide).
         Leave it on and "width:100%" resolves against a scaled box - the HUD came out
         2067px wide inside a 940px window. HUD-only sizes itself, so the zoom goes. */
      set(e,'zoom','1');
      /* v1.2.1: min-width BEATS width - the scrail-open classes hold a min-width on
         body, so width:100% !important still measured 1700px in a 940px window.
         Pin the floor and ceiling too; restore() already removes both. */
      set(e,'min-width','0'); set(e,'max-width','100%');
    });

    /* CG767_BODYCAP - ONE OWNER for body's width in HUD-only. RULE 43 / CLASS I / CLASS V.
       MEASURED on T's glass 12 AUG 2026 off /diag, ovlBuild CG767_PILLPROBE 20260812-3:
         window 3100x1380   html zoom 0.5  -> local viewport 6200x2760 (grips read 6160,2720)
         body INLINE max-width 2100px      <- SC-FIT, CmdGlas_PERSONAL.html, literal CAP=2100
         #sc-home-widgets 0-2100 ; pill local 1167x1533 ; 1167 x 1.8 = 2100.6 ; 1533.3 x 1.8 = 2760
         => the pill fills its parent EXACTLY. width:100% resolves THROUGH zoom. The zoom is
            not the cap and never was. The PARENT is capped, by body.
         => glass 1050 x 1380 real px inside a 3100 px window, 2050 px empty to the right
         => viewBox 2260x920 (2.456) painted into 0.76 = 3.22x vertical stretch, which is
            'formatting is wrong' / 'not on the same rail' / 'too far apart'.
       WHY A STYLESHEET AND NOT A STRONGER INLINE. SC-FIT assigns
       body.style.maxWidth = wDesign+'px' - a NORMAL inline declaration, and that
       assignment replaces whatever priority was there, so inline !important loses to it
       by ORDER. An author !important rule in a stylesheet outranks a NORMAL inline
       declaration in the cascade, so it cannot be replaced by that assignment at all.
       No timer, no MutationObserver, nothing re-created - RULE 17 stays intact.
       Scoped to html.cg-hudonly so it un-applies itself on dock, nothing to restore (RULE 8).
       REVERSIBLE: delete this block and the _wo line in restore(). */
    try{
      var _wo=document.getElementById('cg-ho-widthowner');
      if(!_wo){
        _wo=document.createElement('style'); _wo.id='cg-ho-widthowner';
        /* CG767_LISTDRAG - THE LIST IS NOT FURNITURE. CLASS C #7, third instance.
           MEASURED: CG767_WHEEL published wheel:null after a real roll on T's glass,
           so document never saw the event. CmdGlas_PERSONAL.html:44050 puts
           -webkit-app-region:drag on the whole pill and its own CAUTION says a drag
           region swallows clicks. Its carve-out list and CG767_NODRAG's between them
           name button, input, select, textarea, a, .ops4-tab, .ops4-tabs, .cg-hs-wrap,
           .cg-hs-panel, .cg-tw-bar, .cg-clr-wrap, #cg-b708, .cg767-hit, .cg-clr-btn,
           .cg-mirror. .ops4-body is in NEITHER. CG767_NODRAG claims ONE OWNER and it
           enumerated CONTROLS - the list is not a control, so it missed silently.
           Carved out by SUBTREE, not by naming the members, so a row type added later
           cannot miss it the way this one did.
           GATE Y, STATED: grabbing the MIDDLE OF THE LIST will no longer drag the
           window. Empty glass outside the list and the top drag strip still do.
           REVERSIBLE: delete the two appended lines. */
        _wo.textContent='html.cg-hudonly body{max-width:none !important;min-width:0 !important;'
          +'margin-left:0 !important;margin-right:0 !important;width:100% !important}'
          +'html.cg-hudonly .ops4-body,html.cg-hudonly .ops4-body *'
          +'{-webkit-app-region:no-drag !important}';
        (document.head||document.documentElement).appendChild(_wo);
      }
    }catch(e){}
    /* and the HUD itself becomes the window */
    /* CG767_HUDZOOM - T, 12 AUG 2026: dragged the corner to 3091 wide and the
       glass did not move one pixel. MEASURED off /diag, the whole chain:
         .wg.ops-pill    h 1531  zoom 1.8     <- the pill
         #sc-home-widgets h 2756 zoom 1
         hm-col/hm-cols/hm-wrap/#home-scroll  h 2756  zoom 1
       Every ancestor is neutralised to zoom 1 by the loop above and fills the
       window. The pill is skipped by that loop and this block never set zoom,
       so it kept the tablet per-tab zoom from sc_tab_zooms. width:100% then
       resolves inside a 1.8x box and cannot fill. Same fault the v1.2.1 note
       above says it fixed for ancestors, one element short. CLASS C.
       Also the whole of the anisotropy: viewBox 2260x920 (ratio 2.456) painted
       into 1167x1531 (ratio 0.762) is a 3.22x vertical stretch.
       restore() already removes zoom, so dock is unchanged. */
    set(hud,'zoom','1');
    set(hud,'width','100%'); set(hud,'height','100%');
    set(hud,'min-width','0'); set(hud,'max-width','100%');
    set(hud,'min-height','0'); set(hud,'max-height','100%');
    set(hud,'overflow','hidden');
    /* v1.2.5 - replaces the flat zoom pin: scale the HUD's writing WITH the window.
       470px of window height = design size; clamped so a huge monitor gets at most
       1.8x. Layout still fits: everything above is width:100% + min-width:0. */
    var __z=Math.max(1, Math.min(1.8, Math.round(window.innerHeight/470*100)/100));
    set(hud,'zoom',String(__z));
    /* CG767_WHEEL - THE LIST SCROLLS. CLASS C / CLASS D / RULE 7 / RULE 33.
       THE TABLET ALREADY CARRIES THIS FIX AND IT CANNOT REACH THE HUD. Its own
       comment, CmdGlas_PERSONAL.html:9617, states the engine behaviour:
         'Chrome will not wheel-scroll an element that has BOTH zoom!=1 and
          overflow unless the cursor is over the scrollbar.'
       Its handler then bails on line 3: e.target.closest('.zoom-wrapper').
       MEASURED on T's glass, CG767_LISTPROBE 20260812-5, pointer over the list:
         stack SPAN.cg-loc-txt | DIV.cg-loc-wrap | DIV.ops4-row | DIV.ops4-body
               | DIV.pill-body | DIV.wg ops-pill b385
         reachesBody TRUE, hitsGrip FALSE, hitsZone FALSE, chain z 1.35
       There is NO .zoom-wrapper in the HUD-only chain, so the tablet's fix never
       runs here. The guard is anchored to a CLASS NAME; the condition it is
       guarding is a PROPERTY. That is RULE 7 and it is why this is discovered by
       walking for overflowY + scrollHeight instead of naming an element.
       RULE 33 - deltaY arrives in painted px and scrollTop is the element's own
       local px, so the delta is divided by the scroller's live zoom chain. The
       divisor is NOT chosen: CG767_WHEEL publishes dy, z, before, after and moved
       into /diag so the ratio is read off his machine rather than asserted.
       NARROW BY CONSTRUCTION (GATE Y): HUD-only only, never when something else
       already handled the event, only a scroller INSIDE the pill, and
       preventDefault only when the list actually moved. Installed once, no timer,
       nothing re-created - RULE 17. REVERSIBLE: delete this block. */
    try{
      if(!window.__cg767wheel){
        window.__cg767wheel=1; window.CG767_WHEEL=null;
        document.addEventListener('wheel',function(ev){
          try{
            if(ev.defaultPrevented) return;
            if(!document.documentElement.classList.contains('cg-hudonly')) return;
            var pill=document.querySelector('#sc-home-widgets .ops-pill.b385'); if(!pill) return;
            var n=ev.target, sc=null;
            while(n && n.nodeType===1){
              var oy=getComputedStyle(n).overflowY;
              if((oy==='auto'||oy==='scroll') && n.scrollHeight>n.clientHeight+1){ sc=n; break; }
              if(n===pill) break;
              n=n.parentElement;
            }
            if(!sc || !pill.contains(sc)) return;
            var z=1,q=sc;
            while(q && q.nodeType===1){ var v=parseFloat(getComputedStyle(q).zoom); if(v&&v>0) z*=v; q=q.parentElement; }
            var before=sc.scrollTop;
            sc.scrollTop = before + ev.deltaY/(z||1);
            var after=sc.scrollTop;
            window.CG767_WHEEL={dy:ev.deltaY,z:z,before:Math.round(before),after:Math.round(after),
              moved:Math.round(after-before),max:sc.scrollHeight-sc.clientHeight,
              sc:String(sc.className||sc.id||sc.tagName).slice(0,40)};
            if(after!==before) ev.preventDefault();
          }catch(e){ try{ window.CG767_WHEEL={err:String(e.message).slice(0,90)}; }catch(_){} }
        },{passive:false});
      }
    }catch(e){}
    set(hud,'margin','0'); set(hud,'padding','8px 10px');
    set(hud,'box-sizing','border-box');
    /* THE SLAB. T: "rounded, no triangles, only a smooth tablet that seems to be
       rising out of the screen."

       RISING IS A LIGHT DIRECTION, NOT A SHAPE. A projector sits below and the beam
       weakens as it climbs, so the frame is BRIGHTEST ALONG THE BOTTOM EDGE and fades
       out toward the top, and light pools on the surface underneath it. A uniform
       outline reads as a sticker; a graded one reads as emitted.

       HOW THE GRADED EDGE IS DRAWN. CSS has no gradient border, so this uses the two
       background trick: the first background is clipped to the PADDING box (the
       interior, kept almost clear) and the second to the BORDER box (the ring). The
       ring is a to-top gradient, so the bottom of the frame is full brightness and the
       top is nearly gone.

       It is set INLINE because the sweep above writes background:transparent inline on
       this same element, and a stylesheet rule cannot beat that. */
    /* THE RING IS A PLAIN BORDER NOW.
       The first version used the two-background gradient-border trick (one layer
       clipped to padding-box, one to border-box) so the frame could be brighter at
       the bottom. MEASURED: background-clip did not take through setProperty, so the
       to-top gradient painted the WHOLE panel instead of just the ring - which is the
       cyan wash across the bottom half that T saw twice. A uniform ring cannot fail
       that way, and the "rising" read comes from the emitter below, where it belongs. */
    set(hud,'background','transparent');
    set(hud,'background-image','none');
    /* v1.2.2 - T: "no outlines, not even the line around the entire tablet".
       The ring is gone; the b701 tablet block draws the light. */
    set(hud,'border','0');
    set(hud,'border-radius','26px');
    /* T: "why is the bottom so bright. where is the 3d effect of the tablet rising
       out of the screen."

       THE BRIGHT BAR WAS WRONG AND HERE IS WHY. It was a hard 2px line under the
       whole width - a bar, with ends. A projector does not put a bar under a
       hologram; it puts a POOL, brightest under the middle and gone by the corners.
       So the hard line is deleted and an emitter is drawn instead (below), narrower
       than the slab and elliptical, so it has no ends to be square.

       AND THE 3D. A glow is not depth. Depth is PERSPECTIVE - the top of the slab
       has to be further away than the bottom. rotateX tilts it back a few degrees so
       the top edge recedes, which is what "rising out of the screen" actually looks
       like. 4 degrees is small on purpose: past about 7 the text starts to smear on
       a flat panel. */
    /* NO INSET GLOW. The first attempt put one on the inside bottom edge and it
       washed out the lower HALF of the panel - T: "why is the bottom so bright."
       MEASURED on the render: the wash reached roughly 45% up the slab. A hologram's
       light comes from its own strokes, not from a lamp inside the frame. What is
       left is an outer halo and a pool cast downward, and nothing at all on the
       inside face. */
    set(hud,'box-shadow','none');   /* v1.2.2: no halo either - no shape */
    set(hud,'transform','perspective(1400px) rotateX(4deg)');
    set(hud,'transform-origin','50% 100%');

    /* AND EVERYTHING INSIDE IT. The panels within the HUD paint their own fills from
       id-based rules (#sc-home-widgets .ops-pill.b385 .pill-body{...}) which no class
       rule can beat - MEASURED: alpha 232 out of 255 in the middle of the HUD with
       the stylesheet version of these rules in place. So the sweep is done here, in
       inline styles, on whatever is actually painting.
       The ACTIVE TAB is left alone on purpose: "which tab am I on" has to survive, and
       it is the one filled thing worth keeping. */
    /* NOTE the sweep runs over hud.querySelectorAll('*') - DESCENDANTS only. The HUD
       itself is styled above and is deliberately not in that list, or the slab's own
       gradient edge would be cleared by the very next line. */
    hud.querySelectorAll('*').forEach(function(el){
      if(el.classList && el.classList.contains('ops4-tab') && el.classList.contains('on')) return;
      if(el.closest && el.closest('.cg-hs-panel')) return;   /* the settings panel stays readable */
      if(/^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName)) return; /* v1.2.2: b701 lights these */
      var cs=getComputedStyle(el);
      if(cs.backgroundColor && cs.backgroundColor!=='rgba(0, 0, 0, 0)') set(el,'background','transparent');
      if(cs.backgroundImage && cs.backgroundImage!=='none') set(el,'background-image','none');
      if(cs.boxShadow && cs.boxShadow!=='none') set(el,'box-shadow','none');
    });
    /* v1.2.15 - NO UNDOCK INSIDE THE HUD. T: "remove the close button and undock
       button from the hud."  MEASURED, because there are two of them and only one
       was already handled: button.cg-undock-btn is the v1.2.8 relabelled one and
       is display:none already, but button.cg-mirror.u is a SECOND, mirrored copy
       in the bottom control row - 41x12 at 6px type, the faint UNDOCK in T's
       screenshot. Hidden INLINE, not by stylesheet, because a class rule loses to
       the tablet's own id rules (RULE 18). set() marks it, so restore() puts it
       straight back the moment the tablet docks. */
    hud.querySelectorAll('.cg-mirror.u, .cg-undock-btn').forEach(function(el){
      set(el,'display','none');
    });
    /* THE EMITTER. A real element, not a border or a box-shadow, because both of
       those are rectangles that follow the box - they always have ends. This is an
       ellipse centred under the slab, 46% of its width, fading to nothing well before
       the corners. It is what the slab appears to be rising out of. */
    /* v1.2.2 - variant B approved: NO emitter pool. Remove any old one. */
    var base=document.getElementById('cg-ho-base');
    if(base){ base.remove(); base=null; }
    if(false){
    }
    /* v1.2.14 - THE SWEEP RUNS AFTER THE BADGE, AND IT ZEROES THE HUD'S MARGIN.
       MEASURED on the first v1.2.14 render: the badge was up but the HUD had not
       stepped down, so the amber bar sat across the tab row. The sweep writes
       margin:0 !important inline, which beats everything, so the step has to be
       re-asserted here - at the end of the pass that removed it. The strip has a
       stylesheet rule for the same job; inline is used here because inline is the
       only thing that outlives this sweep. */
    try{
      var _b=document.getElementById('cg-ovl-ctbadge');
      if(_b && _b.classList.contains('on') && window.__cgOvlCtBadge) window.__cgOvlCtBadge(true);
      /* v1.2.15 - the drag strip needs the same re-assert, and for the same
         reason. v1.2.5 gave it a 28px step so it would stop sitting on the tab
         row; the step was being LOST because this sweep writes margin:0 inline
         after __cgOvlDrag ran. MEASURED: strip at y16, GATHER & BUY at y34 -
         18px apart, which is half of what T is looking at when he says the two
         rows run together. Re-asserted here, at the end of the pass that
         removed it, exactly like the badge above. */
      var _d=document.getElementById('cg-ovl-drag');
      if(_d && _d.classList.contains('on') && window.__cgOvlDrag) window.__cgOvlDrag(true);
    }catch(e){}
    return true;
  };
  window.__cgHudOnlyReport=function(){
    var hud=document.querySelector('.cg-ho-hud');
    var r=hud?hud.getBoundingClientRect():null;
    return {on:document.documentElement.classList.contains('cg-hudonly'),
            hudFound:!!hud,
            hudSize:r?Math.round(r.width)+'x'+Math.round(r.height):null,
            hudTop:r?Math.round(r.top):null,
            touched:document.querySelectorAll('['+MARK+']').length,
            visibleWidgets:(function(){var n=0;
              document.querySelectorAll('#sc-home-widgets .wg').forEach(function(w){
                if(getComputedStyle(w).display!=='none') n++; }); return n;})(),
            cover:(function(){var c=document.getElementById('cover-screen');
              return c?getComputedStyle(c).display:'gone';})()};
  };
})();
`;

/* PT-005 — LIVE REPRODUCTION PASSED 29 AUG 2026.
   T confirmed the Personal HUD did not flash when its transparent native
   window was created hidden and revealed only after its real HUD was ready.
   This is deliberately restricted to the Personal HUD launcher: a normal
   tablet or Public HUD preserves its existing launch behavior. */
function revealPersonalHudAfterReady() {
  if (!personalHudInitialReveal || !win) return;
  const target = win;
  setTimeout(() => {
    if (!personalHudInitialReveal || !target || target.isDestroyed()) return;
    personalHudInitialReveal = false;
    try { target.show(); target.focus(); } catch (_) {}
  }, 1900);
}

/* PT-013 TEST — the rails are OPEN placement tracks, not a closed frame.
   This is deliberately test-flagged: it is live only when the disposable
   launcher passes --pt013-rails-test, only in Personal HUD-only mode, and it
   changes page-local visual dials only.  The original a private development tablet HTML
   stays untouched. */
const personalHudRailRestoreTest = process.argv.indexOf('--pt013-rails-test') >= 0;
function isPersonalHudOnly() {
  return !!(cfg && cfg.hudOnly && /CmdGlas_PERSONAL\.html(?:[?#]|$)/i.test(String(cfg.url || '')));
}
function applyPersonalHudRailRestoreTest() {
  if (!personalHudRailRestoreTest || !isPersonalHudOnly() || !win) return Promise.resolve({ skipped: true });
  const js = `(async function(){
    try {
      /* The Personal HUD builds after its tablet data.  Four seconds was not
         enough on this machine; wait up to twenty seconds and change nothing
         unless the real skin API is present. */
      for (let i=0; i<160 && !(window.__cgB767 && window.__cgB767.repaint && window.__cgB767.geometry); i++)
        await new Promise(resolve => setTimeout(resolve, 125));
      if (!(window.__cgB767 && window.__cgB767.repaint && window.__cgB767.geometry))
        return {applied:false, why:'hud-not-ready'};
      /* Keep the established borderless HUD: no closed frame and no mesh.
         The only added artwork is the separate open top/bottom tracks. */
      localStorage.setItem('cg767_outline','off');
      localStorage.setItem('cg767_meshon','0');
      window.__cgB767.repaint();
      await new Promise(resolve => setTimeout(resolve, 900));
      window.__cgB767.repaint();
      /* One visual surface owns every test rail.  These helpers deliberately
         use the same inner-frame geometry that the Personal HUD publishes.
         A rail may live at a different depth, but it must never invent a
         second curve family.  The end-to-centre scale is the HUD's own
         perspective law: 1.0 at each end and smaller at the centre. */
      var railSpec = function(g, side){
        var top = side === 'top', x0 = +g.IX0 || +g.X0, x1 = +g.IX1 || +g.X1;
        var ye = top ? +g.IT_E : +g.IB_E, yc = top ? +g.IT_C : +g.IB_C;
        return {x0:x0, x1:x1, ye:ye, yc:yc};
      };
      var railPoint = function(g, side, x){
        var s=railSpec(g,side), t=(x-s.x0)/(s.x1-s.x0);
        if(t<0)t=0; if(t>1)t=1;
        var d=s.yc-s.ye, y=s.ye+4*t*(1-t)*d;
        return {x:x, y:y, angle:Math.atan2(4*d*(1-2*t),s.x1-s.x0)*180/Math.PI, t:t};
      };
      var railPath = function(g, side){
        var s=railSpec(g,side), cx=(s.x0+s.x1)/2;
        return 'M'+s.x0+' '+s.ye+' Q'+cx+' '+(2*s.yc-s.ye)+' '+s.x1+' '+s.ye;
      };
       var railScale = function(g, t){
         /* One perspective law.  The Personal HUD defines a 28% end-to-crown
            reduction; the previous test's 12% cap removed the visible curve.
            Do not reset or soften this value for a compact label. */
         var sourceAmount=isFinite(+g.PERSP_AMOUNT)?+g.PERSP_AMOUNT:.28;
         var amount=Math.min(.28,Math.max(0,sourceAmount));
        var power=isFinite(+g.PERSP_POWER)?+g.PERSP_POWER:.85;
        if(t<0)t=0; if(t>1)t=1;
        return 1-amount*Math.pow(4*t*(1-t),power);
      };
      /* A row's centre selects its depth on one continuous HUD surface.
         At the top and bottom boundaries this resolves exactly to the same
         published inner curves; rows between them interpolate the bow instead
         of choosing a separate curve family. */
       var surfacePoint = function(g, x, yCentre){
        var s=railSpec(g,'top'), t=(x-s.x0)/(s.x1-s.x0);
        if(t<0)t=0; if(t>1)t=1;
        var topAmp=(+g.IT_C)-(+g.IT_E), bottomAmp=(+g.IB_C)-(+g.IB_E);
        var depth=(yCentre-(+g.IT_C))/((+g.IB_C)-(+g.IT_C));
        if(depth<0)depth=0; if(depth>1)depth=1;
        var amp=topAmp+(bottomAmp-topAmp)*depth, f=4*t*(1-t);
        return {x:x, y:yCentre+(f-1)*amp,
           angle:Math.atan2(4*amp*(1-2*t),s.x1-s.x0)*180/Math.PI, t:t};
       };
       /* A compact HUD label is a projected segment of the same published
          surface, not a flat word with a vertical offset.  Its individual
          letters therefore sample the full rail parameter from 0 through 1.
          The compact on-screen x positions remain measured from the real
          control box; y, angle, and scale come from this shared rail only. */
       var wordSurfacePoint = function(g, yCentre, u){
         var s=railSpec(g,'top'), t=isFinite(+u)?+u:.5;
         if(t<0)t=0; if(t>1)t=1;
         return surfacePoint(g,s.x0+(s.x1-s.x0)*t,yCentre);
       };
      /* cg767-fr deliberately fills the live window with preserveAspectRatio
         none.  At the user's HUD dimensions that means an SVG glyph is squeezed
         horizontally.  Correct each glyph locally before the frame performs
         its non-uniform scale, so the screen sees a uniformly scaled Michroma
         character and the rail tangent remains a real tangent rather than a
         ladder of vertically displaced words. */
       var drawSurfaceRun = function(host, label, centreX, centreY, size, g, projection){
         var ns='http://www.w3.org/2000/svg', font='cg767-michroma-test,Michroma,sans-serif';
         projection=projection||{};
         var glyphXComp=isFinite(+projection.glyphXComp)&&+projection.glyphXComp>0?+projection.glyphXComp:1;
         var bendStrength=isFinite(+projection.bendStrength)?Math.max(0,Math.min(1,+projection.bendStrength)):.45;
        var run=document.createElementNS(ns,'g');
        run.setAttribute('data-pt013-rail-run',label);
        host.appendChild(run);
        var probe=document.createElementNS(ns,'text');
        probe.setAttribute('font-family',font); probe.setAttribute('font-weight','400');
        /* The Personal tablet ends with a global Bruno Ace !important rule
           that reaches SVG text too.  SVG presentation attributes lose to
           that rule, so the test must make Michroma an inline-important
           instruction on both its measuring probe and painted glyphs. */
        probe.style.setProperty('font-family',font,'important');
        probe.style.setProperty('font-weight','400','important');
        probe.style.setProperty('font-style','normal','important');
        probe.setAttribute('visibility','hidden'); probe.setAttribute('x','-10000'); probe.setAttribute('y','-10000');
        host.appendChild(probe);
         var letterSpace=size*.06, widths=[], start=centreX, pass, i, glyphCount=Math.max(1,label.length-1);
         for(pass=0;pass<3;pass++){
           var cursor=start, total=0;
           widths=[];
           for(i=0;i<label.length;i++){
             var wordPoint=wordSurfacePoint(g,centreY,i/glyphCount), glyphSize=size*railScale(g,wordPoint.t), w;
            probe.setAttribute('font-size',glyphSize.toFixed(2));
            probe.style.setProperty('font-size',glyphSize.toFixed(2)+'px','important');
            probe.textContent=label.charAt(i);
            try{ w=probe.getComputedTextLength(); }catch(_mw){ w=0; }
            if(!isFinite(w)||w<=0) w=glyphSize*(label.charAt(i)===' '?0.36:0.62);
            /* The correction group widens the glyph after this measurement,
               so include it here too.  Otherwise letters would regain their
               proper proportions but collide into one another. */
            w *= glyphXComp;
            w += i<label.length-1 ? letterSpace*glyphXComp*railScale(g,point.t) : 0;
            widths.push(w); cursor+=w; total+=w;
          }
          start=centreX-total/2;
         }
         probe.remove();
         var x=start;
         for(i=0;i<label.length;i++){
           var ch=label.charAt(i), w2=widths[i], drawX=x+w2/2,
             p=wordSurfacePoint(g,centreY,i/glyphCount), glyph=size*railScale(g,p.t),
             y=centreY+(p.y-centreY)*bendStrength, angle=p.angle*bendStrength;
           if(ch!==' '){
            /* SVG applies the child rotation first, then the parent correction.
               The frame's X squeeze times this local X expansion equals its
               Y scale, leaving the finished letter proportional and angled
               exactly along this point of the rail. */
             var correct=document.createElementNS(ns,'g');
             correct.setAttribute('transform','translate('+drawX.toFixed(2)+' 0) scale('+glyphXComp.toFixed(5)+' 1) translate('+(-drawX).toFixed(2)+' 0)');
             var node=document.createElementNS(ns,'text');
             node.textContent=ch; node.setAttribute('x',drawX.toFixed(2));
             node.setAttribute('y',(y+glyph*.35).toFixed(2)); node.setAttribute('text-anchor','middle');
             /* Lit colour is constant.  Perspective changes geometry only;
                a font-size-dependent opacity made smaller letters look dim. */
             node.setAttribute('fill','rgb(0,229,255)'); node.setAttribute('fill-opacity','1');
            node.setAttribute('font-family',font); node.setAttribute('font-size',glyph.toFixed(2)); node.setAttribute('font-weight','400');
            node.style.setProperty('font-family',font,'important');
            node.style.setProperty('font-size',glyph.toFixed(2)+'px','important');
            node.style.setProperty('font-weight','400','important');
            node.style.setProperty('font-style','normal','important');
             node.setAttribute('transform','rotate('+angle.toFixed(3)+' '+drawX.toFixed(2)+' '+y.toFixed(2)+')');
            correct.appendChild(node);
            run.appendChild(correct);
          }
          x+=w2;
        }
      };
      var renderOptionHeader = function(force){
        var fr2 = document.getElementById('cg767-fr'); if (!fr2) return;
        var menu1 = document.getElementById('cg767-menu'), menu2 = document.getElementById('cg767-menu2');
        var findHeader = function(menu, words){
          if (!menu) return null;
          return [].slice.call(menu.querySelectorAll('.cg767-hdr')).filter(function(e){ return (e.textContent||'').trim().toUpperCase()===words; })[0] || null;
        };
        var h1 = findHeader(menu1,'HUD CONTROLS'), h2 = findHeader(menu2,'TABLET CONTROLS');
        var isOpen=function(menu){ return !!(menu && getComputedStyle(menu).display!=='none'); };
        var active = isOpen(menu1) ? h1 : (isOpen(menu2) ? h2 : null);
        if (h1) h1.style.setProperty('visibility','hidden','important');
        if (h2) h2.style.setProperty('visibility','hidden','important');
        var old = fr2.querySelector('#cg767-pt013-option-header');
        fr2.style.setProperty('visibility',active?'visible':'hidden','important');
        if (!active) { if (old) old.remove(); return; }
        var label = (active.textContent||'').trim().toUpperCase();
        if (old && old.getAttribute('data-label')===label && !force) return;
        if (old) old.remove();
        var g = window.__cgB767.geometry;
        var rr = fr2.getBoundingClientRect(), cs = getComputedStyle(active);
        var sx=rr.width/g.VW, sy = rr.height/g.VH, size = Math.max(16,Math.min(42,(parseFloat(cs.fontSize)||16)/(sy||1)));
         var projection={glyphXComp:(sy||1)/(sx||1),bendStrength:1};
        /* Keep the heading in its real menu lane, then curve that lane.  The
           prior fixed top-rail placement was what pulled HUD CONTROLS into the
           page-row text in the user's screenshot. */
        var ar=active.getBoundingClientRect();
        var centreX=((ar.left+ar.width/2-rr.left)/rr.width)*g.VW;
        var centreY=((ar.top+ar.height/2-rr.top)/rr.height)*g.VH;
        var ns = 'http://www.w3.org/2000/svg', host = document.createElementNS(ns,'g');
        host.setAttribute('id','cg767-pt013-option-header'); host.setAttribute('data-label',label); host.setAttribute('pointer-events','none');
        fr2.appendChild(host);
        drawSurfaceRun(host,label,centreX,centreY,size,g,projection);
      };
      /* Keep source labels in the DOM for their real actions, but make their
         entire paint tree inert.  Opacity is the final backstop: it suppresses
         even a future clipped gradient or pseudo layer without disabling hit
         testing on the original button. */
      var suppressSourceInk = function(ink){
        if(!ink||!ink.style)return;
        var rules=[
          ['color','transparent'],['-webkit-text-fill-color','transparent'],
          ['background','none'],['background-image','none'],['background-clip','border-box'],
          ['-webkit-background-clip','border-box'],['text-shadow','none'],
          ['-webkit-text-stroke','0 transparent'],['filter','none']
        ];
        /* Main menu buttons retain their own hit box.  Their child label span
           is separately marked and receives opacity zero; direct lower-strip
           buttons use the dedicated proxy hits created by this test. */
        if(!(ink.matches&&ink.matches('.cg767-it')))rules.push(['opacity','0']);
        var needs=rules.some(function(rule){return ink.style.getPropertyValue(rule[0])!==rule[1]||ink.style.getPropertyPriority(rule[0])!=='important';});
        if(!needs)return;
        rules.forEach(function(rule){ink.style.setProperty(rule[0],rule[1],'important');});
      };
      /* The visible controls in the two see-through HUD menus are DOM text,
         not source rail glyphs.  Redraw only those overlay-owned labels on the
         shared surface and leave their original clickable elements in place.
         Tablet pages, .pill-body, and all general page copy are excluded. */
      var renderMenuTextSurface = function(){
        var fr2=document.getElementById('cg767-fr'); if(!fr2) return;
        var menus=['cg767-menu','cg767-menu2'].map(function(id){return document.getElementById(id);})
          .filter(function(m){return m&&getComputedStyle(m).display!=='none';});
        var old=fr2.querySelector('#cg767-pt013-menu-surface');
        if(!menus.length){ if(old)old.remove(); return; }
        fr2.style.setProperty('visibility','visible','important');
        if(old)old.remove();
        var ns='http://www.w3.org/2000/svg', host=document.createElementNS(ns,'g'), rr=fr2.getBoundingClientRect();
        host.setAttribute('id','cg767-pt013-menu-surface'); host.setAttribute('pointer-events','none');
        fr2.appendChild(host);
        var g=window.__cgB767.geometry, sx=rr.width/g.VW, sy=rr.height/g.VH, targets=[], lowerControls=[];
         var projection={glyphXComp:(sy||1)/(sx||1),bendStrength:.45};
        menus.forEach(function(menu){
          [].slice.call(menu.querySelectorAll('.cg767-it,#cg-ovl-drag > *,.cg767-sech,.cg767-setlab,.cg767-setopt'))
            .forEach(function(el){ if(targets.indexOf(el)<0)targets.push(el); });
        });
        /* The five bottom controls are a sibling strip, not descendants of
           cg767-menu.  Include that real strip explicitly; querying from the
           menu alone misses it and leaves the old squeezed source ink behind. */
        [].slice.call(document.querySelectorAll('#cg-ovl-drag > *')).forEach(function(el){
          if(targets.indexOf(el)<0)targets.push(el);
        });
        /* The final five menu controls were authored as an 8px source stack.
           That is smaller than a single 16px label, so copying its centres
           makes the visual overlap by construction.  Give only those overlay
           controls a readable, evenly pitched display lane.  Their original
           DOM stays where it is; matching transparent proxy buttons below
           retain interaction at the new visible positions. */
        targets.forEach(function(el){
          if(!(el.matches && el.matches('#cg-ovl-drag > *')))return;
          var lr=el.getBoundingClientRect(), lcs=getComputedStyle(el);
          var ll=(el.innerText||el.textContent||'').replace(/\s+/g,' ').trim();
          if(ll&&lr.width>=2&&lr.height>=2&&lcs.display!=='none'&&lcs.visibility!=='hidden')lowerControls.push(el);
        });
        lowerControls.sort(function(a,b){return a.getBoundingClientRect().top-b.getBoundingClientRect().top;});
        var upperRows=targets.filter(function(el){return !(el.matches&&el.matches('#cg-ovl-drag > *')) && el.matches&&el.matches('.cg767-it');});
        /* The overlay strip's native type is Rajdhani 800 at 10px while the
           real HUD list is its own 15px display face.  Read one healthy list
           item as the source of truth, then render the five strip labels with
           that exact visual scale rather than inheriting the strip's unrelated
           window-manager typography. */
        var menuReferenceSize=0;
        upperRows.some(function(el){
          var ur=el.getBoundingClientRect(), ucs=getComputedStyle(el), us=(parseFloat(ucs.fontSize)||0)/(sy||1);
          if(ur.width>=2&&ur.height>=2&&us>0){menuReferenceSize=us;return true;} return false;
        });
        var upperPitch=0;
        if(upperRows.length>1){
          var upperYs=upperRows.map(function(el){var r=el.getBoundingClientRect();return r.top+r.height/2;}).sort(function(a,b){return a-b;});
          var gaps=[]; for(var ug=1;ug<upperYs.length;ug++){var gap=upperYs[ug]-upperYs[ug-1];if(gap>2)gaps.push(gap);}
          if(gaps.length){gaps.sort(function(a,b){return a-b;});upperPitch=gaps[Math.floor(gaps.length/2)]/(sy||1);}
        }
        /* 38 design units is a 20px screen pitch at the test's current
           height.  It is also never allowed to be tighter than the existing
           healthy HUD menu rhythm if that rhythm is larger. */
        var lowerPitch=Math.max(38,menuReferenceSize*1.35,upperPitch||0);
        var lowerLayout=[];
        if(lowerControls.length){
          var firstRect=lowerControls[0].getBoundingClientRect();
          var firstY=((firstRect.top+firstRect.height/2-rr.top)/rr.height)*g.VH;
          lowerControls.forEach(function(el,index){lowerLayout[index]={index:index,centreY:firstY+index*lowerPitch,pitch:lowerPitch};});
        }
        var hitRows=[], menuHitRows=[];
        targets.forEach(function(el){
          var rect=el.getBoundingClientRect(), cs=getComputedStyle(el);
          var label=(el.innerText||el.textContent||'').replace(/\s+/g,' ').trim();
          if(!label||rect.width<2||rect.height<2||cs.display==='none'||cs.visibility==='hidden')return;
          /* Keep controls functional: erase only their DOM ink, never hide or
             move the real button.  The SVG clone cannot receive input. */
          /* The original HUD type often paints through a gradient background
             clipped to the glyphs.  Transparent color alone leaves that
             gradient visible, producing the double text the user reported. */
          [el].concat([].slice.call(el.querySelectorAll('*'))).forEach(function(ink){
            ink.setAttribute('data-pt013-surface-ink','1');
            suppressSourceInk(ink);
          });
          var cx=((rect.left+rect.width/2-rr.left)/rr.width)*g.VW;
          var lowerIndex=lowerControls.indexOf(el);
          var layout=lowerIndex>=0?lowerLayout[lowerIndex]:null;
          var cy=layout?layout.centreY:((rect.top+rect.height/2-rr.top)/rr.height)*g.VH;
          var sourceSize=Math.max(8,Math.min(42,(parseFloat(cs.fontSize)||10)/(sy||1)));
          var size=layout&&menuReferenceSize?menuReferenceSize:sourceSize;
          drawSurfaceRun(host,label,cx,cy,size,g,projection);
          if(layout)hitRows.push({el:el,cx:cx,cy:cy,pitch:layout.pitch,label:label});
          else if(el.matches&&el.matches('.cg767-it'))menuHitRows.push({el:el,rect:rect,label:label});
        });
        /* A visual control must be clickable where it is drawn.  These targets
           forward only to the original button; they do not alter tablet pages
           or normal overlay input, and exist solely in this test window. */
        var oldHits=[].slice.call(document.querySelectorAll('[data-pt013-lower-hit="1"]'));
        oldHits.forEach(function(hit){hit.remove();});
        hitRows.forEach(function(row,index){
          var point=surfacePoint(g,row.cx,row.cy), width=Math.max(190,row.label.length*22);
          var hit=document.createElement('button'); hit.type='button'; hit.setAttribute('data-pt013-lower-hit','1');
          hit.setAttribute('aria-label',row.label); hit.id='cg767-pt013-lower-hit-'+index;
          hit.style.cssText='position:fixed;display:block;padding:0;margin:0;border:0;background:transparent;box-shadow:none;opacity:0;z-index:2147482990;pointer-events:auto;-webkit-app-region:no-drag;cursor:pointer;';
          hit.style.left=Math.round(rr.left+(row.cx-width/2)/g.VW*rr.width)+'px';
          hit.style.top=Math.round(rr.top+(point.y-row.pitch*.42)/g.VH*rr.height)+'px';
          hit.style.width=Math.round(width/g.VW*rr.width)+'px';
          hit.style.height=Math.max(14,Math.round(row.pitch*.84/g.VH*rr.height))+'px';
          hit.addEventListener('click',function(ev){ev.preventDefault();ev.stopPropagation();try{row.el.click();}catch(_pt013){}},true);
          document.body.appendChild(hit);
        });
        /* The source main-menu buttons sit beneath the transparent HUD frame
           and do not win its native hit test.  Give each visible curved word a
           same-size proxy that forwards only to that original button. */
        [].slice.call(document.querySelectorAll('[data-pt013-menu-hit="1"]')).forEach(function(hit){hit.remove();});
        menuHitRows.forEach(function(row,index){
          var hit=document.createElement('button'); hit.type='button'; hit.setAttribute('data-pt013-menu-hit','1');
          hit.setAttribute('aria-label',row.label); hit.id='cg767-pt013-menu-hit-'+index;
          hit.style.cssText='position:fixed;display:block;padding:0;margin:0;border:0;background:transparent;box-shadow:none;opacity:0;z-index:2147482985;pointer-events:auto;-webkit-app-region:no-drag;cursor:pointer;';
          hit.style.left=Math.round(row.rect.left)+'px'; hit.style.top=Math.round(row.rect.top)+'px';
          hit.style.width=Math.max(1,Math.round(row.rect.width))+'px'; hit.style.height=Math.max(1,Math.round(row.rect.height))+'px';
          hit.addEventListener('click',function(ev){ev.preventDefault();ev.stopPropagation();try{row.el.click();}catch(_pt013menu){}},true);
          document.body.appendChild(hit);
        });
      };
      /* The two visual dots are only 8px wide after the overlay's zoom chain.
         Their DOM boxes do not participate in the browser hit-test on this
         transparent window, so give each dot a transparent, non-drag click
         target and forward only that press to its original button. */
      var installDotHitTargets = function(){
        [['cg767-chev','cg767-pt013-dot-hit-left'],['cg767-chev2','cg767-pt013-dot-hit-right']].forEach(function(pair){
          var dot=document.getElementById(pair[0]); if(!dot)return;
          var zone=document.getElementById(pair[1]);
          if(!zone){
            zone=document.createElement('button'); zone.type='button'; zone.id=pair[1];
            zone.setAttribute('aria-label',pair[0]==='cg767-chev'?'Open HUD Controls':'Open Tablet Controls');
            zone.style.cssText='position:fixed;display:block;padding:0;margin:0;border:0;background:transparent;box-shadow:none;opacity:0;z-index:2147483000;pointer-events:auto;-webkit-app-region:no-drag;cursor:pointer;';
            zone.addEventListener('click',function(ev){
              ev.preventDefault(); ev.stopPropagation(); try{dot.click();}catch(_d){}
              setTimeout(function(){try{window.__cg767PT013RenderSurfaceStable(true);}catch(_rs){}},0);
            },true);
            document.body.appendChild(zone);
          }
          var r=dot.getBoundingClientRect(), split=(pair[0]==='cg767-chev');
          /* Zones meet at the screen centre but never overlap: left/right
             dots retain distinct actions even on a fractional zoom. */
          var mid=(document.getElementById('cg767-chev').getBoundingClientRect().left+document.getElementById('cg767-chev').getBoundingClientRect().width/2+document.getElementById('cg767-chev2').getBoundingClientRect().left+document.getElementById('cg767-chev2').getBoundingClientRect().width/2)/2;
          var left=split?Math.max(0,r.left-10):mid;
          var right=split?mid:Math.min(window.innerWidth,r.right+10);
          zone.style.left=Math.round(left)+'px'; zone.style.top=Math.round(Math.max(0,r.top-10))+'px';
          zone.style.width=Math.max(1,Math.round(right-left))+'px'; zone.style.height=Math.round(r.height+20)+'px';
        });
      };
      window.__cg767PT013RenderOptionHeader = renderOptionHeader;
      window.__cg767PT013RenderMenuTextSurface = renderMenuTextSurface;
      window.__cg767PT013InstallDotHitTargets = installDotHitTargets;
      /* The Personal HUD's own label script can restore an inline gradient
         after a menu opens.  With background-clip:text that gradient remains
         visible even when the text colour is transparent, creating the exact
         two-layer word the user reported.  This persistent test-only cascade
         guard wins over the normal inline write while leaving the real button
         and its action completely intact. */
      var installSourceInkGuard = function(){
        var guard=document.getElementById('cg767-pt013-source-ink-guard');
        if(guard)return;
        guard=document.createElement('style'); guard.id='cg767-pt013-source-ink-guard';
        guard.textContent='[data-pt013-surface-ink="1"],[data-pt013-surface-ink="1"]::before,[data-pt013-surface-ink="1"]::after{'
          +'color:transparent !important;-webkit-text-fill-color:transparent !important;'
          +'opacity:0 !important;'
          +'background:none !important;background-image:none !important;'
          +'background-clip:border-box !important;-webkit-background-clip:border-box !important;'
          +'text-shadow:none !important;-webkit-text-stroke:0 transparent !important;filter:none !important;}'
          +'[data-pt013-surface-ink="1"].cg767-it{opacity:1 !important;}';
        (document.head||document.documentElement).appendChild(guard);
      };
      /* The old 750ms loop rebuilt all glyphs whether anything had changed or
         not.  That needless repaint can read as type flicker on transparent
         glass.  Cache the actual frame/menu layout and redraw only when it
         changes, or immediately after one of the two HUD dots is pressed. */
      var renderSurfaceStable = function(force){
        var fr3=document.getElementById('cg767-fr'); if(!fr3)return;
        var rr3=fr3.getBoundingClientRect();
        var bits=[Math.round(rr3.width*10)/10,Math.round(rr3.height*10)/10];
        ['cg767-menu','cg767-menu2'].forEach(function(id){
          var m=document.getElementById(id); if(!m){bits.push(id,'missing');return;}
          var mr=m.getBoundingClientRect();
          bits.push(id,getComputedStyle(m).display,Math.round(mr.left*10)/10,Math.round(mr.top*10)/10,Math.round(mr.width*10)/10,Math.round(mr.height*10)/10);
        });
        /* The HUD builds menu buttons asynchronously after the panel itself
           becomes visible.  Include that real label set in the signature so
           the test paints once when the words arrive, without returning to a
           continuous redraw loop. */
        var sourceWords=[].slice.call(document.querySelectorAll('#cg767-menu .cg767-it,#cg767-menu2 .cg767-it,#cg-ovl-drag > *'))
          .map(function(el){var r=el.getBoundingClientRect();return r.width>=2&&r.height>=2?(el.innerText||el.textContent||'').replace(/\s+/g,' ').trim():'';})
          .filter(Boolean);
        bits.push(sourceWords.join('~'));
        var signature=bits.join('|');
        if(!force&&window.__cg767PT013RenderSignature===signature)return;
        window.__cg767PT013RenderSignature=signature;
        window.__cg767PT013RenderCount=(window.__cg767PT013RenderCount||0)+1;
        renderOptionHeader(force); renderMenuTextSurface(); installSourceInkGuard(); installDotHitTargets();
      };
      window.__cg767PT013RenderSurfaceStable = renderSurfaceStable;
      var installOpenTracks = function(){
        var fr2 = document.getElementById('cg767-fr'); if (!fr2) return;
        var prior=fr2.querySelector('#cg767-pt013-open-tracks');
        if(!prior || prior.getAttribute('data-revision')!=='guides-only-v3') {
          if(prior) prior.remove();
          var g = window.__cgB767.geometry;
          var ns = 'http://www.w3.org/2000/svg', tracks = document.createElementNS(ns,'g');
          tracks.setAttribute('id','cg767-pt013-open-tracks');
          tracks.setAttribute('data-revision','guides-only-v3');
          tracks.setAttribute('pointer-events','none');
          /* The rails are geometry only.  No visible line is added: visible
             top/bottom strokes read as borders, while text still follows the
             same shared curved-display surface through railPoint/railScale. */
          fr2.appendChild(tracks);
        }
        renderSurfaceStable(true);
      };
      window.__cg767PT013InstallOpenTracks = installOpenTracks;
      var fr = document.getElementById('cg767-fr');
      if (fr && !window.__cg767PT013RailObserver) {
        var queued = false;
        window.__cg767PT013RailObserver = new MutationObserver(function(records){
          /* Do not let this test's own SVG redraw schedule itself again. */
          var changed=false;
          records.forEach(function(record){
            [].slice.call(record.addedNodes).concat([].slice.call(record.removedNodes)).forEach(function(node){
              var id=node&&node.nodeType===1&&node.id||'';
              if(id.indexOf('cg767-pt013-')!==0) changed=true;
            });
          });
          if(!changed) return;
          if (queued) return; queued = true;
          requestAnimationFrame(function(){
            queued = false;
            /* Source HUD animation can add ordinary child nodes while the menu
               is open.  Those nodes do not justify tearing down every curved
               glyph.  Reinstall only if this test's host was actually lost;
               otherwise let the stable signature decide whether any repaint
               is needed. */
            if(!fr.querySelector('#cg767-pt013-open-tracks')) window.__cg767PT013InstallOpenTracks();
            else window.__cg767PT013RenderSurfaceStable(false);
          });
        });
        window.__cg767PT013RailObserver.observe(fr, {childList:true});
      }
      installOpenTracks();
      if (!window.__cg767PT013HeaderTimer) window.__cg767PT013HeaderTimer=setInterval(function(){
        renderSurfaceStable(false);
      },750);
      return {applied:true, outline:localStorage.getItem('cg767_outline'), mesh:localStorage.getItem('cg767_meshon'),
        framePaths:fr ? fr.querySelectorAll('path').length : 0, openTracks:!!(fr&&fr.querySelector('#cg767-pt013-open-tracks')),
        rawBodyTouched:false};
    } catch (e) { return {applied:false, err:String(e && e.message || e)}; }
  })()`;
  return win.webContents.executeJavaScript(js, true).then((r) => {
    cgLogErr('pt013-rails-test', JSON.stringify(r));
    return r;
  }).catch((e) => {
    cgLogErr('pt013-rails-test', (e && e.message) || e);
    return { applied:false, err:'rail restore test injection failed' };
  });
}

/* PT-012 — Michroma belongs ONLY to the overlay chrome.  The earlier
   attempt selected html/body descendants and therefore rewrote the tablet
   itself.  This deliberately selects only SVG/DOM elements created by the
   HUD skin: the frame, rail labels, and HUD-owned menus.  It cannot reach a
   tablet subpage, .pill-body, or the tablet's content root.  The font data is
   read from the user's local Michroma asset so the test has no network/font-CDN
   dependency. */
function applyPersonalHudRailFont() {
  const personalHud = cfg.hudOnly && /CmdGlas_PERSONAL\.html(?:[?#]|$)/i.test(String(cfg.url || ''));
  if (!personalHudRailFontEnabled || !personalHud || !win) return Promise.resolve({ skipped: true });
  let face = '';
  try {
    face = fs.readFileSync(PERSONAL_HUD_MICHROMA_FILE).toString('base64');
  } catch (e) {
    cgLogErr('pt012-michroma-read', (e && e.message) || e);
    return Promise.resolve({ applied: false, err: 'Michroma asset unreadable' });
  }
  const css = '@font-face{font-family:"cg767-michroma-test";font-style:normal;font-weight:400;font-display:block;src:url(data:font/ttf;base64,' + face + ') format("truetype");}'
    + 'html.cg-hudonly #cg767-fr text,html.cg-hudonly #cg767-top text,'
    + 'html.cg-hudonly #cg767-menu .cg767-hdr,html.cg-hudonly #cg767-menu .cg767-it,'
    + 'html.cg-hudonly #cg767-menu #cg-ovl-drag > *,'
    + 'html.cg-hudonly #cg767-menu2 .cg767-hdr,html.cg-hudonly #cg767-menu2 .cg767-it,'
    + 'html.cg-hudonly #cg767-shippanel .sp-ttl,html.cg-hudonly #cg767-shippanel .sp-btn,'
    + 'html.cg-hudonly #cg767-shippanel .sp-ship{font-family:"cg767-michroma-test",Michroma,sans-serif !important;font-weight:400 !important;}';
  return win.webContents.insertCSS(css).then(() =>
    win.webContents.executeJavaScript('(async function(){try{await document.fonts.load("400 16px \\"cg767-michroma-test\\"");function repaint(){try{if(window.__cgB767&&window.__cgB767.repaint)window.__cgB767.repaint();}catch(e){}};repaint();setTimeout(repaint,900);return {applied:true,loaded:document.fonts.check("16px \\"cg767-michroma-test\\""),armed:document.documentElement.classList.contains("cg-hudonly"),targets:document.querySelectorAll("#cg767-fr text,#cg767-top text,#cg767-menu .cg767-it,#cg767-menu2 .cg767-it").length};}catch(e){return {applied:false,err:String(e&&e.message||e)}}})()', true)
  ).catch((e) => {
    cgLogErr('pt012-michroma-apply', (e && e.message) || e);
    return { applied: false, err: 'Michroma CSS injection failed' };
  });
}

function applyHudOnly() {
  if (!win) return;
  win.webContents.executeJavaScript(HUDONLY_JS).then(() =>
    win.webContents.executeJavaScript('window.__cgHudOnly(' + (cfg.hudOnly ? 'true' : 'false') + ')')
  ).then(ok => {
    if (!ok && cfg.hudOnly) {
      // the home screen builds itself over a couple of seconds; retry, bounded
      let n = 0;
      const iv = setInterval(() => {
        if (!win || ++n > 30) return clearInterval(iv);
        win.webContents.executeJavaScript('window.__cgHudOnly(true)')
          .then(r => { if (r) clearInterval(iv); }).catch(() => {});
      }, 400);
    }
  }).catch(() => {});
}

function setHudOnly(on) {
  cfg.hudOnly = !!on;
  saveConfig();
  // each mode remembers its own window size - a HUD-sized window must not become
  // the size the whole tablet reopens at
  const b = win ? win.getBounds() : null;
  if (b) { if (on) sizeState.full = b; else sizeState.hud = b; }
  applyHudOnly();
  if (win) win.webContents.executeJavaScript(
    'window.__cgOvlHudBtn && window.__cgOvlHudBtn(' + (on ? 'true' : 'false') + ')').catch(() => {});
  /* v1.2.10 - T: "when you go to full tablet its size is incorrect - it spawns in
     the same size the user left the hud on." A --hud launch never captures a
     full-tablet size, so docking had nothing to restore and kept the HUD bounds.
     The tablet now falls back to its own launch geometry: centred, up to
     1400x900, inside the work area. Minimum size follows the mode too. */
  let want = on ? sizeState.hud : sizeState.full;
  if (!on && !want) {
    const wa = screen.getDisplayMatching(win.getBounds()).workArea;
    const w = Math.min(1400, wa.width - 80), h = Math.min(900, wa.height - 80);
    want = { x: wa.x + Math.round((wa.width - w) / 2),
             y: wa.y + Math.round((wa.height - h) / 2), width: w, height: h };
  }
  if (win) { if (on) { try { win.setAspectRatio(0); } catch (e) {} win.setMinimumSize(720, 260); } else { cgTabletVMin(); } }   /* CG767_TABRATIO: aspect freed for HUD-only, locked 4:3 in whole-tablet */
  if (want) setBounds(want, on ? 'hudonly-size' : 'fulltablet-size');
  toast(on ? 'HUD ONLY' : 'WHOLE TABLET', false, 1400);
}

/* CG767_VMIN - 17 AUG 2026. T: "the user should never be able to zoom in so
   far as to the whole page not being displayed. this is the tablet overlay ...
   it's already locked down horizontally at a minimum point. only the vertical
   height still moves too far."
   THE NUMBER, RECORDED PER GATE V: the home page's real content height
   measured 1771-1838 CSS px at the pinned design width (handoff 4.3), and
   every fitter floors at zoom 0.5 - so below 920 window px the page CANNOT
   fully display. 920 = ceil(1838 x 0.5), scaled by the live Electron
   zoomFactor, clamped to the monitor's work area minus 20 so a short monitor
   can never get an unsatisfiable minimum (GATE G - never wedge his window).
   WHOLE-TABLET MODE ONLY - HUD-only keeps its small minimum untouched. */
function cgTabletVMin(){
  try{
    if(!win || win.isDestroyed() || cfg.hudOnly) return;
    var zf=1; try{ zf=win.webContents.getZoomFactor()||1; }catch(e){}
    var wa=screen.getDisplayMatching(win.getBounds()).workArea;
    /* CG767_LANDLOCK - T: "your tablet now opens in portrait mode. fix it."
       CAUSE: the width (height x 4/3) was never checked against the SCREEN -
       on a display narrower than that, the OS clamped width while the height
       minimum held, and the window came up taller than wide. The 4:3 box is
       now fitted inside the work area on BOTH axes, so landscape holds by
       construction on any monitor. */
    var mh=Math.min(Math.ceil(920*zf), Math.max(400, wa.height-20),
                    Math.max(300, Math.floor((wa.width-20)*3/4)));
    /* CG767_TABRATIO - T, 17 AUG: "as long as it looks like a tablet.
       landscape mode with the correct dimensions." A real tablet in landscape
       is 4:3 - the iPad's own ratio, the device this tablet already targets.
       Whole-tablet mode holds that shape: aspect locked for manual resizes,
       minimum width follows the readable minimum height. */
    var mw=Math.max(900, Math.ceil(mh*4/3));
    try{ win.setAspectRatio(4/3); }catch(e){}
    win.setMinimumSize(mw, mh);
    var b=win.getBounds();
    if(b.height<mh || b.width<mw)
      setBounds({x:b.x, y:b.y, width:Math.max(b.width,mw), height:Math.max(b.height,mh)}, 'vmin-grow');
  }catch(e){}
}
function inject() {
  if (!win) return;
  win.webContents.insertCSS(OVL_CSS).catch(() => {});
  win.webContents.insertCSS(HUDONLY_CSS).catch(() => {});   /* gated on html.cg-hudonly - inert until the class is set */
  win.webContents.insertCSS(OVL_ROUND_CSS).catch(() => {});  /* v1.2.11 rounded tablet corners */
  win.webContents.executeJavaScript(OVL_JS).then(() => {
    applyHudOnly();
    applyPersonalHudRailFont().then((r) => {
      if (r && r.applied === false) cgLogErr('pt012-michroma-result', JSON.stringify(r));
    });
    applyPersonalHudRailRestoreTest().then((r) => {
      if (r && r.applied === false) cgLogErr('pt013-rails-test-result', JSON.stringify(r));
    });
    revealPersonalHudAfterReady();
    win.webContents.executeJavaScript(
      'window.__cgOvlHudBtn && window.__cgOvlHudBtn(' + (cfg.hudOnly ? 'true' : 'false') + ')').catch(() => {});
    applyDim(false);
    setDragBar(!clickThrough);
    setCtBadge(clickThrough);   /* v1.2.14 - correct on the FIRST paint, not only after a toggle */
    if (cfg.__urlFromArg) toast('TEST BUILD  ·  ' + cfg.url.split('/').pop(), true, 4000);
    /* v1.2.4 put a 6-second toast here. v1.2.14 replaces it with the badge above:
       MEASURED on the first v1.2.14 render - both fired at once and stacked two
       amber bars saying the same sentence, and the toast's copy was the weaker of
       the two. A state does not need an announcement as well as a sign. */
    if (startupReport.length) {
      toast(startupReport.join('   ·   '), true, 7000);
      startupReport = [];
    }
  }).catch(() => {});
}
function toast(msg, warn, ms) {
  if (!win) return;
  /* CG767_HKTOAST - build 289. A HARD CAP, so no message written later can
     wall him again. T: "that's too much to be read during a regular warning."
     Truncation is VISIBLE (the ellipsis), never silent - 2.5, any cap must
     report that it capped. */
  msg = String(msg); if (msg.length > 120) msg = msg.slice(0, 117) + '\u2026';
  win.webContents.executeJavaScript(
    'window.__cgOvlToast && window.__cgOvlToast(' + JSON.stringify(String(msg)) + ',' +
    (warn ? 'true' : 'false') + ',' + (ms || 1100) + ')').catch(() => {});
}
function setDragBar(on) {
  if (!win || !cfg.showDragBar) return;
  win.webContents.executeJavaScript('window.__cgOvlDrag && window.__cgOvlDrag(' + (on ? 'true' : 'false') + ')').catch(() => {});
}

// ---------------------------------------------------------------------------
//  dimmer
// ---------------------------------------------------------------------------
function applyDim(announce) {
  if (!win) return;
  const pct = cfg.dimLevel;
  if (cfg.dimTarget === 'window') {
    win.setOpacity(pct / 100);
    win.webContents.executeJavaScript("window.__cgOvlDim && window.__cgOvlDim('window',100)").catch(() => {});
  } else {
    win.setOpacity(1);
    win.webContents.executeJavaScript(
      "window.__cgOvlDim && window.__cgOvlDim('" + cfg.dimTarget + "'," + pct + ")").catch(() => {});
  }
  if (announce) {
    const name = { window: 'WHOLE WINDOW', content: 'WHOLE TABLET', hud: 'HUD ONLY' }[cfg.dimTarget];
    toast(pct + '%  ·  ' + name);
  }
}
function setDim(pct) { if (STEPS.indexOf(pct) < 0) return; cfg.dimLevel = pct; saveConfig(); applyDim(true); }
function cycleDim() { setDim(STEPS[(STEPS.indexOf(cfg.dimLevel) + 1) % STEPS.length]); }

function setClickThrough(on) {
  clickThrough = !!on;
  if (!win) return;
  win.setIgnoreMouseEvents(clickThrough, { forward: true });
  setDragBar(!clickThrough);
  setCtBadge(clickThrough);      /* v1.2.14 - the state gets a permanent tell */
}
/* v1.2.14 - separate from toast() on purpose: a toast is an event with a timer,
   this is a condition that stays on screen until it stops being true. */
function setCtBadge(on) {
  if (!win) return;
  win.webContents.executeJavaScript(
    'window.__cgOvlCtBadge && window.__cgOvlCtBadge(' + (on ? 'true' : 'false') + ')').catch(() => {});
}

// ---------------------------------------------------------------------------
//  COMPACT -> window shrinks to fit.  T: "once hidden close the tablet in around
//  the new size".  fullBounds is remembered so FULL restores exactly what it was,
//  not a guess.
// ---------------------------------------------------------------------------
function onCompactReport(compact, hiddenPx) {
  if (!win) return;
  if (compact === compactNow) return;              // only the TRANSITION acts, never a repeat
  const b = win.getBounds();
  if (compact) {
    compactNow = true;
    if (!cfg.shrinkOnCompact) return;
    const d = Math.max(0, Math.round(hiddenPx || 0));
    if (!d) { console.log('BOUNDS compact-on: nothing to remove, window unchanged'); return; }
    fullBounds = b;
    setBounds({ x: b.x, y: b.y, width: b.width, height: Math.max(cfg.minHeight, b.height - d) }, 'compact-shrink -' + d);
  } else {
    compactNow = false;
    if (!cfg.shrinkOnCompact) return;
    // a page that LOADED compact has no remembered full size - grow by the delta
    if (!fullBounds) fullBounds = { x: b.x, y: b.y, width: b.width, height: b.height + Math.max(0, Math.round(hiddenPx || 0)) };
    setBounds(fullBounds, 'compact-restore');
  }
}
function maximise() {
  if (!win) return;
  const wa = screen.getDisplayMatching(win.getBounds()).workArea;
  const b = win.getBounds();
  const isFull = Math.abs(b.width - wa.width) < 6 && Math.abs(b.height - wa.height) < 6;
  if (isFull && fullBounds) { setBounds(fullBounds, 'max-restore'); toast('RESTORED'); }
  else { fullBounds = b; setBounds({ x: wa.x, y: wa.y, width: wa.width, height: wa.height }, 'maximise'); toast('FULL SCREEN'); }
}

// ---------------------------------------------------------------------------
//  corner resize.  The page sends absolute SCREEN coordinates; main works out the
//  delta from the anchor it took on pointerdown. Doing it from deltas the page
//  computes would drift, because the window moves under the cursor as it resizes.
// ---------------------------------------------------------------------------
function onResize(msg) {
  if (!win) return;
  if (msg.rz === 'start') { rzAnchor = { edge: msg.edge, sx: msg.sx, sy: msg.sy, b: win.getBounds() }; return; }
  if (msg.rz === 'end') { rzAnchor = null; if (!compactNow) fullBounds = win.getBounds(); saveState(); return; }
  if (msg.rz !== 'move' || !rzAnchor) return;
  const dx = msg.sx - rzAnchor.sx, dy = msg.sy - rzAnchor.sy, o = rzAnchor.b, e = rzAnchor.edge;
  const MINW = cfg.minWidth, MINH = cfg.minHeight;
  let x = o.x, y = o.y, w = o.width, h = o.height;
  if (e === 'se') { w = o.width + dx; h = o.height + dy; }
  else if (e === 'sw') { w = o.width - dx; h = o.height + dy; x = o.x + dx; }
  else if (e === 'ne') { w = o.width + dx; h = o.height - dy; y = o.y + dy; }
  else if (e === 'nw') { w = o.width - dx; h = o.height - dy; x = o.x + dx; y = o.y + dy; }
  if (w < MINW) { if (e === 'sw' || e === 'nw') x = o.x + (o.width - MINW); w = MINW; }
  if (h < MINH) { if (e === 'ne' || e === 'nw') y = o.y + (o.height - MINH); h = MINH; }
  setBounds({ x: x, y: y, width: w, height: h }, 'resize-' + e);
}

// ---------------------------------------------------------------------------
//  the window
// ---------------------------------------------------------------------------
function createWindow() {
  const disp = screen.getPrimaryDisplay().workAreaSize;
  const saved = loadState();
  /* PT-004/PT-005: Personal 4 - Game Overlay only.  The one-alpha backing plus
     hidden-until-ready reveal passed T's live visual test.  Public retains its
     fully transparent backing and normal startup. */
  const personalHudLaunch = cfg.hudOnly && /CmdGlas_PERSONAL\.html(?:[?#]|$)/i.test(String(cfg.url || ''));
  personalHudInitialReveal = personalHudLaunch;
  win = new BrowserWindow({
    transparent: true, frame: false, alwaysOnTop: true,
    backgroundColor: personalHudLaunch ? '#00000001' : '#00000000', hasShadow: false, skipTaskbar: false, resizable: true,
    show: !personalHudLaunch,
    minWidth: cfg.minWidth, minHeight: cfg.minHeight,
    /* MEASURED: the HUD lays out at about 866 x 308 at default zoom, so the HUD-only
       window opens landscape to fit it. Opening it portrait produced nothing but the
       tablet's ROTATE TO LANDSCAPE card. */
    /* v1.2.7 - T's HUD had been dragged to 320px wide and that width was restored
       on every launch: six tab labels cannot fit, so GATHER & BUY wrapped and
       STREAM was clipped. A saved width is CLAMPED to a readable floor now, and
       the window carries a real minimum below (setMinimumSize). */
    width:  Math.max(cfg.hudOnly ? 720 : 900,
              cfg.hudOnly ? (saved && saved.hudW ? saved.hudW : 940)
                          : (saved ? saved.width  : Math.min(1400, disp.width  - 80))),
    height: Math.max(cfg.hudOnly ? 260 : 400,
              cfg.hudOnly ? (saved && saved.hudH ? saved.hudH : 440)
                          : (saved ? saved.height : Math.min(900,  disp.height - 80))),
    x: saved ? saved.x : undefined,
    y: saved ? saved.y : undefined,
    webPreferences: { contextIsolation: true, nodeIntegration: false, backgroundThrottling: false }
  });
  fullBounds = win.getBounds();
  /* v1.2.15: re-apply on EVERY load. loadURL resets the zoom, so without this the
     reload hotkey would quietly hand the pilot a 100% window again. */
  win.webContents.on('did-finish-load', () => { try { applyZoom(); } catch (e) {} });
  win.webContents.on('did-finish-load', () => { setTimeout(() => cgSnapAspect('load'), 900); });
  win.webContents.on('did-finish-load', () => { setTimeout(() => { try { cgTabletVMin(); } catch (e) {} }, 1200); });   /* CG767_VMIN */
  /* CG767_OPENMIN - T, 17 AUG: "bake it in so that the tablet always opens in
     min mode." On LAUNCH (first load only - a Ctrl+F2 reload keeps whatever
     size he has dragged to), whole-tablet mode snaps to the same 4:3 readable
     floor the MIN button uses, keeping the saved position. HUD-only launches
     untouched. */
  let cgMinOpened = false;
  win.webContents.on('did-finish-load', () => { setTimeout(() => { try {
    if (cgMinOpened || cfg.hudOnly) return; cgMinOpened = true;
    var zfO = 1; try { zfO = win.webContents.getZoomFactor() || 1; } catch (e) {}
    var waO = screen.getDisplayMatching(win.getBounds()).workArea;
    var mhO = Math.min(Math.ceil(920 * zfO), Math.max(400, waO.height - 20), Math.max(300, Math.floor((waO.width - 20) * 3 / 4)));   /* CG767_LANDLOCK */
    var bO = win.getBounds();
    setBounds({ x: bO.x, y: bO.y, width: Math.max(900, Math.ceil(mhO * 4 / 3)), height: mhO }, 'openmin');
  } catch (e) {} }, 1600); });
  win.setAlwaysOnTop(true, 'screen-saver');
  win.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });

  /* A pilot whose control server is not running should still get a working tablet.
     If the configured URL fails, fall through to the published one and SAY SO -
     silently loading a different build than the one asked for would be worse than
     an error page. */
  /* CG767_FRESHLOAD - 13 AUG. Electron's HTTP cache served a build one
     splice behind the disk through a real restart - the server was verified
     serving the new bytes while the painted DOM lacked them. Every launch
     now stamps a cache-buster on http(s) loads, so a restart ALWAYS fetches
     what is on disk. localhost only pays a local 7 MB read. */
  const bust = (u) => { try{ if(!/^http/i.test(u)) return u;
      return u + (u.includes('?') ? '&' : '?') + 'cb=' + Date.now(); }catch(e){ return u; } };
  const loadWithFallback = (u, isFallback) => win.loadURL(bust(u)).then(() => {
    if (isFallback) {
      startupReport.push('COULD NOT REACH ' + cfg.url + '  -  loaded ' + cfg.fallbackUrl + ' instead');
    }
  }).catch(err => {
    if (!isFallback && cfg.fallbackUrl && cfg.fallbackUrl !== u) {
      console.error('primary URL failed (' + u + '), trying ' + cfg.fallbackUrl);
      return loadWithFallback(cfg.fallbackUrl, true);
    }
    throw err;
  });
  loadWithFallback(cfg.url, false).catch(err => {
    const msg = String((err && err.message) || err).replace(/</g, '&lt;');
    win.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(
      '<body style="margin:0;background:#0b1017;color:#cfe2f1;font:14px/1.6 Segoe UI,sans-serif;padding:26px">' +
      '<h2 style="color:#8fd8ff;letter-spacing:2px">CMDGLAS OVERLAY - CANNOT REACH THE TABLET</h2>' +
      '<p>Tried: <b>' + cfg.url + '</b></p><p>' + msg + '</p>' +
      '<p>Start the control server, then press <b>' + KM.pretty(cfg.hotkeys.reload) + '</b>.</p></body>'));
  });

  // one channel back from the page - no preload, no node integration in the tablet
  /* CG767_PLAYERWIN - 17 AUG 2026 S27. T: "its own window that's always on
     top." A frameless, always-on-top, cornerless player window. It loads
     player.html from the SAME origin the tablet loads from (the control
     server), so the Twitch embed gets a real localhost parent. One window,
     reused: a second launch retargets it. Reversible: delete this function
     and its dispatch line. */
  function openPlayer(q){
    try{
      /* YTSWITCH-355: q of the form site:<url> loads the FULL site (youtube,
         yt music) - those refuse to be embedded, but a real window loads them
         whole. Site windows keep the OS frame so they stay movable without a
         drag strip we cannot inject cross-origin. */
      const site = /^site:/.test(String(q)) ? String(q).slice(5) : null;
      const target = site ? site : (new URL('player.html', cfg.url).toString() + '#q=' + encodeURIComponent(q));
      if (global.__cgPlayerWin && !global.__cgPlayerWin.isDestroyed() && !!global.__cgPlayerWin.__cgSite === !!site) {
        global.__cgPlayerWin.loadURL(target);
        global.__cgPlayerWin.show(); global.__cgPlayerWin.focus();
        return;
      }
      if (global.__cgPlayerWin && !global.__cgPlayerWin.isDestroyed()) { try{ global.__cgPlayerWin.close(); }catch(_){} }
      if (site) {
        const sw = new BrowserWindow({
          width: 1100, height: 700, frame: true, resizable: true,
          backgroundColor: '#000000',
          webPreferences: { nodeIntegration: false, contextIsolation: true }
        });
        sw.setAlwaysOnTop(true, 'screen-saver');
        sw.setMenuBarVisibility(false);
        sw.loadURL(site);
        sw.__cgSite = true;
        sw.on('closed', () => { global.__cgPlayerWin = null; });
        global.__cgPlayerWin = sw;
        return;
      }
      const pw = new BrowserWindow({
        width: 884, height: 510, frame: false, resizable: true,
        backgroundColor: '#000000', skipTaskbar: false,
        webPreferences: { nodeIntegration: false, contextIsolation: true }
      });
      pw.setAlwaysOnTop(true, 'screen-saver');
      pw.setMinimumSize(320, 210);
      pw.loadURL(target);
      pw.on('closed', () => { global.__cgPlayerWin = null; });
      global.__cgPlayerWin = pw;
    }catch(e){ try{ toast('PLAYER FAILED: '+String(e).slice(0,60), true, 2500); }catch(_){} }
  }

  win.webContents.on('console-message', (_e, _lvl, message) => {
    const i = message.indexOf('CGOVL§');
    if (i < 0) return;
    let m; try { m = JSON.parse(message.slice(i + 6)); } catch (_) { return; }
    if (m.rz) return onResize(m);
    if (m.act === 'max') return maximise();
    if (m.act === 'fit') {
      /* CG767_FITMIN - 17 AUG 2026. T: "i want the fit button on the top
         right to force the tablet into the smallest fully readable tablet we
         can reduce the tablet size to." The smallest fully-readable size IS
         the CG767_VMIN minimum: width 900 and height ceil(920 x the live
         zoomFactor) - the height below which the whole page cannot display
         (content 1771-1838 CSS px at the 0.5 zoom floor). FIT now snaps the
         whole-tablet window to exactly that, keeping its top-left where it
         is. HUD-only mode keeps the old fit behaviour. */
      if (!cfg.hudOnly) {
        try {
          var zfF = 1; try { zfF = win.webContents.getZoomFactor() || 1; } catch (e) {}
          var waF = screen.getDisplayMatching(win.getBounds()).workArea;
          var mhF = Math.min(Math.ceil(920 * zfF), Math.max(400, waF.height - 20), Math.max(300, Math.floor((waF.width - 20) * 3 / 4)));   /* CG767_LANDLOCK */
          var bF = win.getBounds();
          cgTabletVMin();
          setBounds({ x: bF.x, y: bF.y, width: Math.max(900, Math.ceil(mhF*4/3)), height: mhF }, 'fitmin');   /* CG767_TABRATIO: MIN snaps to the 4:3 readable floor */
          toast('SMALLEST READABLE', false, 1200);
        } catch (e) {}
        return;
      }
      win.webContents.executeJavaScript('window.__cgOvlFit && window.__cgOvlFit()').catch(() => {}); cgSnapAspect('fit-btn'); return; }
    if (m.act === 'player') return openPlayer(String(m.q||''));   /* CG767_PLAYERWIN */
    if (m.act === 'settings') return openSettings();
    if (m.act === 'close') { try { saveState(); } catch (_) {} app.quit(); return; }   /* v1.2.3 */
    if (m.act === 'hud') return setHudOnly(m.want === 'toggle' ? !cfg.hudOnly : !!m.want);
    if (typeof m.compact === 'boolean') return onCompactReport(m.compact, m.hiddenPx);
  });

  win.webContents.on('did-finish-load', () => { compactNow = false; inject(); });
  /* v1.2.4 - T clicked UNDOCK on launch, click-through was ON, the click went
     THROUGH to the Explorer window behind and Windows opened keymap.js with WSH
     (his screenshot, 3 AUG 2026). WHOLE-TABLET launches now start INTERACTIVE -
     you launched a tablet, you mean to touch it. HUD-only keeps the config value:
     that is the in-flight mode, click-through is its point. */
  win.setMinimumSize(cfg.hudOnly ? 720 : 900, cfg.hudOnly ? 260 : 400);  /* v1.2.7 */
  /* The visual rail harness must always receive real mouse input.  This flag
     is test-only and does not change the saved normal-overlay preference. */
  setClickThrough(personalHudRailRestoreTest ? false : (cfg.hudOnly ? cfg.clickThroughOnStart : false));
  win.on('resized', () => { if (!compactNow && !rzAnchor) fullBounds = win.getBounds(); });
  /* v1.2.9 - MEASURED: after ANY window resize the tablet's own fit logic re-writes
     the ancestor widths the HUD-only sweep had pinned (inline vs inline - last
     write wins), and the tab row lays out at ~2x the window: STREAM/THREAT walked
     off-screen in T's screenshot. The sweep is idempotent, so it simply re-runs
     after each resize settles. */
  let __rzT = null;
  win.on('resize', () => {
    if (!cfg.hudOnly) return;
    clearTimeout(__rzT);
    __rzT = setTimeout(() => { if (win && cfg.hudOnly) applyHudOnly(); }, 250);
  });
  win.on('close', saveState);
  win.on('closed', () => { win = null; });
}

// ---------------------------------------------------------------------------
//  hotkeys
// ---------------------------------------------------------------------------
/* v1.2.13 - T: "i can't actually make hotkeys for my streamdeck since it's
   connected to the game. you made me some url's before".
   Keystrokes go to the focused window - the game. URLs do not. This is the same
   doctrine as the 8421 HUD bridge: a loopback-only HTTP listener, one endpoint
   per action, driveable by anything that can open a URL. 127.0.0.1 ONLY -
   nothing outside this PC can reach it. Port 8422 (8420 server, 8421 bridge). */
const http = require('http');
function startControlServer() {
  const ACT = {
    ping:        () => 'ok',
    hud:         () => { setHudOnly(true);  return 'hud'; },
    tablet:      () => { setHudOnly(false); return 'tablet'; },
    toggle:      () => { setHudOnly(!cfg.hudOnly); return cfg.hudOnly ? 'hud' : 'tablet'; },
    hide:        () => { if (win) win.hide(); return 'hidden'; },
    show:        () => { if (win) { win.show(); } return 'shown'; },
    visible:     () => { if (win) (win.isVisible() ? win.hide() : win.show()); return 'toggled'; },
    clickthrough:() => { setClickThrough(!clickThrough); return clickThrough ? 'on' : 'off'; },
    dim25:       () => { setDim(25);  return '25'; },
    dim50:       () => { setDim(50);  return '50'; },
    dim75:       () => { setDim(75);  return '75'; },
    dim100:      () => { setDim(100); return '100'; },
    dimcycle:    () => { cycleDim(); return 'cycled'; },
    reload:      () => { if (win) win.loadURL(cfg.url+(cfg.url.includes('?')?'&':'?')+'cb='+Date.now()); return 'reloading'; }   /* CG767_FRESHLOAD */
  };
  /* ---- v1.2.20, 4 AUG 2026 --------------------------------------------------
     T: "streamdeck controls to open the individual ingame tools tabs and the
     buttons inside the hud so user doesn't have to actually use mouse."

     WHY THIS AND NOT ?tab=NAME. The URL reference's http://host:8420/?tab=NAME
     opens a BROWSER at that address. It does not reach the overlay window the
     pilot is looking at, so it is the opposite of not touching the mouse.
     These endpoints run inside the overlay's OWN page via executeJavaScript.
     RULE 20 also makes this the only correct design: click-through means the
     page CANNOT be clicked while in flight, so every in-flight control has to
     have a non-mouse path.

     READ OUT OF THE TABLET BEFORE WRITING, not guessed:
       window.setActiveTabById(id)  - the global the tablet's own ?tab= opener
                                      calls. TAB_ALIAS below is a copy of that
                                      opener's ALIAS table, same left/right sides.
       .ops4-tab                    - the HUD pill's tab buttons. Matched by their
                                      VISIBLE LABEL, not by data-v: the base file
                                      defines only gather/notes/status and later
                                      builds append Contracts, Org/Party and
                                      Threat, so a data-v list would go stale.
                                      The label is what T sees and what he asks for.
       [data-refresh] / [data-clr]  - the b667 REFRESH and CLEAR buttons.
       .cg-mirror.s / .cg-mirror.u  - the on-screen SOURCE and UNDOCK mirrors
                                      (the originals are display:none on PC).

     Nothing here sends a keystroke and nothing touches the game client.
     Loopback only, same as the rest of this server. Reversible: delete this
     block and the two helpers above the listener. */
  const TAB_ALIAS = {
    mining:'mining', mine:'mining',
    blueprints:'blueprints', blueprint:'blueprints', bp:'blueprints',
    contracts:'missions', missions:'missions', mission:'missions',
    craftcalc:'craftcalc', craft:'craftcalc', craftcalculator:'craftcalc', calculator:'craftcalc',
    harvest:'harvest', harvestables:'harvest', harvestable:'harvest',
    loadout:'loadout', loadouts:'loadout', shiploadouts:'loadout', ships:'loadout',
    hauling:'trading', trading:'trading', cargo:'trading',
    salvage:'salvage', starmap:'starmap', nav:'starmap',
    inventory:'inventory', notepad:'notepad', notes:'notepad',
    myops:'myops', gather:'myops', buy:'myops', gatherbuy:'myops',
    orgpage:'orgpage', org:'orgpage', party:'orgpage',
    reputation:'reputation', shard:'shard', keybinds:'allkb', allkb:'allkb',
    system:'system', trouble:'trouble', manuals:'spacemanuals', spacemanuals:'spacemanuals',
    home:'home'
  };
  /* HUD pill tab -> the leading text of its visible label, upper case. */
  /* v1.2.21, 12 AUG 2026. T: "build it for streamdeck xl 32 key" - sixteen
     keys, of which FOUR had no endpoint at all. This table was written when the
     pill had seven tabs; MEASURED against the live HUD it now renders eleven:
       ❮❮ BACK · Gather & Buy · Notes · Contracts · Org/Party · Threat ·
       Stream · Route · Hauling · Account · Media
     BACK, Route, Hauling and Media were missing, and a Stream Deck key wired to
     a missing endpoint is a key that does nothing and says nothing - GATE G.
     Account is included for completeness but NOTE: the b767 HUD skin hides that
     tab in HUD-only mode, so that one is a whole-tablet control. */
  const HUD_TAB = {
    gather:'GATHER', notes:'NOTES', contracts:'CONTRACTS',
    org:'ORG', party:'ORG', threat:'THREAT', stream:'STREAM', status:'STREAM',
    back:'BACK', route:'ROUTE', hauling:'HAULING', media:'MEDIA',
    account:'ACCOUNT'
  };
  const HUD_BTN = {
    refresh:      '[data-refresh]',
    cleargather:  '[data-clr="gather"]',
    clearharvest: '[data-clr="harvest"]',
    clearbuy:     '[data-clr="buy"]',
    clearall:     '[data-clr="all"]',
    /* MEASURED 12 AUG 2026: the real button is BUTTON.cg-mirror.s.cg-src-off
       inside SPAN.cg-clr-wrap, and it computes display:none at 0x0. A
       programmatic .click() still dispatches on a display:none element - only a
       real mouse is blocked - so this endpoint should fire where the mouse
       cannot. Recorded as MEASURED IN THE SANDBOX, NOT ON T's MACHINE. The
       button-first order matters: a plain '#cg-hudsrc' was matching a different
       node earlier in the document. */
    source:       'button.cg-mirror.s, .cg-mirror.s, #cg-hudsrc',
    undock:       '.cg-mirror.u, .cg-undock-btn'
  };
  function runJS(js) {
    if (!win || !win.webContents) return Promise.resolve('no-window');
    return win.webContents.executeJavaScript(js, true)
      .catch(e => 'err ' + String(e && e.message || e).slice(0, 90));
  }
  function jsTab(id) {
    return '(function(){try{if(typeof setActiveTabById!=="function")return "no-setActiveTabById";'
         + 'setActiveTabById(' + JSON.stringify(id) + ');return "ok";}catch(e){return "throw "+e.message}})()';
  }
  /* LEADING MATCH FIRST, THEN CONTAINS. MEASURED: the BACK tab's label is
     "❮❮ BACK" - two chevrons before the word - so indexOf("BACK") is 3, not 0,
     and a leading-only match could never reach it. Leading is still tried
     first so "ORG" cannot be stolen by a longer label that merely contains it;
     contains is the fallback, not the rule. */
  function jsHudTab(lead) {
    return '(function(){try{var L=' + JSON.stringify(lead) + ';'
         + 'var t=[].slice.call(document.querySelectorAll(".ops4-tab"));'
         + 'var b=t.filter(function(x){return (x.textContent||"").trim().toUpperCase().indexOf(L)===0;})[0];'
         + 'if(!b)b=t.filter(function(x){return (x.textContent||"").trim().toUpperCase().indexOf(L)>=0;})[0];'
         + 'if(!b)return "no-tab";b.click();return "ok";}catch(e){return "throw "+e.message}})()';
  }
  function jsClick(sel) {
    return '(function(){try{var b=document.querySelector(' + JSON.stringify(sel) + ');'
         + 'if(!b)return "not-found";b.click();return "ok";}catch(e){return "throw "+e.message}})()';
  }

  const srv = http.createServer((req, res) => {
    const name = (req.url || '/').replace(/^\/+/, '').split('?')[0].toLowerCase();
    res.setHeader('content-type', 'application/json');
    const done = (o, code) => { if (code) res.statusCode = code; res.end(JSON.stringify(o)); };

    /* discovery - so a dead endpoint can be diagnosed without reading this file */
    if (name === 'know' || name === 'help') {
      return done({ ok: true, window: Object.keys(ACT),
                    tabs: Object.keys(TAB_ALIAS).map(k => 'tab/' + k),
                    hudTabs: Object.keys(HUD_TAB).map(k => 'hud/' + k),
                    hudButtons: Object.keys(HUD_BTN).map(k => 'hud/' + k) });
    }
    if (name.indexOf('tab/') === 0) {
      const want = name.slice(4).replace(/[^a-z0-9]/g, '');
      const id = TAB_ALIAS[want];
      if (!id) return done({ ok: false, err: 'unknown tab', know: Object.keys(TAB_ALIAS) }, 404);
      return runJS(jsTab(id)).then(r => done({ ok: r === 'ok', did: 'tab/' + id, state: r }));
    }
    if (name.indexOf('hud/') === 0) {
      const want = name.slice(4).replace(/[^a-z0-9]/g, '');
      if (HUD_BTN[want]) return runJS(jsClick(HUD_BTN[want])).then(r => done({ ok: r === 'ok', did: 'hud/' + want, state: r }));
      if (HUD_TAB[want]) return runJS(jsHudTab(HUD_TAB[want])).then(r => done({ ok: r === 'ok', did: 'hud/' + want, state: r }));
      return done({ ok: false, err: 'unknown hud command',
                    know: Object.keys(HUD_TAB).concat(Object.keys(HUD_BTN)) }, 404);
    }

    /* v1.2.17-diag  10 AUG 2026 - TEMPORARY, READ ONLY.
       T: "still wrong". The overlay window's real numbers cannot be read from
       outside it, and reasoning from screenshots has now been wrong twice.
       GET http://127.0.0.1:8422/diag  returns them. Reads nothing but geometry.
       Remove this whole if-block to revert. */
    if (name === 'diag') {
      let b = null, cb = null, zf = null, disp = null;
      try { b  = win && !win.isDestroyed() ? win.getBounds() : null; } catch (e) {}
      try { cb = win && !win.isDestroyed() ? win.getContentBounds() : null; } catch (e) {}
      try { zf = win.webContents.getZoomFactor(); } catch (e) {}
      try { const s2 = screen.getPrimaryDisplay(); disp = { size: s2.size, workArea: s2.workArea, scaleFactor: s2.scaleFactor }; } catch (e) {}
      const probe = '(function(){try{var d=document.documentElement,b=document.body;'
        + 'return JSON.stringify({innerW:innerWidth,innerH:innerHeight,dpr:devicePixelRatio,'
        + 'rootZoom:d.style.zoom,bodyOffW:b.offsetWidth,bodyMinW:b.style.minWidth,'
        + 'bodyMaxW:b.style.maxWidth,scrollW:d.scrollWidth,clientW:d.clientWidth,'
        + 'overflowX:d.scrollWidth-d.clientWidth,scrollH:d.scrollHeight,clientH:d.clientHeight,'
        + 'hudonly:d.classList.contains("cg-hudonly"),compact:d.classList.contains("cg-compact"),'
        + 'portable:b.getAttribute("data-portable"),'
        + 'b736:!!document.getElementById("cg-b736-bottom-css"),'
        + 'noticeBottom:(function(){var n=document.getElementById("cg-cig-notice");return n?Math.round(n.getBoundingClientRect().bottom):0;})(),'
        + 'cg740:(function(){try{return JSON.parse(document.documentElement.getAttribute("data-cg740")||"null");}catch(e){return "err";}})(),'
        + 'homeScrollH:(function(){var h=document.getElementById("home-scroll");return h?h.scrollHeight:0;})(),'
        + 'coarse:!!(window.matchMedia&&matchMedia("(pointer:coarse)").matches),'
        + 'pillz:(function(){try{var p=document.querySelector("#sc-home-widgets .ops-pill.b385");'
        + 'if(!p)return "no-pill";var b=p.querySelector(".pill-body");var g=getComputedStyle(p);'
        + 'return {inline:p.style.zoom,prio:p.style.getPropertyPriority("zoom"),comp:g.zoom,'
        + 'cgho:p.getAttribute("data-cgho"),cls:String(p.className).slice(0,90),'
        + 'styleLen:(p.getAttribute("style")||"").length,'
        + 'styleHas:((p.getAttribute("style")||"").indexOf("zoom")>=0),'
        + 'bodyComp:b?getComputedStyle(b).zoom:null,bodyInline:b?b.style.zoom:null,'
        + 'parentComp:p.parentElement?getComputedStyle(p.parentElement).zoom:null};'
        + '}catch(e){return "err "+e.message;}})(),'
        /* CG767_LISTPROBE - READ ONLY. Closes the instrument SS15.18 demanded and
           forbade building without: what elementFromPoint returns over the LIST,
           not over the controls. RULE 33 - the point is converted local -> painted
           through the zoom chain before it is handed to elementsFromPoint, which is
           the exact CLASS Z fault CG767_HITRULER fixed for the rails.
           reachesBody is the whole answer: a wheel can only scroll .ops4-body if
           .ops4-body is in the stack under the pointer. Draws nothing, seats
           nothing, changes nothing. Delete this block to revert. */
        + 'listprobe:(function(){try{'
        + 'function zc(el){var z=1,n=el;while(n&&n.nodeType===1){var v=parseFloat(getComputedStyle(n).zoom);if(v&&v>0)z*=v;n=n.parentElement;}return z;}'
        + 'var lb=document.querySelector(".ops4-body");if(!lb)return "no-ops4-body";'
        + 'var r=lb.getBoundingClientRect(),z=zc(lb),i,pts=[];'
        + 'for(i=1;i<=5;i++){pts.push([r.left+r.width*0.5,r.top+r.height*(i/6)]);}'
        + 'var pl=document.querySelector("#sc-home-widgets .ops-pill.b385");'
        + 'var out=pts.map(function(p){var px=p[0]*z,py=p[1]*z,st=[];'
        + 'try{st=document.elementsFromPoint(px,py).slice(0,6).map(function(e){'
        + 'return e.tagName+"."+String(e.className||e.id||"").slice(0,30);});}catch(e){}'
        + 'var j=st.join(" | ");'
        + 'return {local:[Math.round(p[0]),Math.round(p[1])],painted:[Math.round(px),Math.round(py)],'
        + 'stack:st,reachesBody:j.indexOf("ops4-body")>=0,hitsGrip:j.indexOf("cg-ovl-rz")>=0,'
        + 'hitsZone:j.indexOf("cg767-hit")>=0};});'
        + 'return {z:z,rectLocal:[Math.round(r.left),Math.round(r.top),Math.round(r.width),Math.round(r.height)],'
        + 'scrollTop:lb.scrollTop,scrollH:lb.scrollHeight,clientH:lb.clientHeight,'
        + 'ovY:getComputedStyle(lb).overflowY,pillZoom:pl?getComputedStyle(pl).zoom:null,'
        + 'grips:[].slice.call(document.querySelectorAll(".cg-ovl-rz")).map(function(g){'
        + 'var q=g.getBoundingClientRect();return g.id+" local["+Math.round(q.left)+","+Math.round(q.top)'
        + '+","+Math.round(q.width)+","+Math.round(q.height)+"] disp"+getComputedStyle(g).display;}),'
        + 'wheel:(window.CG767_WHEEL||null),'
        + 'pts:out};'
        + '}catch(e){return "err "+e.message;}})(),'
        + 'url:location.href});}catch(e){return JSON.stringify({err:String(e.message)});}})()';
      return runJS(probe).then(r => {
        let page = r; try { page = JSON.parse(r); } catch (e) {}
        /* CG767_OVLBUILD - RULE 22 with an instrument behind it. Twice today a
           fix sat on disk while an older main.js was still the running process,
           and there was no way to tell them apart from outside. Now there is.
           Bump this string with every main.js edit. */
        done({ ok: true, ovlBuild: 'CG767_PT012_SCOPED_RAIL_MICHROMA_20260829',
               bounds: b, contentBounds: cb, zoomFactor: zf,
               cfgZoom: cfg.zoomFactor, hudOnly: cfg.hudOnly,
               display: disp, page: page });
      });
    }

    const fn = ACT[name];
    if (!fn) { res.statusCode = 404; res.end(JSON.stringify({ ok: false, know: Object.keys(ACT).concat(['know']) })); return; }
    let out; try { out = fn(); } catch (e) { res.statusCode = 500; res.end(JSON.stringify({ ok: false, err: String(e).slice(0, 120) })); return; }
    res.end(JSON.stringify({ ok: true, did: name, state: out }));
  });
  srv.on('error', () => {});           /* port taken (second instance) - stay silent */
  srv.listen(8422, '127.0.0.1');
}

/* v1.2.15: one place that owns the zoom. loadURL resets a webContents zoom, so this is
   called again on every did-finish-load - otherwise RELOAD silently undoes it. */
const ZOOM_MIN = 0.5, ZOOM_MAX = 3.0, ZOOM_STEP = 0.1;
function clampZoom(z) {
  z = Number(z); if (!isFinite(z)) z = 1;
  return Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, Math.round(z * 100) / 100));
}
/* v1.2.17 - 10 AUG 2026.  T: "the tablet doesn't size itself correctly inside
   of the ipad frame" ... "still wrong".
   MEASURED over /diag with the window at 1451x1376: the page lays out 1450 wide
   (overflowX 0) but only ~1008 tall, leaving a ~370px dead band. The tablet's
   own fitter is hard-designed 1700x1130 - a 3:2 landscape - and NO zoom value
   can fill a near-square window with a 3:2 page. The window itself must follow
   the page's shape.
   LOOP-SAFE, unlike the v1.2.15 attempt this file already warns about at the
   compact machinery: height here is a pure function of WIDTH (design ratio
   1130/1700 plus the 44px drag lane), never of anything the page reports, so
   the two cannot chase each other.
   Runs in whole-tablet mode only - HUD ONLY has its own sizing. */
function cgSnapAspect(why) {
  /* CG767_ONESHAPE - 17 AUG 2026. RETIRED, and this was the portrait maker:
     this height-follows-content snapper was a SECOND owner of the window's
     shape (CLASS C). It re-snapped the height to the page's content bottom
     AFTER the 4:3 landscape work - at MIN width that height exceeds the
     width, so the tablet opened portrait, twice, through two of my fixes
     aimed at the first cause (GATE X: causes stack). Since CG767_REALH the
     page fits ANY window by zoom, so the height never needs to chase content
     again. ONE owner now: the 4:3 family (TABRATIO/VMIN/FITMIN/OPENMIN/
     LANDLOCK). Restore from main.js.bak_pre_ONESHAPE_20260817. */
  return;
  if (!win || win.isDestroyed() || cfg.hudOnly) return;
  /* v1.2.19 - the 1130 constant was WRONG. MEASURED on the live page at two widths:
     the home content's real bottom lands at ~1213-1224 DESIGN px, not 1130 - the
     fitter's 1130 is only its zoom denominator. A snap to the 1130 formula cuts
     ~76px off the page, disclaimer included. So the window now follows the page's
     measured content bottom instead of a constant.
     LOOP-SAFE, the argument, not a hope: the page zoom derives from WIDTH (the
     binding ratio at every real overlay shape), and the home content does NOT
     stretch vertically - MEASURED: window 871 tall, content bottom 759, no growth.
     The probed bottom is a function of width alone, so setting HEIGHT from it
     cannot feed back. One shot per trigger, 8px dead band, no interval.
     +46 clears the fixed news ticker / brand band. */
  const probe = '(function(){try{var n=document.getElementById("cg-cig-notice");'
    + 'var b=n?n.getBoundingClientRect().bottom:0;'
    + 'if(!b){var w=document.querySelector("#tab-home .hm-wrap");if(w)b=w.getBoundingClientRect().bottom;}'
    + 'return Math.round(b||0);}catch(e){return 0;}})()';
  win.webContents.executeJavaScript(probe, true).then(function(bot){
    try {
      if (!win || win.isDestroyed() || cfg.hudOnly) return;
      const b = win.getBounds();
      let zf = 1; try { zf = win.webContents.getZoomFactor() || 1; } catch (e) {}
      let want;
      if (bot && bot > 200) want = Math.round((bot + 46) * zf);
      else {  /* page not ready - fall back to the ratio, better than nothing */
        const z = Math.min(1.8, Math.max(0.5, (b.width / zf) / 1700));
        want = Math.round((1130 * z + 44) * zf);
      }
      try { const wa = screen.getDisplayMatching(b).workArea;
            if (want > wa.height) want = wa.height; } catch (e) {}
      if (Math.abs(want - b.height) > 8)
        setBounds({ x: b.x, y: b.y, width: b.width, height: want }, 'aspect-' + (why || ''));
    } catch (e) {}
  }).catch(function(){});
}
function applyZoom() {
  if (!win || win.isDestroyed()) return cfg.zoomFactor;
  cfg.zoomFactor = clampZoom(cfg.zoomFactor);
  try { win.webContents.setZoomFactor(cfg.zoomFactor); } catch (e) {}
  try { cgTabletVMin(); } catch (e) {}   /* CG767_VMIN - a zoom change moves the minimum */
  return cfg.zoomFactor;
}
function setZoom(z, quiet) {
  cfg.zoomFactor = clampZoom(z);
  applyZoom(); saveConfig();
  if (!quiet) { try { toast('ZOOM ' + Math.round(cfg.zoomFactor * 100) + '%', false, 900); } catch (e) {} }
  return cfg.zoomFactor;
}

/* CG767_CORNERPRESS - build 290. STRIKE TWO on "HUD corners on/off still
   isn't working", so the METHOD CHANGES; restating the old one in more words
   is not a change and the two-strike rule refuses it.

   WHAT FAILED, NAMED EXACTLY: the old action was
       executeJavaScript('window.__cg767corners && window.__cg767corners()')
         .catch(() => {})
   Three links, every one of them silent. `&&` swallows an undefined function,
   `.catch(()=>{})` swallows a rejected script, and a throw inside the page
   function is caught by the page function itself. All three failure modes look
   IDENTICAL from out here, which is why two builds could not tell them apart.
   MEASURED, so this is not a theory: hotkey_report.json says Control+= is
   REGISTERED, and the armed dump still reads cnr.why "dial off" - the key
   fires, the dial never moves. The break is inside those three links.

   WHAT CHANGED, IN TWO PARTS:
   1. IT NO LONGER DEPENDS ON THE PAGE FUNCTION AT ALL. The script sets the
      localStorage dial itself and asks the page to repaint. window.__cg767corners
      being missing can no longer stop it.
   2. IT REPORTS WHAT HAPPENED TO DISK. corner_press.json, beside this file,
      carries the dial's value after the press and the typeof of the page
      function. 12.5: an instrument T cannot reach is not an instrument, and
      this overlay is an app window with no console and no F12.
   No silent catch survives: the reject path writes the error rather than
   discarding it (GATE G). */
function cornerPress() {
  if (!win) { try { fs.writeFileSync(path.join(__dirname, 'corner_press.json'),
      JSON.stringify({ at: new Date().toString(), err: 'no overlay window' }, null, 2)); } catch (e) {} return; }
  const js = "(function(){try{" +
    "var on=(localStorage.getItem('cg767_corners')||'0')==='1';" +
    "localStorage.setItem('cg767_corners', on?'0':'1');" +
    "var r=null; try{ if(window.__cgB767&&window.__cgB767.repaint){window.__cgB767.repaint(); r='repaint';} }catch(e){ r='repaint threw '+e.message; }" +
    "return {dial:localStorage.getItem('cg767_corners'), fn:(typeof window.__cg767corners), repaint:r, " +
    "stamp:String(window.CG767_STAMP||''), cnr:(window.__cg767cnr||null)};" +
    "}catch(e){return {err:String(e&&e.message||e)};}})()";
  const stamp = (o) => { try { fs.writeFileSync(path.join(__dirname, 'corner_press.json'),
      JSON.stringify(Object.assign({ at: new Date().toString() }, o), null, 2)); } catch (e) {} };
  win.webContents.executeJavaScript(js, true)
     .then((r) => { stamp({ ok: true, result: r }); try { toast('CORNERS ' + ((r && r.dial) === '1' ? 'ON' : 'OFF')); } catch (e) {} })
     .catch((e) => stamp({ ok: false, err: String((e && e.message) || e) }));
}
function actionFns() {
  return {
    toggleClickThrough: () => setClickThrough(!clickThrough),
    toggleVisible:      () => { if (win) (win.isVisible() ? win.hide() : win.show()); },
    reload:             () => { if (win) win.loadURL(cfg.url+(cfg.url.includes('?')?'&':'?')+'cb='+Date.now()); },   /* CG767_FRESHLOAD */
    settings:           () => toggleSettings(),   /* CG767_SETTOGGLE - T, 16 AUG: same key closes it */
    dimCycle:           () => cycleDim(),
    dim25:              () => setDim(25),
    dim50:              () => setDim(50),
    dim75:              () => setDim(75),
    dim100:             () => setDim(100),
    toggleHudOnly:      () => setHudOnly(!cfg.hudOnly),
    /* CG767_CORNERHK - build 287. T: "the hud needs corner markers so i can
       tell where the display area is for the hud." The dots live in the page
       (b767_dev.js CG767_CORNERS); this only presses the switch, the same way
       __cgOvlFit is pressed at ~1449. NO DEFAULT COMBO IS SHIPPED - it lands
       in DEFAULTS.hotkeys as '' so registerHotkeys() skips it and it shows in
       the HOTKEYS window as (not set) for HIM to assign. Never pick a key for
       him: the SC export lists only REBINDABLE actions, so a hardcoded game
       key (backtick = console) reads as free and is not. That already shipped
       wrong once. */
    toggleCorners:      () => cornerPress(),
    zoomIn:             () => setZoom((cfg.zoomFactor || 1) + ZOOM_STEP),
    zoomOut:            () => setZoom((cfg.zoomFactor || 1) - ZOOM_STEP),
    zoomReset:          () => setZoom(1)
  };
}

/** Register everything, and REPORT what failed instead of whispering to a console. */
function registerHotkeys() {
  globalShortcut.unregisterAll();
  const fns = actionFns();
  const bad = [];
  /* CG767_HKREPORT - build 288. T assigned Ctrl+= to the corner dots, pressed
     it, and the dial in the page was still off. Whether register() returned
     false, or the combo was rejected, or the page function was never reached,
     is NOT ANSWERABLE from here - every one of them looks identical from
     outside, and the console this writes to is unreachable in an app window
     with no F12 (S22, "f12 does not open devtools"). So it goes to DISK,
     beside this file, where it can be read off the mount. 12.5: an instrument
     T cannot reach is not an instrument. READ-ONLY, changes no behaviour. */
  const regOk = {};
  for (const action of Object.keys(fns)) {
    const combo = cfg.hotkeys[action];
    if (!combo) { regOk[action] = { combo: '', result: 'not set' }; continue; }
    if (!KM.isRegistrableKey(combo)) { bad.push(labelOf(action) + ': "' + combo + '" is not a key Electron accepts'); regOk[action] = { combo, result: 'REJECTED - not a key Electron accepts' }; continue; }
    let ok = false;
    try { ok = globalShortcut.register(combo, fns[action]); } catch (e) { ok = false; }
    if (!ok) bad.push(labelOf(action) + ': ' + KM.pretty(combo) + ' is already taken');
    regOk[action] = { combo, result: ok ? 'REGISTERED' : 'REFUSED - already taken by something else' };
  }
  try {
    fs.writeFileSync(path.join(__dirname, 'hotkey_report.json'),
      JSON.stringify({ at: new Date().toString(), rows: regOk }, null, 2));
  } catch (e) {}
  const clash = [];
  if (scBinds.ok) {
    for (const action of Object.keys(fns)) {
      const c = KM.canon(cfg.hotkeys[action], false);
      const hit = c && scBinds.index.get(c);
      if (hit && hit.length) clash.push(labelOf(action) + ': ' + KM.pretty(cfg.hotkeys[action]) + ' = ' + hit[0].action);
    }
  }
  startupReport = [];
  /* CG767_HKTOAST - build 289. T, with the picture: "this wall of text needs to
     go away. that's too much to be read during a regular warning." He is right.
     Fourteen named keys in a startup toast cannot be read, and the detail
     already lives on disk in hotkey_report.json from 288.
     AND THE WALL WAS SAYING ONE THING, NOT FOURTEEN. hotkey_report.json at
     14:03:51 reads REGISTERED for all fourteen, Control+= included - so nothing
     on this machine competes for them. Every key reporting "already taken" at
     once means a SECOND COPY OF THIS OVERLAY was still holding them. 18.9's
     zombie test: one Electron app is 4+ processes. The line now SAYS that
     instead of making him work it out from a list.
     COUNTS ONLY, NEVER NAMES, for the partial case. The names are on disk. */
  const nHot = Object.keys(fns).filter(a => cfg.hotkeys[a]).length;
  if (nHot > 0 && bad.length >= nHot) {
    startupReport.push('HOTKEYS BLOCKED - another copy of the overlay is already running. Close it and start once.');
  } else if (bad.length) {
    startupReport.push('HOTKEYS  ' + bad.length + ' of ' + nHot + ' not working  -  open HOTKEYS on the drag strip');
  }
  if (clash.length) startupReport.push('SC CLASH  ' + clash.length + '  -  open HOTKEYS on the drag strip');
  bad.forEach(b => console.error('HOTKEY: ' + b));
  clash.forEach(c => console.error('SC CLASH: ' + c));
  return { bad, clash };
}
function labelOf(a) { return (ACTION_LABELS[a] && ACTION_LABELS[a][0]) || a; }

// ---------------------------------------------------------------------------
//  the hotkey editor window
// ---------------------------------------------------------------------------
/* CG767_SETTOGGLE - T, 16 AUG 2026: "I need the next press on CTRL 8 to
   close the hotkeys window." openSettings() only ever showed and focused,
   so a second press did nothing visible. close() is used rather than
   hide() because the existing 'closed' handler already nulls setWin, so
   there is exactly one owner of that variable and no second teardown to
   keep in step. REVERT: point the settings action back at openSettings
   and delete this function. */
function toggleSettings() {
  try {
    if (setWin && !setWin.isDestroyed()) { setWin.close(); return; }
  } catch (e) { setWin = null; }
  openSettings();
}
function openSettings() {
  if (setWin && !setWin.isDestroyed()) { setWin.show(); setWin.focus(); return; }
  setWin = new BrowserWindow({
    width: 900, height: 760, title: 'CmdGlas Overlay - Hotkeys',
    backgroundColor: '#0b1017', autoHideMenuBar: true, alwaysOnTop: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload-settings.js'),
      contextIsolation: true, nodeIntegration: false
    }
  });
  setWin.loadFile(path.join(__dirname, 'settings.html'));
  setWin.on('closed', () => { setWin = null; });
}

ipcMain.handle('cg:getState', () => ({
  hotkeys: JSON.parse(JSON.stringify(cfg.hotkeys)),
  labels: ACTION_LABELS,
  order: Object.keys(ACTION_LABELS),
  sc: { ok: scBinds.ok, path: scBinds.path, count: scBinds.count || 0,
        skipped: scBinds.skipped || 0, generated: scBinds.generated || null,
        source: scBinds.source || null, error: scBinds.error || null },
  cfg: { url: cfg.url, dimTarget: cfg.dimTarget, shrinkOnCompact: cfg.shrinkOnCompact,
         clickThroughOnStart: cfg.clickThroughOnStart, showDragBar: cfg.showDragBar }
}));

ipcMain.handle('cg:check', (_e, { combo, action, draft }) => {
  return KM.checkCombo(combo, {
    selfMap: draft || cfg.hotkeys, selfAction: action, scIndex: scBinds,
    tryRegister: (c) => {
      // A combination the overlay itself already holds would look "taken" by the
      // overlay. Drop everything, test, then put it all back.
      try {
        globalShortcut.unregisterAll();
        let ok = false;
        try { ok = globalShortcut.register(c, () => {}); } catch (_) { ok = false; }
        if (ok) globalShortcut.unregister(c);
        return ok;
      } finally { registerHotkeys(); }
    }
  });
});

ipcMain.handle('cg:save', (_e, { hotkeys, options }) => {
  const before = JSON.parse(JSON.stringify(cfg.hotkeys));
  cfg.hotkeys = Object.assign({}, cfg.hotkeys, hotkeys || {});
  if (options && typeof options.shrinkOnCompact === 'boolean') cfg.shrinkOnCompact = options.shrinkOnCompact;
  if (options && ['window', 'content', 'hud'].indexOf(options.dimTarget) >= 0) cfg.dimTarget = options.dimTarget;
  const saved = saveConfig();
  if (!saved) { cfg.hotkeys = before; registerHotkeys(); return { ok: false, error: 'could not write overlay.config.json' }; }
  const r = registerHotkeys();
  applyDim(false);
  toast('HOTKEYS SAVED', false, 1600);
  return { ok: true, bad: r.bad, clash: r.clash };
});

ipcMain.handle('cg:reveal', () => { try { shell.showItemInFolder(CONFIG_FILE); } catch (_) {} });

// ---------------------------------------------------------------------------
app.on('render-process-gone', function(ev, wc, details){ try{ cgLogErr('renderer-gone', JSON.stringify(details)+' url='+(wc&&wc.getURL&&wc.getURL())); }catch(_e){} });   /* CG767_ERRLOG - a crashed/killed page names itself */
app.on('child-process-gone', function(ev, details){ try{ cgLogErr('child-gone', JSON.stringify(details)); }catch(_e){} });
app.whenReady().then(() => {
  startControlServer();   /* v1.2.13 - Stream Deck URL control on 127.0.0.1:8422 */
  cfg = loadConfig();
  scBinds = findScBinds();
  console.log(scBinds.ok
    ? ('keybind export: ' + scBinds.path + '  (' + scBinds.count + ' keyboard binds, ' + scBinds.skipped + ' mouse/wheel skipped)')
    : ('NO keybind export found - the Star Citizen conflict check is UNAVAILABLE, which is not the same as "no conflicts". ' + (scBinds.error || '')));
  createWindow();
  registerHotkeys();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('will-quit', () => globalShortcut.unregisterAll());
app.on('window-all-closed', () => app.quit());
