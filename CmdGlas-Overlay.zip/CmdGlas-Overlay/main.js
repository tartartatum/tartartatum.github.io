// =============================================================================
//  CmdGlas Overlay  -  transparent, always-on-top shell for the command tablet
//  v1.2  -  3 AUG 2026
//
//  WHAT CHANGED IN 1.2, all of it from T using the thing:
//    1. "i cant move it"
//         -> a drag strip across the top, shown only when it can be used.
//            (This existed in the 1.1 source but was NEVER INSTALLED - his PC was
//             still running 1.0, 7014 bytes, which is why the strip never came.)
//    2. "when detached i need to be able to increase the size of the hud to
//        fullscreen by dragging"
//         -> four corner grips that resize the window, plus a MAX button.
//            A TRANSPARENT window has no grabbable edge - Windows hit-testing
//            passes straight through the clear pixels - so the grips are drawn in
//            the page and drive setBounds directly. That is the only way.
//    3. "let the user hide everything underneath the assist nav my rig row. once
//        hidden close the tablet in around the new size"
//         -> the window now shrinks to fit when the tablet reports COMPACT, and
//            goes back to the size it was when it reports FULL.
//    4. "some people have your hotkeys as inflight keybinds" /
//       "make the hotkeys customizable during setup"
//         -> a hotkey editor with a live conflict check against the pilot's own
//            Star Citizen export. Press a combination and it tells you, before
//            you keep it, whether the game already uses it.
//
//  A BUG THIS VERSION FIXES, FOUND BY CHECKING RATHER THAN BY IT BREAKING.
//  T's config had  dim100: "Control+Shift+numenter".  There is no "numenter" in
//  Electron's accelerator vocabulary, so that hotkey registered as nothing and
//  failed silently - the only sign was a line in a console nobody sees. 1.2
//  validates every combo at startup and puts the result ON SCREEN.
//
//  WHAT IT STILL DOES NOT DO: read game memory, send input, hook the game, or
//  touch anything anti-cheat cares about. It is a window that draws on top.
//
//  v1.2.14  -  4 AUG 2026.  T: "when i selected the buttons inside your hud
//  nothing happened."  THE BUTTONS WERE NEVER DEAD. clickThroughOnStart was true
//  and a HUD-only launch therefore called setIgnoreMouseEvents(true) at startup,
//  so Windows never delivered his mouse to the window at all. The only tell was a
//  toast that had already faded after six seconds.
//    (a) A PERSISTENT amber badge (#cg-ovl-ctbadge) is shown for as long as
//        click-through is on, and it names the key that turns it off.
//    (b) The badge is whitelisted in the HUD-only sweep's skip() - the sweep
//        inline-hides every unknown top-level node, which would have hidden the
//        one element whose whole job is to be visible (RULE 18 family).
//    (c) clickThroughOnStart now defaults to FALSE. The HUD starts interactive;
//        click-through is a thing you turn ON for flight, not a thing you have to
//        discover is already on.
//  v1.2.15  -  4 AUG 2026.  T: "remove the cmdglas overlay title from the top
//  left. there is no visual seperation between drag to move whole tablet and the
//  gather and buy and notes."
//    (a) The "CMDGLAS OVERLAY" title is gone from the drag strip.
//    (b) The strip is the WINDOW's row, not the tablet's, and it now looks like
//        it: at rest only the shadow of its words shows and its cloud drops to
//        ~1/5 weight, so the tablet's own tab row is the only lit thing up there.
//        Hovering anywhere on the strip brings the whole row up at once.
//  v1.2.16  -  4 AUG 2026.  T: "why is there a hud only button on the tablet
//  that doesn't work when the tablet is open ... too many controls as it stands
//  now."  Three controls read as undock in whole-tablet mode; two of them were.
//    (a) The strip's HUD ONLY button is not rendered while the tablet is docked.
//        The tablet's own UNDOCK (bottom row) is the only undock control.
//    (b) In HUD-only that same strip button returns, labelled DOCK TABLET - the
//        one action the HUD cannot otherwise reach. Ctrl+Alt+Shift+H does it too.
//    (c) The "HUD" caret is relabelled OPTS in whole-tablet mode. It was
//        never an undock control: the tablet's own title attribute on it reads
//        "HUD settings - transparency, brightness, colour".
//  VERIFY LESSON, PAID FOR: CDP/synthetic clicks BYPASS setIgnoreMouseEvents.
//  A sweep of synthetic clicks reported every control firing while T's real mouse
//  did nothing. Click-through behaviour is NEVER verified from synthetic clicks.
// =============================================================================
'use strict';
const { app, BrowserWindow, globalShortcut, screen, ipcMain, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const KM = require('./keymap.js');

const CONFIG_FILE = path.join(__dirname, 'overlay.config.json');
// The keybind export lives with the control server, one level up from this folder.
// Both spellings are tried because the Tools copy is the one the sync writes.
const SC_BIND_CANDIDATES = [
  path.join(__dirname, '..', 'MASTER_KEYBINDS.json'),
  path.join(__dirname, '..', 'Tools', 'MASTER_KEYBINDS.json'),
  path.join(__dirname, 'MASTER_KEYBINDS.json')
];

const DEFAULTS = {
  /* PUBLIC BY DEFAULT. A fresh install needs no control server, no Node, no local
     files - it loads the published tablet. T's own config points at his localhost
     because he runs the server and it carries the newest build; that is a CHOICE in
     his config file, not a requirement of the app. */
  url: 'https://cmdglas.com/',
  fallbackUrl: 'https://cmdglas.com/',
  hudOnly: false,
  dimTarget: 'window',            // window | content | hud
  dimLevel: 100,                  // 25 | 50 | 75 | 100
  /* v1.2.14: was true. A HUD-only launch then began with the mouse passing
     straight through to the game, which reads exactly like dead buttons.
     Start interactive; Ctrl+Shift+F12 turns click-through on for flight. */
  clickThroughOnStart: false,
  showDragBar: true,
  shrinkOnCompact: true,          // follow the tablet's COMPACT switch
  minWidth: 320,
  minHeight: 200,
  hotkeys: {
    toggleClickThrough: 'Control+Alt+2',
    toggleVisible:      'Control+Alt+3',
    reload:             'Control+Alt+4',
    dimCycle:           'Control+Alt+5',
    settings:           'Control+Alt+6',
    dim25:              'Control+Alt+7',
    dim50:              'Control+Alt+8',
    dim75:              'Control+Alt+9',
    dim100:             'Control+Alt+0',
    toggleHudOnly:      'Control+Alt+Shift+H'
  }
};
// Plain English for the editor. The key order here is the row order on screen.
const ACTION_LABELS = {
  toggleClickThrough: ['Click through on / off', 'When ON the mouse passes through to the game. Turn it OFF to use the tablet.'],
  toggleVisible:      ['Hide / show the overlay', 'Gets the whole thing out of the way without closing it.'],
  reload:             ['Reload the tablet',       'Pulls the newest build from the control server.'],
  settings:           ['Open these settings',     'This window.'],
  dimCycle:           ['Brightness - next step',  'Steps 25 - 50 - 75 - 100 and round again.'],
  dim25:              ['Brightness 25%',          ''],
  dim50:              ['Brightness 50%',          ''],
  dim75:              ['Brightness 75%',          ''],
  dim100:             ['Brightness 100%',         'Back to solid. Worth keeping somewhere you can find by feel.'],
  toggleHudOnly:      ['HUD only / whole tablet',  'HUD only shows just the floating HUD. The whole tablet is one key away.']
};
const STEPS = [25, 50, 75, 100];

let win = null, setWin = null, cfg = JSON.parse(JSON.stringify(DEFAULTS));
let clickThrough = true, scBinds = { ok: false }, startupReport = [];
let fullBounds = null, compactNow = false, rzAnchor = null;
let sizeState = { full: null, hud: null };

// Every move of the window goes through here and says WHY. When something ends up
// the wrong size the log is a record instead of a guess - which is the only way to
// tell "compact shrank it" from "a resize grip did" after the fact.
function setBounds(b, why) {
  if (!win) return;
  const n = { x: Math.round(b.x), y: Math.round(b.y), width: Math.round(b.width), height: Math.round(b.height) };
  win.setBounds(n, false);
  console.log('BOUNDS ' + why + ' ' + n.x + ',' + n.y + ' ' + n.width + 'x' + n.height);
}

// ---------------------------------------------------------------------------
//  config
// ---------------------------------------------------------------------------
/* A URL given on the command line or in CG_URL beats the config file. That is how
   "3 - RUN OVERLAY (TEST BUILD).bat" points the same app at the TEST tablet without
   touching overlay.config.json - so the test launcher and the normal launcher can
   never fight over one setting. */
function urlOverride() {
  try {
    for (const a of process.argv) {
      const m = /^--url=(.+)$/.exec(a);
      if (m && m[1]) return m[1];
    }
    if (process.env.CG_URL) return process.env.CG_URL;
  } catch (e) {}
  return null;
}
function hudOnlyArg() {
  try { return process.argv.indexOf('--hud') >= 0 || process.env.CG_HUD === '1'; }
  catch (e) { return false; }
}

function loadConfig() {
  let c = JSON.parse(JSON.stringify(DEFAULTS));
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      const u = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
      Object.assign(c, u);
      c.hotkeys = Object.assign({}, DEFAULTS.hotkeys, u.hotkeys || {});
    } else {
      fs.writeFileSync(CONFIG_FILE, JSON.stringify(DEFAULTS, null, 2), 'utf8');
    }
  } catch (e) { console.error('config unreadable, using defaults:', e.message); }
  if (STEPS.indexOf(c.dimLevel) < 0) c.dimLevel = 100;
  if (['window', 'content', 'hud'].indexOf(c.dimTarget) < 0) c.dimTarget = 'window';
  const ov = urlOverride();
  if (ov) { c.url = ov; c.__urlFromArg = true; }
  if (hudOnlyArg()) { c.hudOnly = true; c.__hudFromArg = true; }
  return c;
}
function saveConfig() {
  // write to a temp file and rename, so a crash mid-write cannot leave a
  // half-written config that stops the overlay starting next time
  try {
    const tmp = CONFIG_FILE + '.tmp';
    const out = JSON.parse(JSON.stringify(cfg));
    delete out.__urlFromArg; delete out.__hudFromArg;
    if (cfg.__urlFromArg) delete out.url;          // a test URL must never become the saved one
    if (cfg.__hudFromArg) delete out.hudOnly;      // nor a --hud launch
    fs.writeFileSync(tmp, JSON.stringify(out, null, 2), 'utf8');
    fs.renameSync(tmp, CONFIG_FILE);
    return true;
  } catch (e) { console.error('could not save config:', e.message); return false; }
}

const STATE_FILE = path.join(app.getPath('userData'), 'window-state.json');
function loadState() { try { return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); } catch (e) { return null; } }
function saveState() {
  if (!win) return;
  try {
    fs.mkdirSync(path.dirname(STATE_FILE), { recursive: true });
    // never save the SHRUNK size as the window's own size, or COMPACT would be
    // sticky across restarts and there would be no way back to the full layout
    const b = fullBounds || win.getBounds();
    const prev = loadState() || {};
    const out = cfg.hudOnly
      ? Object.assign({}, prev, { hudW: b.width, hudH: b.height, x: b.x, y: b.y })
      : Object.assign({}, prev, { width: b.width, height: b.height, x: b.x, y: b.y });
    fs.writeFileSync(STATE_FILE, JSON.stringify(out), 'utf8');
  } catch (e) {}
}

function findScBinds() {
  for (const p of SC_BIND_CANDIDATES) {
    if (fs.existsSync(p)) return KM.loadStarCitizenBinds(fs, p);
  }
  return { ok: false, path: SC_BIND_CANDIDATES[0], count: 0, index: new Map(), error: 'no MASTER_KEYBINDS.json found' };
}

// ---------------------------------------------------------------------------
//  the page-side furniture: drag strip, toast, dimmer, resize grips, compact
//  reporter.  All of it injected, because the tablet HTML knows nothing about
//  being in an overlay and should not have to.
// ---------------------------------------------------------------------------
const OVL_CSS = `
/* the portrait gate is for phones, not for a window the pilot sized themselves */
#cg-rotate-lock{ display:none !important; }
/* v1.2.12 - T: "the bright pill on top of the hud ... needs to be borderless and
   fade to black like everything else in the tablet but with a small pulse in the
   cloud it sits on. sharp and easier readable, more contrast."
   The solid blue bar becomes the HUD's own language: no border, no fill - a soft
   cloud that breathes (4s, subtle), crisp bright text on a dark contact shadow. */
#cg-ovl-drag{
  position:fixed; left:14px; right:14px; top:10px; height:30px; z-index:2147483646;
  -webkit-app-region:drag; display:none; align-items:center; justify-content:center;
  gap:12px; font:800 10px/1 'Rajdhani','Segoe UI',sans-serif; letter-spacing:2px;
  color:rgba(234,246,255,.22); background:none; border:0;
  text-shadow:0 1px 2px rgba(0,7,14,.95), 0 0 3px rgba(0,10,20,.8);
  cursor:move; user-select:none; transition:color .16s ease; }
#cg-ovl-drag:hover{ color:#eaf6ff; }
#cg-ovl-drag::before{
  content:''; position:absolute; left:-4%; right:-4%; top:-140%; bottom:-90%;
  z-index:-1; pointer-events:none;
  background:radial-gradient(52% 88% at 50% 42%,
    rgba(9,22,36,.85) 0%, rgba(9,22,36,.55) 45%,
    rgba(70,170,220,.10) 68%, transparent 82%);
  animation:cgOvlBreathe 4s ease-in-out infinite;
  transition:opacity .16s ease; }
/* v1.2.15 - T: "there is no visual seperation between drag to move whole tablet
   and the gather and buy and notes."
   THE TWO ROWS WERE THE SAME BRIGHTNESS AND THE SAME CLOUD, so they read as one
   six-item bar. This row belongs to the WINDOW, not to the tablet, so at rest it
   is only the shadow of its own words - the cloud drops to a fifth of its old
   weight and the text keeps its dark contact shadow with almost no fill. Reach
   for it and the whole row comes up together, so nothing has to be hunted for.
   The tablet's own row is untouched and is now the only lit thing up there. */
@keyframes cgOvlBreathe{
  0%,100%{ opacity:.16; } 50%{ opacity:.24; } }
#cg-ovl-drag:hover::before{ animation:none; opacity:1; }
#cg-ovl-drag.on{ display:flex; }
#cg-ovl-drag span{ color:rgba(159,194,214,.22); transition:color .16s ease; }
#cg-ovl-drag button{
  -webkit-app-region:no-drag; cursor:pointer; font:800 10px/1 'Rajdhani','Segoe UI',sans-serif;
  letter-spacing:1.8px; color:rgba(223,242,255,.22); background:none; border:0; padding:5px 9px;
  text-shadow:0 1px 2px rgba(0,7,14,.95);
  transition:color .16s ease, text-shadow .16s ease; }
/* HOVER ANYWHERE ON THE ROW LIGHTS THE WHOLE ROW. Lighting only the one button
   under the pointer would still leave the others invisible, and you cannot aim
   at a word you cannot see. */
#cg-ovl-drag:hover span{ color:#9fc2d6; }
#cg-ovl-drag:hover button{ color:#dff2ff;
  text-shadow:0 1px 2px rgba(0,7,14,.95), 0 0 5px rgba(90,200,255,.35); }
#cg-ovl-drag button:hover{ color:#ffffff;
  text-shadow:0 1px 2px rgba(0,7,14,.95), 0 0 9px rgba(140,225,255,.9); }
/* v1.2.15 - HUD-only has no shutdown control. Dock, then close. */
#cg-ovl-drag.cg-hudmode button[data-a="close"]{ display:none !important; }
/* v1.2.16 - T: "too many controls as it stands now."  MEASURED in whole-tablet:
   THREE controls read as undock and only two were - the strip's HUD ONLY (83x20),
   the tablet's own UNDOCK (44x12, bottom row) and the HUD caret, which is not an
   undock control at all. T's ruling: the tablet's own UNDOCK is the one that
   survives, so the strip's button is not rendered while the tablet is docked. In
   HUD-only it comes back as the DOCK control, which is the one thing the HUD has
   no other way to do. */
#cg-ovl-drag:not(.cg-hudmode) button[data-a="hud"]{ display:none !important; }
/* v1.2.16 - THE CARET IS NOT A HUD BUTTON. Its own title attribute in the tablet
   source says "HUD settings - transparency, brightness, colour", and it reads
   "HUD" with a chevron, which is why it looked like a HUD ONLY button that did
   nothing. Relabelled, not hidden - the panel behind it is real.
   WHOLE-TABLET ONLY: in HUD-only the tablet drives this same ::before itself for
   the tint glow (4 rules, all guarded by cg-hudonly/cg-holo - checked), and
   "HUD" is the right word when you are already in the HUD. The selector carries
   the id and outweighs the tablet's own #sc-home-widgets rule (RULE 18).
   MEASURED, first attempt failed: the guard was :not(.cg-hudonly):not(.cg-holo)
   and NOTHING applied - the tablet runs classList.toggle('cg-holo', m!=='panel'),
   so cg-holo is ON in normal use and my own guard was switching my rule off. The
   cg-holo ::before rules it was meant to avoid all require a .cg-pop-float
   ancestor, and RULE 20 says the overlay never spawns a float, so they cannot
   collide in here. Guard dropped. */
html:not(.cg-hudonly) body #sc-home-widgets .ops-pill.b385 .cg-hs-chev{
  font-size:0 !important; }
html:not(.cg-hudonly) body #sc-home-widgets .ops-pill.b385 .cg-hs-chev::before{
  /* MEASURED: 'HUD OPTIONS' at 9px came out 106px wide against the 43px the
     caret had, and the tab row does not reflow around it - the label printed
     straight over the STREAM tab. 'OPTIONS' at 8px was still 72px and still
     overlapped. MEASURED BUDGET IS THE 43px THE OLD LABEL HAD - the tab row does
     not reflow, so the label has to fit the hole, not just say the right thing.
     'OPTS' is what fits. The full sentence is still on the button's own title
     attribute: "HUD settings - transparency, brightness, colour". */
  content:'OPTS' !important;
  font:700 8px 'Rajdhani','Segoe UI',sans-serif !important; letter-spacing:.6px !important;
  background:none !important; box-shadow:none !important; }
html:not(.cg-hudonly) body #sc-home-widgets .ops-pill.b385 .cg-hs-chev{
  padding-left:6px !important; padding-right:6px !important; }
html:not(.cg-hudonly) body #sc-home-widgets .ops-pill.b385 .cg-hs-chev .cv{
  font-size:8px !important; }
/* v1.2.16 - T: "fix offset too close to frame". The strip sat at top:2px, so
   its caps ran into the window edge. Lane moved to top:10px and every
   clearance below it moved with it - 26 -> 44 here, 28 -> 44 inline. */
body.cg-ovl-draggable{ padding-top:44px !important; box-sizing:border-box; }
#cg-ovl-toast{
  position:fixed; left:50%; top:38px; transform:translateX(-50%); z-index:2147483647;
  padding:9px 16px; border-radius:9px; pointer-events:none; opacity:0; max-width:80vw;
  transition:opacity .18s ease; font:800 12.5px/1.45 'Rajdhani','Segoe UI',sans-serif;
  letter-spacing:1.6px; color:#04141d; text-align:center;
  background:linear-gradient(180deg,#a6f2ff,#33b5e6); box-shadow:0 4px 16px rgba(0,0,0,.5); }
#cg-ovl-toast.warn{ background:linear-gradient(180deg,#ffd479,#e0a000); }
#cg-ovl-toast.on{ opacity:1; }
/* THE RESIZE GRIPS. A transparent window has no edge Windows can grab, so the
   corners are drawn here and they drive setBounds themselves. Shown only when
   click-through is off, so they can never sit over the game while flying. */
.cg-ovl-rz{
  position:fixed; width:38px; height:38px; z-index:2147483645; display:none;
  -webkit-app-region:no-drag; }
body.cg-ovl-draggable .cg-ovl-rz{ display:block; }
/* v1.2.6 - T: "the resize control dissapeard" + earlier "draw a little bit of
   attention to the 3 dots with a recize symbol. it's super easy to miss especially
   with the star darkeness background". Same language as the tablet's browser grip:
   soft halo, three dots, a resize arrow. Bottom-right carries the arrow. */
body.cg-ovl-draggable .cg-ovl-rz{
  background: radial-gradient(50% 50% at 55% 55%, rgba(90,190,240,.20), transparent 72%); }
#cg-ovl-rz-se::before{ content:'\u2921'; position:absolute; left:-2px; top:-4px;
  font:700 17px sans-serif; color:rgba(175,238,255,.95);
  text-shadow:0 0 8px rgba(120,215,255,.95); pointer-events:none; }
#cg-ovl-rz-se:hover::before{ color:#ffffff; }
/* T: "no triangles". The grips used to be L-shaped brackets, which are corners of a
   box - the exact thing the slab is trying not to look like. They are soft dots now:
   round, no angle anywhere, and they only exist while click-through is off. */
.cg-ovl-rz::after{
  content:''; position:absolute; inset:9px; border-radius:50%;
  background:
    radial-gradient(circle 3px at 78% 78%, rgba(200,250,255,.95), transparent 70%),
    radial-gradient(circle 3px at 78% 40%, rgba(180,240,255,.85), transparent 70%),
    radial-gradient(circle 3px at 40% 78%, rgba(180,240,255,.85), transparent 70%); }
.cg-ovl-rz:hover::after{
  background:
    radial-gradient(circle 3px at 78% 78%, #ffffff, transparent 70%),
    radial-gradient(circle 3px at 78% 40%, rgba(225,252,255,1), transparent 70%),
    radial-gradient(circle 3px at 40% 78%, rgba(225,252,255,1), transparent 70%); }
/* v1.2.14 - THE CLICK-THROUGH BADGE. A toast is an event; click-through is a
   STATE, and a state needs a tell that stays. Amber, not cyan: this is the
   tablet's only "you cannot touch me" condition and it must not read as chrome.
   pointer-events:none so it can never eat a click in the interactive state, and
   it lives in the same top-centre lane as the drag strip - the two are mutually
   exclusive by construction (setDragBar(!clickThrough) / setCtBadge(clickThrough)). */
#cg-ovl-ctbadge{
  position:fixed; left:50%; top:10px; transform:translateX(-50%); z-index:2147483647;
  display:none; pointer-events:none; padding:6px 15px; border-radius:8px;
  font:800 11px/1.35 'Rajdhani','Segoe UI',sans-serif; letter-spacing:1.7px;
  color:#2a1a00; text-align:center; white-space:nowrap;
  background:linear-gradient(180deg,#ffd479,#e0a000);
  box-shadow:0 3px 14px rgba(0,0,0,.55); }
#cg-ovl-ctbadge.on{ display:block; }
#cg-ovl-rz-nw{ left:2px; top:28px; cursor:nwse-resize; }
#cg-ovl-rz-ne{ right:2px; top:28px; cursor:nesw-resize; }
#cg-ovl-rz-sw{ left:2px; bottom:2px; cursor:nesw-resize; }
#cg-ovl-rz-se{ right:2px; bottom:2px; cursor:nwse-resize; }
`;

// Everything the page sends back to main goes through console.log with this
// prefix. It is a one-way channel that needs no preload and no node integration
// in the tablet page - the tablet stays an ordinary web page.
const OVL_JS = `
(function(){
  var TAG='CGOVL\\u00a7';
  function send(o){ try{ console.log(TAG+JSON.stringify(o)); }catch(e){} }
  window.__cgOvlSend=send;

  if(!document.getElementById('cg-ovl-drag')){
    var d=document.createElement('div'); d.id='cg-ovl-drag';
    /* v1.2.15 - T: "remove the cmdglas overlay title from the top left."
       The app does not need to announce itself on every frame of his screen. */
    d.innerHTML='<span>DRAG TO MOVE</span>'
      +'<button type="button" data-a="hud" id="cg-ovl-hudbtn">HUD ONLY</button>'
      +'<button type="button" data-a="max">MAX</button>'
      +'<button type="button" data-a="fit">FIT</button>'
      +'<button type="button" data-a="settings">HOTKEYS</button>'
      +'<button type="button" data-a="close" title="Close the overlay window">\u2715 CLOSE</button>'; /* v1.2.3 - T: "the tablet needs a way to be closed from the onscreen tablet surface" */
    document.body.appendChild(d);
    d.addEventListener('click', function(e){
      var b=e.target.closest && e.target.closest('button[data-a]');
      if(b) send({act:b.getAttribute('data-a')});
    });
  }
  if(!document.getElementById('cg-ovl-toast')){
    var t=document.createElement('div'); t.id='cg-ovl-toast'; document.body.appendChild(t);
  }
  /* v1.2.14 - the persistent click-through tell. Built once, shown by class. */
  if(!document.getElementById('cg-ovl-ctbadge')){
    var cb=document.createElement('div'); cb.id='cg-ovl-ctbadge';
    cb.textContent='CLICK-THROUGH ON \\u00b7 MOUSE GOES TO GAME \\u00b7 CTRL+SHIFT+F12';
    document.body.appendChild(cb);
  }
  ['nw','ne','sw','se'].forEach(function(c){
    if(document.getElementById('cg-ovl-rz-'+c)) return;
    var g=document.createElement('div'); g.className='cg-ovl-rz'; g.id='cg-ovl-rz-'+c;
    document.body.appendChild(g);
    var live=false, raf=0, last=null;
    g.addEventListener('pointerdown', function(e){
      e.preventDefault(); live=true;
      try{ g.setPointerCapture(e.pointerId); }catch(_){}
      send({rz:'start', edge:c, sx:e.screenX, sy:e.screenY});
    });
    g.addEventListener('pointermove', function(e){
      if(!live) return;
      last={sx:e.screenX, sy:e.screenY};
      if(raf) return;
      raf=requestAnimationFrame(function(){ raf=0; if(last) send({rz:'move', sx:last.sx, sy:last.sy}); });
    });
    function end(e){ if(!live) return; live=false; if(raf){cancelAnimationFrame(raf);raf=0;} send({rz:'end'}); }
    g.addEventListener('pointerup', end);
    g.addEventListener('pointercancel', end);
  });

  /* THE START PAGE. The tablet opens on a cover screen with an ENTER TABLET button.
     That is right in a browser and wrong in an overlay - the pilot launched the app,
     they have already "entered". T, exactly: "the run test bat just opened the entire
     tablet start screen in app format. i don't know what's going on."
     window.scCoverGo() is the tablet's own dismiss function (it clears the .hide class
     AND the inline display:none the fade leaves behind), so this uses that rather than
     poking at the element - one code path, no second way to be wrong. */
  function enterTablet(){
    try{
      var c=document.getElementById('cover-screen');
      if(!c) return true;
      /* judge by what is PAINTED, not by the class. Coming back from HUD-only the
         .hide class is still on the cover but the inline display:none has been
         restored away, so a class check said "already dismissed" while the start
         page was on screen. MEASURED: cover computed display 'flex' with .hide set. */
      var cs=getComputedStyle(c);
      if(cs.display==='none') return true;
      if(typeof window.scCoverGo==='function'){ window.scCoverGo(); return true; }
      var b=document.getElementById('cover-enter'); if(b){ b.click(); return true; }
      c.classList.add('hide'); c.style.display='none'; return true;
    }catch(e){ return false; }
  }
  window.__cgOvlEnter=enterTablet;
  enterTablet();
  /* the cover can be re-shown by the tablet's own START PAGE button; only dismiss it
     on the way in, bounded, never on a permanent timer */
  var _n=0, _iv=setInterval(function(){ if(enterTablet()||++_n>25) clearInterval(_iv); }, 300);

  /* UNDOCK MEANS SOMETHING ELSE IN AN APP.
     T: "when i'm using run overlay.bat and then want to pop out the hud via undock,
     undock runs the run hud only .bat. and vice versa?" - yes, that is the right
     design and this is where it is done.

     In a BROWSER, build 430's UNDOCK has to spawn a second window, because a browser
     tab cannot float. In the OVERLAY the window is ALREADY the floating window, so
     spawning another one is pure cost: a second thing to position, a second thing to
     lose. So in here UNDOCK is intercepted and turned into "this window becomes the
     HUD". DOCK / RTB turns it back into the whole tablet. Same window, both ways.

     Captured on the way DOWN (capture:true) so build 430's own listener never runs -
     stopping it after the fact would leave a second window already opening. */
  document.addEventListener('click', function(e){
    var b=e.target && e.target.closest && e.target.closest('.cg-undock-btn,.cg-pop-fdock,.cg-pop-rtb');
    if(!b) return;
    var pop=b.getAttribute && b.getAttribute('data-pop');
    if(pop && pop!=='ops') return;            /* only the HUD - other pills keep their own behaviour */
    e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
    send({act:'hud', want:'toggle'});
  }, true);

  document.addEventListener('keydown', function(e){
    /* the tablet binds Ctrl+Alt+1 to undock. Same substitution, same reason. */
    if(e.ctrlKey && e.altKey && !e.shiftKey && (e.code==='Digit1'||e.key==='1')){
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
      send({act:'hud', want:'toggle'});
    }
  }, true);

  window.__cgOvlHudBtn=function(hudOn){
    var b=document.getElementById('cg-ovl-hudbtn');
    /* v1.2.16 - one label, one job. The button is only rendered in HUD-only now
       (CSS above), and in HUD-only the only thing it can do is dock. It used to
       carry both labels because it used to be shown in both modes. */
    if(b) b.textContent = 'DOCK TABLET';
    /* v1.2.15 - T: "remove the close button and undock button from the hud. the
       only option can be to dock the hud and then close the tablet. for
       shutdown."  There is no quitting from the HUD: dock first, close second.
       The button is not disabled, it is not rendered - a disabled control still
       invites the click. */
    var d=document.getElementById('cg-ovl-drag');
    if(d) d.classList.toggle('cg-hudmode', !!hudOn);
  };

  window.__cgOvlDrag=function(on){
    var d=document.getElementById('cg-ovl-drag'); if(!d) return;
    d.classList.toggle('on', !!on);
    document.body.classList.toggle('cg-ovl-draggable', !!on);
    /* v1.2.5 - T's screenshot 3 AUG 2026: in HUD-only the sweep zeroes body padding
       with inline !important, so the strip sat ON TOP of the tab row and the tabs
       "vanished". The hud itself steps down while the strip is visible. */
    var hud=document.querySelector('.cg-ho-hud');
    if(hud){ if(on){ hud.style.setProperty('margin-top','44px','important'); }
             else { hud.style.removeProperty('margin-top'); } }
  };
  /* v1.2.14 - state, not event: this one has no timer and does not fade. */
  window.__cgOvlCtBadge=function(on){
    var b=document.getElementById('cg-ovl-ctbadge'); if(!b) return;
    b.classList.toggle('on', !!on);
    /* SAME LANE AS THE DRAG STRIP, SO THE SAME 28px STEP. MEASURED on the first
       v1.2.14 render: the badge sat across the HUD's tab row (GATHER & BUY /
       NOTES / CONTRACTS ...) exactly as the strip did before v1.2.5. Stepping the
       HUD down for the badge too also means the HUD no longer JUMPS when
       click-through is toggled - one goes, the other arrives, same height. */
    var hud=document.querySelector('.cg-ho-hud'); if(!hud) return;
    if(on){ hud.style.setProperty('margin-top','44px','important'); }
    else {
      /* only clear it if the strip is not the one holding it - setDragBar(true)
         runs BEFORE setCtBadge(false) on the way out of click-through */
      var d=document.getElementById('cg-ovl-drag');
      if(!d || !d.classList.contains('on')) hud.style.removeProperty('margin-top');
    }
  };
  window.__cgOvlToast=function(msg, warn, ms){
    var t=document.getElementById('cg-ovl-toast'); if(!t) return;
    t.textContent=msg; t.classList.toggle('warn', !!warn); t.classList.add('on');
    clearTimeout(t.__h); t.__h=setTimeout(function(){ t.classList.remove('on'); }, ms||1100);
  };
  window.__cgOvlDim=function(target, pct){
    var id='cg-ovl-dim', st=document.getElementById(id);
    if(!st){ st=document.createElement('style'); st.id=id; document.head.appendChild(st); }
    var o=(pct/100);
    if(target==='hud'){
      st.textContent='#sc-home-widgets .ops-pill.b385{opacity:'+o+' !important}';
    }else if(target==='content'){
      st.textContent='html,body,#content,#tab-home,#tab-home #home-scroll,'
        +'#tab-home .hm-wrap,#tab-home .hm-cols{background:transparent !important;'
        +'background-image:none !important}'
        +'#content{opacity:'+o+' !important}';
    }else{ st.textContent=''; }
  };

  /* COMPACT. The tablet owns the setting (build 693 puts .cg-compact on <html>);
     the overlay only follows it.

     WHAT NOT TO DO, LEARNED BY DOING IT. The first version reported the absolute
     height of the control bar and let main resize to that. It GREW the window from
     900 to 1212 instead of shrinking it, because the tablet scales its home screen
     to fit the window - so the height main was chasing changed every time main
     changed the window, and the two ran away from each other. MEASURED: onebar
     bottom 1210 at 900 px tall, 1386 after the window grew to 1212.

     So the page reports the DELTA instead: how many pixels compact actually
     removes. That number does not depend on the window size, so there is no loop.
     It is measured by forcing the layout both ways inside ONE frame - two reads,
     no paint between them, so nothing flickers on screen. */
  function hiddenPx(){
    var bar=document.getElementById('cg-onebar'); if(!bar) return 0;
    var r=document.documentElement, was=r.classList.contains('cg-compact');
    function bottom(){
      var b=0, ids=['cg-onebar','cg-theme-row536','cg-social-row','cg-affil-note'];
      for(var i=0;i<ids.length;i++){
        var e=document.getElementById(ids[i]);
        if(!e) continue;
        var cs=getComputedStyle(e); if(cs.display==='none') continue;
        b=Math.max(b, e.getBoundingClientRect().bottom);
      }
      return b;
    }
    r.classList.add('cg-compact');    var withCompact=bottom();
    r.classList.remove('cg-compact'); var withFull=bottom();
    if(was) r.classList.add('cg-compact');
    var d=Math.round(withFull-withCompact);
    return (d>0 && d<2000) ? d : 0;
  }
  var lastState=null;
  function report(force){
    var c=document.documentElement.classList.contains('cg-compact');
    if(!force && c===lastState) return;
    lastState=c;
    send({compact:c, hiddenPx:hiddenPx()});
  }
  if(!window.__cgOvlObs){
    window.__cgOvlObs=new MutationObserver(function(){ report(false); });
    window.__cgOvlObs.observe(document.documentElement,{attributes:true,attributeFilter:['class']});
  }
  window.__cgOvlFit=function(){ report(true); };
  /* the home screen finishes laying out after the fonts and the fit pass, so the
     first measurement is taken a moment later - twice, not on a loop */
  setTimeout(function(){ report(true); }, 1500);
  setTimeout(function(){ report(true); }, 6000);
  send({ready:true});
})();
`;

// ---------------------------------------------------------------------------
//  HUD ONLY
//
//  T: "i want app hud only. address bar hud has to go."
//
//  The app used to open the whole tablet and leave the pilot to press Ctrl+Alt+1 to
//  pop the HUD out of it - three steps to reach the one thing he wanted. HUD ONLY
//  opens straight into the floating HUD instead.
//
//  IT DOES NOT USE THE TABLET'S UNDOCK. Build 430's undock spawns a second window
//  (Document PiP, a popup, or an in-page float) which is exactly the machinery that
//  is not wanted here - the overlay window IS already the floating window. So this
//  simply hides everything in the page except the HUD and lets the HUD fill the
//  window. Fewer moving parts, and nothing to fight with build 430's own sweep.
//
//  HOW THE HIDING WORKS, AND WHY IT IS NOT A LIST OF IDs. Marking "hide #topbar,
//  #sc-tools-row, #cg-onebar ..." breaks the first time a block adds a new element.
//  Instead it walks UP from the HUD to <body>, marks every ancestor as KEEP, then
//  hides every child of a KEEP element that is not itself KEEP. Structure-independent:
//  anything added to the home screen later is hidden automatically because it will
//  not be on the path to the HUD.
// ---------------------------------------------------------------------------
const OVL_ROUND_CSS = `
/* v1.2.11 - T: "the tablet outer corners aren't rounded. they have corners squares."
   The window is frameless and transparent; its shape IS whatever the page paints,
   and the tablet paints to the rectangle's edge. clip-path on the root rounds the
   ENTIRE page - including fixed-position layers, which plain border-radius+overflow
   cannot clip. Whole-tablet mode only: the HUD is free-floating glass already. */
html:not(.cg-hudonly){ clip-path: inset(0 round 22px); }
`;

const HUDONLY_CSS = `
/* v1.2.8 - T: "this is already undocked so why is the undocked button showing".
   In the app the intercepted button DOCKS you back, but its label never changed
   for HUD-only. Relabelled here with CSS (stateless - the tablet's own button
   sweep rewrites textContent, it cannot rewrite a pseudo-element). */
html.cg-hudonly .cg-undock-btn{ font-size:0 !important; }
html.cg-hudonly .cg-undock-btn::after{
  content:'DOCK TABLET';
  font:700 9px 'Rajdhani','Segoe UI',sans-serif; letter-spacing:1.1px;
  color:#9fbdd2; text-shadow:0 1px 2px rgba(0,7,14,.9); }
/* THE HIDING IS DONE WITH INLINE STYLES IN HUDONLY_JS, not here - see the note in
   that block. What is left here is only the LOOK, which nothing in the tablet fights
   over, so ordinary rules are enough. */
html.cg-hudonly #cg-rotate-lock,
html.cg-hudonly #sc-spacebg,
html.cg-hudonly #sc-lshape,
html.cg-hudonly #topbar,
html.cg-hudonly #sc-zoom-bar,
html.cg-hudonly #sc-right-bar,
html.cg-hudonly #sc-appbar,
html.cg-hudonly #cg-cmdlog,
html.cg-hudonly #cg-credit,
html.cg-hudonly #cg-affil-note,
html.cg-hudonly #scv-build{ display:none !important; }
/* THE LIGHT BAND, FOUND BY PROBING RATHER THAN GUESSING. body::before is a
   radial-gradient glow and body::after is a repeating-linear-gradient scanline
   field - the tablet's own atmosphere. Inline styles cannot touch a pseudo-element,
   which is why the sweep over every real element left alpha at 232 out of 255.
   MEASURED: elementsFromPoint in the gap returned nothing but transparent elements,
   and the paint was coming from underneath all of them. */
html.cg-hudonly body::before,
html.cg-hudonly body::after,
html.cg-hudonly #sc-spacebg::before,
html.cg-hudonly #sc-spacebg::after,
html.cg-hudonly .hm-wrap::before,
html.cg-hudonly .hm-wrap::after,
/* the pill paints its own gradient through .wg::before - that was the last solid
   thing left inside the HUD after the body atmosphere went. MEASURED: corner alpha
   0, middle alpha 229, so the paint was inside the pill, not behind it. */
html.cg-hudonly .cg-ho-hud::before,
html.cg-hudonly .cg-ho-hud::after,
html.cg-hudonly #sc-home-widgets .cg-ho-hud::before,
html.cg-hudonly #sc-home-widgets .cg-ho-hud::after,
html.cg-hudonly .cg-ho-hud .pill-body::before,
html.cg-hudonly .cg-ho-hud .pill-body::after{
  content: none !important; background: none !important; display: none !important; }
html.cg-hudonly #cover-screen{ display:none !important; }
html.cg-hudonly .cg-ho-hud *{
  text-shadow: 0 0 5px rgba(150,235,255,.9), 0 0 14px rgba(70,180,245,.5) !important; }
html.cg-hudonly .cg-ho-hud .pill-body,
html.cg-hudonly .cg-ho-hud .ops4-body,
html.cg-hudonly .cg-ho-hud .ops4-list,
html.cg-hudonly #sc-home-widgets .cg-ho-hud .pill-body{
  background: transparent !important; background-image: none !important;
  border: 0 !important; box-shadow: none !important; }
html.cg-hudonly .cg-ho-hud .ops4-row{ border-bottom: 0 !important; }
/* a scrollbar is a piece of window furniture and there is no window */
html.cg-hudonly .cg-ho-hud *::-webkit-scrollbar{ width:0 !important; height:0 !important; }
html.cg-hudonly .cg-ho-hud *{ scrollbar-width: none !important; }
/* THE SETTINGS PANEL IS EXEMPT. The sweep strips every background inside the HUD to
   make it a hologram, and it stripped the settings panel too - unreadable over a
   bright scene. A panel you opened deliberately is not part of the projection. */
html.cg-hudonly .cg-ho-hud .cg-hs-panel{
  background: rgba(6,16,26,.93) !important;
  border: 1px solid rgba(120,190,225,.4) !important;
  box-shadow: 0 8px 26px rgba(0,0,0,.65) !important; }
html.cg-hudonly .cg-ho-hud button,
html.cg-hudonly .cg-ho-hud .ops4-tab,
html.cg-hudonly #sc-home-widgets .cg-ho-hud button,
html.cg-hudonly #sc-home-widgets .cg-ho-hud .ops4-tab{
  background: transparent !important; background-image: none !important;
  box-shadow: none !important; color:#a8e6fb !important;
  border: 1px solid rgba(130,225,255,.28) !important; }
html.cg-hudonly .cg-ho-hud .ops4-tab.on,
html.cg-hudonly #sc-home-widgets .cg-ho-hud .ops4-tab.on{
  color:#eaffff !important; border-color: rgba(170,245,255,.8) !important;
  background: rgba(120,220,255,.14) !important; }
html.cg-hudonly .cg-ho-hud .cg-undock-btn,
html.cg-hudonly #sc-home-widgets .cg-ho-hud .cg-undock-btn{ display:none !important; }
/* the drag strip needs its 26 px when it is showing, or it sits on the tab row */
html.cg-hudonly body.cg-ovl-draggable .cg-ho-hud,
html.cg-hudonly body.cg-ovl-draggable #sc-home-widgets .cg-ho-hud{
  margin-top: 44px !important; height: calc(100% - 44px) !important; }
html.cg-hudonly body.cg-ovl-draggable{ padding-top: 0 !important; }
`;

const HUDONLY_JS = `
(function(){
  /* INLINE STYLES, NOT CLASSES - and that is the whole lesson of this file.
     A class rule cannot beat an id rule no matter how many !importants it carries,
     and the tablet is full of them: #sc-home-widgets .wg{display:flex !important}
     (1,1,0) beat html.cg-hudonly .cg-ho-hide (0,2,0) and the widgets stayed on
     screen. An inline !important beats every stylesheet rule there is.
     Everything touched is tagged with data-cgho so it can be put back exactly. */
  var MARK='data-cgho';
  function set(el, prop, val){
    if(!el.hasAttribute(MARK)) el.setAttribute(MARK,'1');
    el.style.setProperty(prop, val, 'important');
  }
  function restore(){
    var base=document.getElementById('cg-ho-base'); if(base) base.remove();
    document.querySelectorAll('['+MARK+']').forEach(function(el){
      ['display','width','height','max-width','max-height','min-height','margin',
       'padding','background','background-image','border','box-shadow','overflow',
       'box-sizing','border-radius','position','inset','transform','flex','zoom',
       'min-width','max-width','background-origin','background-clip',
       'transform-origin','overflow'].forEach(function(p){
        el.style.removeProperty(p);
      });
      el.removeAttribute(MARK);
      if(!el.getAttribute('style')) el.removeAttribute('style');
    });
  }
  function skip(el){
    if(!el || !el.tagName) return true;
    if(el.tagName==='SCRIPT'||el.tagName==='STYLE'||el.tagName==='LINK') return true;
    /* v1.2.14 - the badge joins the drag strip and the toast on this list. The
       sweep below inline-hides every body child that is not on the path to the
       HUD, and on the first build of this badge it did exactly that: badgeOn was
       true and the element carried display:none from the sweep. The one node that
       exists to be seen has to be exempt from the hiding pass. */
    if(el.id==='cg-ovl-drag'||el.id==='cg-ovl-toast'||el.id==='cg-ovl-ctbadge') return true;
    if(el.classList && el.classList.contains('cg-ovl-rz')) return true;
    return false;
  }
  window.__cgHudOnly=function(on){
    restore();
    document.documentElement.classList.toggle('cg-hudonly', !!on);
    /* restore() puts back everything it touched, and the start page was one of them -
       so it has to be dismissed again on the way out, or turning HUD-only off drops
       the pilot back on the cover screen. */
    if(!on){ try{ if(window.__cgOvlEnter) window.__cgOvlEnter(); }catch(e){} return true; }
    var hud=document.querySelector('#sc-home-widgets .ops-pill.b385');
    if(!hud) return false;                       /* page not ready - the caller retries */
    hud.classList.add('cg-ho-hud');

    var node=hud, chain=[];
    while(node && node!==document.body){ chain.push(node); node=node.parentElement; }
    var keep=new Set(chain);

    /* hide every sibling on the path up, and every body child that is not on it */
    chain.forEach(function(el){
      var p=el.parentElement; if(!p) return;
      [].forEach.call(p.children, function(sib){
        if(keep.has(sib)||skip(sib)) return;
        set(sib,'display','none');
      });
    });
    [].forEach.call(document.body.children, function(el){
      if(keep.has(el)||skip(el)) return;
      set(el,'display','none');
    });

    /* the ancestors give up their own box so the HUD can fill the window */
    chain.forEach(function(el){
      if(el===hud) return;
      set(el,'width','100%'); set(el,'height','100%');
      /* max-width:none was wrong - it let the tablet's own min-widths win and the HUD
         laid out at 1700px inside a 940px window. Cap to the window and allow shrink. */
      set(el,'max-width','100%'); set(el,'max-height','100%');
      set(el,'min-width','0'); set(el,'min-height','0');
      set(el,'margin','0'); set(el,'padding','0');
      set(el,'background','transparent'); set(el,'background-image','none');
      set(el,'border','0'); set(el,'box-shadow','none');
      set(el,'overflow','visible'); set(el,'box-sizing','border-box');
      set(el,'transform','none'); set(el,'flex','1 1 auto');
      /* v1.2.1: the tablet's per-tab zoom (.zoom-wrapper, sc_tab_zooms) survived the
         sweep and inflated the layout (MEASURED: 1700 -> 1889px in a 940px window,
         content clipped right - T's screenshot 3 AUG 2026). Ancestors carry no zoom
         in HUD-only; restore() already removes 'zoom'. */
      set(el,'zoom','1');
      /* .hm-cols is a GRID with fixed columns - width:100% on it does not make the one
         surviving child span the row, so the HUD stayed in a narrow left column at
         520px inside a 940px window. Forcing block layout on the ancestors is what
         actually lets the HUD fill. MEASURED before/after. */
      set(el,'display','block');
    });
    ['html','body'].forEach(function(sel){
      var e=document.querySelector(sel); if(!e) return;
      set(e,'background','transparent'); set(e,'background-image','none');
      set(e,'margin','0'); set(e,'padding','0'); set(e,'overflow','hidden');
      set(e,'width','100%'); set(e,'height','100%');
      /* the tablet's FIT pass puts a zoom on <html> (measured 1.456 at 2600px wide).
         Leave it on and "width:100%" resolves against a scaled box - the HUD came out
         2067px wide inside a 940px window. HUD-only sizes itself, so the zoom goes. */
      set(e,'zoom','1');
      /* v1.2.1: min-width BEATS width - the scrail-open classes hold a min-width on
         body, so width:100% !important still measured 1700px in a 940px window.
         Pin the floor and ceiling too; restore() already removes both. */
      set(e,'min-width','0'); set(e,'max-width','100%');
    });

    /* and the HUD itself becomes the window */
    set(hud,'width','100%'); set(hud,'height','100%');
    set(hud,'min-width','0'); set(hud,'max-width','100%');
    set(hud,'min-height','0'); set(hud,'max-height','100%');
    set(hud,'overflow','hidden');
    /* v1.2.5 - replaces the flat zoom pin: scale the HUD's writing WITH the window.
       470px of window height = design size; clamped so a huge monitor gets at most
       1.8x. Layout still fits: everything above is width:100% + min-width:0. */
    var __z=Math.max(1, Math.min(1.8, Math.round(window.innerHeight/470*100)/100));
    set(hud,'zoom',String(__z));
    set(hud,'margin','0'); set(hud,'padding','8px 10px');
    set(hud,'box-sizing','border-box');
    /* THE SLAB. T: "rounded, no triangles, only a smooth tablet that seems to be
       rising out of the screen."

       RISING IS A LIGHT DIRECTION, NOT A SHAPE. A projector sits below and the beam
       weakens as it climbs, so the frame is BRIGHTEST ALONG THE BOTTOM EDGE and fades
       out toward the top, and light pools on the surface underneath it. A uniform
       outline reads as a sticker; a graded one reads as emitted.

       HOW THE GRADED EDGE IS DRAWN. CSS has no gradient border, so this uses the two
       background trick: the first background is clipped to the PADDING box (the
       interior, kept almost clear) and the second to the BORDER box (the ring). The
       ring is a to-top gradient, so the bottom of the frame is full brightness and the
       top is nearly gone.

       It is set INLINE because the sweep above writes background:transparent inline on
       this same element, and a stylesheet rule cannot beat that. */
    /* THE RING IS A PLAIN BORDER NOW.
       The first version used the two-background gradient-border trick (one layer
       clipped to padding-box, one to border-box) so the frame could be brighter at
       the bottom. MEASURED: background-clip did not take through setProperty, so the
       to-top gradient painted the WHOLE panel instead of just the ring - which is the
       cyan wash across the bottom half that T saw twice. A uniform ring cannot fail
       that way, and the "rising" read comes from the emitter below, where it belongs. */
    set(hud,'background','transparent');
    set(hud,'background-image','none');
    /* v1.2.2 - T: "no outlines, not even the line around the entire tablet".
       The ring is gone; the b701 tablet block draws the light. */
    set(hud,'border','0');
    set(hud,'border-radius','26px');
    /* T: "why is the bottom so bright. where is the 3d effect of the tablet rising
       out of the screen."

       THE BRIGHT BAR WAS WRONG AND HERE IS WHY. It was a hard 2px line under the
       whole width - a bar, with ends. A projector does not put a bar under a
       hologram; it puts a POOL, brightest under the middle and gone by the corners.
       So the hard line is deleted and an emitter is drawn instead (below), narrower
       than the slab and elliptical, so it has no ends to be square.

       AND THE 3D. A glow is not depth. Depth is PERSPECTIVE - the top of the slab
       has to be further away than the bottom. rotateX tilts it back a few degrees so
       the top edge recedes, which is what "rising out of the screen" actually looks
       like. 4 degrees is small on purpose: past about 7 the text starts to smear on
       a flat panel. */
    /* NO INSET GLOW. The first attempt put one on the inside bottom edge and it
       washed out the lower HALF of the panel - T: "why is the bottom so bright."
       MEASURED on the render: the wash reached roughly 45% up the slab. A hologram's
       light comes from its own strokes, not from a lamp inside the frame. What is
       left is an outer halo and a pool cast downward, and nothing at all on the
       inside face. */
    set(hud,'box-shadow','none');   /* v1.2.2: no halo either - no shape */
    set(hud,'transform','perspective(1400px) rotateX(4deg)');
    set(hud,'transform-origin','50% 100%');

    /* AND EVERYTHING INSIDE IT. The panels within the HUD paint their own fills from
       id-based rules (#sc-home-widgets .ops-pill.b385 .pill-body{...}) which no class
       rule can beat - MEASURED: alpha 232 out of 255 in the middle of the HUD with
       the stylesheet version of these rules in place. So the sweep is done here, in
       inline styles, on whatever is actually painting.
       The ACTIVE TAB is left alone on purpose: "which tab am I on" has to survive, and
       it is the one filled thing worth keeping. */
    /* NOTE the sweep runs over hud.querySelectorAll('*') - DESCENDANTS only. The HUD
       itself is styled above and is deliberately not in that list, or the slab's own
       gradient edge would be cleared by the very next line. */
    hud.querySelectorAll('*').forEach(function(el){
      if(el.classList && el.classList.contains('ops4-tab') && el.classList.contains('on')) return;
      if(el.closest && el.closest('.cg-hs-panel')) return;   /* the settings panel stays readable */
      if(/^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName)) return; /* v1.2.2: b701 lights these */
      var cs=getComputedStyle(el);
      if(cs.backgroundColor && cs.backgroundColor!=='rgba(0, 0, 0, 0)') set(el,'background','transparent');
      if(cs.backgroundImage && cs.backgroundImage!=='none') set(el,'background-image','none');
      if(cs.boxShadow && cs.boxShadow!=='none') set(el,'box-shadow','none');
    });
    /* v1.2.15 - NO UNDOCK INSIDE THE HUD. T: "remove the close button and undock
       button from the hud."  MEASURED, because there are two of them and only one
       was already handled: button.cg-undock-btn is the v1.2.8 relabelled one and
       is display:none already, but button.cg-mirror.u is a SECOND, mirrored copy
       in the bottom control row - 41x12 at 6px type, the faint UNDOCK in T's
       screenshot. Hidden INLINE, not by stylesheet, because a class rule loses to
       the tablet's own id rules (RULE 18). set() marks it, so restore() puts it
       straight back the moment the tablet docks. */
    hud.querySelectorAll('.cg-mirror.u, .cg-undock-btn').forEach(function(el){
      set(el,'display','none');
    });
    /* THE EMITTER. A real element, not a border or a box-shadow, because both of
       those are rectangles that follow the box - they always have ends. This is an
       ellipse centred under the slab, 46% of its width, fading to nothing well before
       the corners. It is what the slab appears to be rising out of. */
    /* v1.2.2 - variant B approved: NO emitter pool. Remove any old one. */
    var base=document.getElementById('cg-ho-base');
    if(base){ base.remove(); base=null; }
    if(false){
    }
    /* v1.2.14 - THE SWEEP RUNS AFTER THE BADGE, AND IT ZEROES THE HUD'S MARGIN.
       MEASURED on the first v1.2.14 render: the badge was up but the HUD had not
       stepped down, so the amber bar sat across the tab row. The sweep writes
       margin:0 !important inline, which beats everything, so the step has to be
       re-asserted here - at the end of the pass that removed it. The strip has a
       stylesheet rule for the same job; inline is used here because inline is the
       only thing that outlives this sweep. */
    try{
      var _b=document.getElementById('cg-ovl-ctbadge');
      if(_b && _b.classList.contains('on') && window.__cgOvlCtBadge) window.__cgOvlCtBadge(true);
      /* v1.2.15 - the drag strip needs the same re-assert, and for the same
         reason. v1.2.5 gave it a 28px step so it would stop sitting on the tab
         row; the step was being LOST because this sweep writes margin:0 inline
         after __cgOvlDrag ran. MEASURED: strip at y16, GATHER & BUY at y34 -
         18px apart, which is half of what T is looking at when he says the two
         rows run together. Re-asserted here, at the end of the pass that
         removed it, exactly like the badge above. */
      var _d=document.getElementById('cg-ovl-drag');
      if(_d && _d.classList.contains('on') && window.__cgOvlDrag) window.__cgOvlDrag(true);
    }catch(e){}
    return true;
  };
  window.__cgHudOnlyReport=function(){
    var hud=document.querySelector('.cg-ho-hud');
    var r=hud?hud.getBoundingClientRect():null;
    return {on:document.documentElement.classList.contains('cg-hudonly'),
            hudFound:!!hud,
            hudSize:r?Math.round(r.width)+'x'+Math.round(r.height):null,
            hudTop:r?Math.round(r.top):null,
            touched:document.querySelectorAll('['+MARK+']').length,
            visibleWidgets:(function(){var n=0;
              document.querySelectorAll('#sc-home-widgets .wg').forEach(function(w){
                if(getComputedStyle(w).display!=='none') n++; }); return n;})(),
            cover:(function(){var c=document.getElementById('cover-screen');
              return c?getComputedStyle(c).display:'gone';})()};
  };
})();
`;

function applyHudOnly() {
  if (!win) return;
  win.webContents.executeJavaScript(HUDONLY_JS).then(() =>
    win.webContents.executeJavaScript('window.__cgHudOnly(' + (cfg.hudOnly ? 'true' : 'false') + ')')
  ).then(ok => {
    if (!ok && cfg.hudOnly) {
      // the home screen builds itself over a couple of seconds; retry, bounded
      let n = 0;
      const iv = setInterval(() => {
        if (!win || ++n > 30) return clearInterval(iv);
        win.webContents.executeJavaScript('window.__cgHudOnly(true)')
          .then(r => { if (r) clearInterval(iv); }).catch(() => {});
      }, 400);
    }
  }).catch(() => {});
}

function setHudOnly(on) {
  cfg.hudOnly = !!on;
  saveConfig();
  // each mode remembers its own window size - a HUD-sized window must not become
  // the size the whole tablet reopens at
  const b = win ? win.getBounds() : null;
  if (b) { if (on) sizeState.full = b; else sizeState.hud = b; }
  applyHudOnly();
  if (win) win.webContents.executeJavaScript(
    'window.__cgOvlHudBtn && window.__cgOvlHudBtn(' + (on ? 'true' : 'false') + ')').catch(() => {});
  /* v1.2.10 - T: "when you go to full tablet its size is incorrect - it spawns in
     the same size the user left the hud on." A --hud launch never captures a
     full-tablet size, so docking had nothing to restore and kept the HUD bounds.
     The tablet now falls back to its own launch geometry: centred, up to
     1400x900, inside the work area. Minimum size follows the mode too. */
  let want = on ? sizeState.hud : sizeState.full;
  if (!on && !want) {
    const wa = screen.getDisplayMatching(win.getBounds()).workArea;
    const w = Math.min(1400, wa.width - 80), h = Math.min(900, wa.height - 80);
    want = { x: wa.x + Math.round((wa.width - w) / 2),
             y: wa.y + Math.round((wa.height - h) / 2), width: w, height: h };
  }
  if (win) win.setMinimumSize(on ? 720 : 900, on ? 260 : 400);
  if (want) setBounds(want, on ? 'hudonly-size' : 'fulltablet-size');
  toast(on ? 'HUD ONLY' : 'WHOLE TABLET', false, 1400);
}

function inject() {
  if (!win) return;
  win.webContents.insertCSS(OVL_CSS).catch(() => {});
  win.webContents.insertCSS(HUDONLY_CSS).catch(() => {});   /* gated on html.cg-hudonly - inert until the class is set */
  win.webContents.insertCSS(OVL_ROUND_CSS).catch(() => {});  /* v1.2.11 rounded tablet corners */
  win.webContents.executeJavaScript(OVL_JS).then(() => {
    applyHudOnly();
    win.webContents.executeJavaScript(
      'window.__cgOvlHudBtn && window.__cgOvlHudBtn(' + (cfg.hudOnly ? 'true' : 'false') + ')').catch(() => {});
    applyDim(false);
    setDragBar(!clickThrough);
    setCtBadge(clickThrough);   /* v1.2.14 - correct on the FIRST paint, not only after a toggle */
    if (cfg.__urlFromArg) toast('TEST BUILD  ·  ' + cfg.url.split('/').pop(), true, 4000);
    /* v1.2.4 put a 6-second toast here. v1.2.14 replaces it with the badge above:
       MEASURED on the first v1.2.14 render - both fired at once and stacked two
       amber bars saying the same sentence, and the toast's copy was the weaker of
       the two. A state does not need an announcement as well as a sign. */
    if (startupReport.length) {
      toast(startupReport.join('   ·   '), true, 7000);
      startupReport = [];
    }
  }).catch(() => {});
}
function toast(msg, warn, ms) {
  if (!win) return;
  win.webContents.executeJavaScript(
    'window.__cgOvlToast && window.__cgOvlToast(' + JSON.stringify(String(msg)) + ',' +
    (warn ? 'true' : 'false') + ',' + (ms || 1100) + ')').catch(() => {});
}
function setDragBar(on) {
  if (!win || !cfg.showDragBar) return;
  win.webContents.executeJavaScript('window.__cgOvlDrag && window.__cgOvlDrag(' + (on ? 'true' : 'false') + ')').catch(() => {});
}

// ---------------------------------------------------------------------------
//  dimmer
// ---------------------------------------------------------------------------
function applyDim(announce) {
  if (!win) return;
  const pct = cfg.dimLevel;
  if (cfg.dimTarget === 'window') {
    win.setOpacity(pct / 100);
    win.webContents.executeJavaScript("window.__cgOvlDim && window.__cgOvlDim('window',100)").catch(() => {});
  } else {
    win.setOpacity(1);
    win.webContents.executeJavaScript(
      "window.__cgOvlDim && window.__cgOvlDim('" + cfg.dimTarget + "'," + pct + ")").catch(() => {});
  }
  if (announce) {
    const name = { window: 'WHOLE WINDOW', content: 'WHOLE TABLET', hud: 'HUD ONLY' }[cfg.dimTarget];
    toast(pct + '%  ·  ' + name);
  }
}
function setDim(pct) { if (STEPS.indexOf(pct) < 0) return; cfg.dimLevel = pct; saveConfig(); applyDim(true); }
function cycleDim() { setDim(STEPS[(STEPS.indexOf(cfg.dimLevel) + 1) % STEPS.length]); }

function setClickThrough(on) {
  clickThrough = !!on;
  if (!win) return;
  win.setIgnoreMouseEvents(clickThrough, { forward: true });
  setDragBar(!clickThrough);
  setCtBadge(clickThrough);      /* v1.2.14 - the state gets a permanent tell */
}
/* v1.2.14 - separate from toast() on purpose: a toast is an event with a timer,
   this is a condition that stays on screen until it stops being true. */
function setCtBadge(on) {
  if (!win) return;
  win.webContents.executeJavaScript(
    'window.__cgOvlCtBadge && window.__cgOvlCtBadge(' + (on ? 'true' : 'false') + ')').catch(() => {});
}

// ---------------------------------------------------------------------------
//  COMPACT -> window shrinks to fit.  T: "once hidden close the tablet in around
//  the new size".  fullBounds is remembered so FULL restores exactly what it was,
//  not a guess.
// ---------------------------------------------------------------------------
function onCompactReport(compact, hiddenPx) {
  if (!win) return;
  if (compact === compactNow) return;              // only the TRANSITION acts, never a repeat
  const b = win.getBounds();
  if (compact) {
    compactNow = true;
    if (!cfg.shrinkOnCompact) return;
    const d = Math.max(0, Math.round(hiddenPx || 0));
    if (!d) { console.log('BOUNDS compact-on: nothing to remove, window unchanged'); return; }
    fullBounds = b;
    setBounds({ x: b.x, y: b.y, width: b.width, height: Math.max(cfg.minHeight, b.height - d) }, 'compact-shrink -' + d);
  } else {
    compactNow = false;
    if (!cfg.shrinkOnCompact) return;
    // a page that LOADED compact has no remembered full size - grow by the delta
    if (!fullBounds) fullBounds = { x: b.x, y: b.y, width: b.width, height: b.height + Math.max(0, Math.round(hiddenPx || 0)) };
    setBounds(fullBounds, 'compact-restore');
  }
}
function maximise() {
  if (!win) return;
  const wa = screen.getDisplayMatching(win.getBounds()).workArea;
  const b = win.getBounds();
  const isFull = Math.abs(b.width - wa.width) < 6 && Math.abs(b.height - wa.height) < 6;
  if (isFull && fullBounds) { setBounds(fullBounds, 'max-restore'); toast('RESTORED'); }
  else { fullBounds = b; setBounds({ x: wa.x, y: wa.y, width: wa.width, height: wa.height }, 'maximise'); toast('FULL SCREEN'); }
}

// ---------------------------------------------------------------------------
//  corner resize.  The page sends absolute SCREEN coordinates; main works out the
//  delta from the anchor it took on pointerdown. Doing it from deltas the page
//  computes would drift, because the window moves under the cursor as it resizes.
// ---------------------------------------------------------------------------
function onResize(msg) {
  if (!win) return;
  if (msg.rz === 'start') { rzAnchor = { edge: msg.edge, sx: msg.sx, sy: msg.sy, b: win.getBounds() }; return; }
  if (msg.rz === 'end') { rzAnchor = null; if (!compactNow) fullBounds = win.getBounds(); saveState(); return; }
  if (msg.rz !== 'move' || !rzAnchor) return;
  const dx = msg.sx - rzAnchor.sx, dy = msg.sy - rzAnchor.sy, o = rzAnchor.b, e = rzAnchor.edge;
  const MINW = cfg.minWidth, MINH = cfg.minHeight;
  let x = o.x, y = o.y, w = o.width, h = o.height;
  if (e === 'se') { w = o.width + dx; h = o.height + dy; }
  else if (e === 'sw') { w = o.width - dx; h = o.height + dy; x = o.x + dx; }
  else if (e === 'ne') { w = o.width + dx; h = o.height - dy; y = o.y + dy; }
  else if (e === 'nw') { w = o.width - dx; h = o.height - dy; x = o.x + dx; y = o.y + dy; }
  if (w < MINW) { if (e === 'sw' || e === 'nw') x = o.x + (o.width - MINW); w = MINW; }
  if (h < MINH) { if (e === 'ne' || e === 'nw') y = o.y + (o.height - MINH); h = MINH; }
  setBounds({ x: x, y: y, width: w, height: h }, 'resize-' + e);
}

// ---------------------------------------------------------------------------
//  the window
// ---------------------------------------------------------------------------
function createWindow() {
  const disp = screen.getPrimaryDisplay().workAreaSize;
  const saved = loadState();
  win = new BrowserWindow({
    transparent: true, frame: false, alwaysOnTop: true,
    backgroundColor: '#00000000', hasShadow: false, skipTaskbar: false, resizable: true,
    minWidth: cfg.minWidth, minHeight: cfg.minHeight,
    /* MEASURED: the HUD lays out at about 866 x 308 at default zoom, so the HUD-only
       window opens landscape to fit it. Opening it portrait produced nothing but the
       tablet's ROTATE TO LANDSCAPE card. */
    /* v1.2.7 - T's HUD had been dragged to 320px wide and that width was restored
       on every launch: six tab labels cannot fit, so GATHER & BUY wrapped and
       STREAM was clipped. A saved width is CLAMPED to a readable floor now, and
       the window carries a real minimum below (setMinimumSize). */
    width:  Math.max(cfg.hudOnly ? 720 : 900,
              cfg.hudOnly ? (saved && saved.hudW ? saved.hudW : 940)
                          : (saved ? saved.width  : Math.min(1400, disp.width  - 80))),
    height: Math.max(cfg.hudOnly ? 260 : 400,
              cfg.hudOnly ? (saved && saved.hudH ? saved.hudH : 440)
                          : (saved ? saved.height : Math.min(900,  disp.height - 80))),
    x: saved ? saved.x : undefined,
    y: saved ? saved.y : undefined,
    webPreferences: { contextIsolation: true, nodeIntegration: false, backgroundThrottling: false }
  });
  fullBounds = win.getBounds();
  win.setAlwaysOnTop(true, 'screen-saver');
  win.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });

  /* A pilot whose control server is not running should still get a working tablet.
     If the configured URL fails, fall through to the published one and SAY SO -
     silently loading a different build than the one asked for would be worse than
     an error page. */
  const loadWithFallback = (u, isFallback) => win.loadURL(u).then(() => {
    if (isFallback) {
      startupReport.push('COULD NOT REACH ' + cfg.url + '  -  loaded ' + cfg.fallbackUrl + ' instead');
    }
  }).catch(err => {
    if (!isFallback && cfg.fallbackUrl && cfg.fallbackUrl !== u) {
      console.error('primary URL failed (' + u + '), trying ' + cfg.fallbackUrl);
      return loadWithFallback(cfg.fallbackUrl, true);
    }
    throw err;
  });
  loadWithFallback(cfg.url, false).catch(err => {
    const msg = String((err && err.message) || err).replace(/</g, '&lt;');
    win.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(
      '<body style="margin:0;background:#0b1017;color:#cfe2f1;font:14px/1.6 Segoe UI,sans-serif;padding:26px">' +
      '<h2 style="color:#8fd8ff;letter-spacing:2px">CMDGLAS OVERLAY - CANNOT REACH THE TABLET</h2>' +
      '<p>Tried: <b>' + cfg.url + '</b></p><p>' + msg + '</p>' +
      '<p>Start the control server, then press <b>' + KM.pretty(cfg.hotkeys.reload) + '</b>.</p></body>'));
  });

  // one channel back from the page - no preload, no node integration in the tablet
  win.webContents.on('console-message', (_e, _lvl, message) => {
    const i = message.indexOf('CGOVL§');
    if (i < 0) return;
    let m; try { m = JSON.parse(message.slice(i + 6)); } catch (_) { return; }
    if (m.rz) return onResize(m);
    if (m.act === 'max') return maximise();
    if (m.act === 'fit') { win.webContents.executeJavaScript('window.__cgOvlFit && window.__cgOvlFit()').catch(() => {}); return; }
    if (m.act === 'settings') return openSettings();
    if (m.act === 'close') { try { saveState(); } catch (_) {} app.quit(); return; }   /* v1.2.3 */
    if (m.act === 'hud') return setHudOnly(m.want === 'toggle' ? !cfg.hudOnly : !!m.want);
    if (typeof m.compact === 'boolean') return onCompactReport(m.compact, m.hiddenPx);
  });

  win.webContents.on('did-finish-load', () => { compactNow = false; inject(); });
  /* v1.2.4 - T clicked UNDOCK on launch, click-through was ON, the click went
     THROUGH to the Explorer window behind and Windows opened keymap.js with WSH
     (his screenshot, 3 AUG 2026). WHOLE-TABLET launches now start INTERACTIVE -
     you launched a tablet, you mean to touch it. HUD-only keeps the config value:
     that is the in-flight mode, click-through is its point. */
  win.setMinimumSize(cfg.hudOnly ? 720 : 900, cfg.hudOnly ? 260 : 400);  /* v1.2.7 */
  setClickThrough(cfg.hudOnly ? cfg.clickThroughOnStart : false);
  win.on('resized', () => { if (!compactNow && !rzAnchor) fullBounds = win.getBounds(); });
  /* v1.2.9 - MEASURED: after ANY window resize the tablet's own fit logic re-writes
     the ancestor widths the HUD-only sweep had pinned (inline vs inline - last
     write wins), and the tab row lays out at ~2x the window: STREAM/THREAT walked
     off-screen in T's screenshot. The sweep is idempotent, so it simply re-runs
     after each resize settles. */
  let __rzT = null;
  win.on('resize', () => {
    if (!cfg.hudOnly) return;
    clearTimeout(__rzT);
    __rzT = setTimeout(() => { if (win && cfg.hudOnly) applyHudOnly(); }, 250);
  });
  win.on('close', saveState);
  win.on('closed', () => { win = null; });
}

// ---------------------------------------------------------------------------
//  hotkeys
// ---------------------------------------------------------------------------
/* v1.2.13 - T: "i can't actually make hotkeys for my streamdeck since it's
   connected to the game. you made me some url's before".
   Keystrokes go to the focused window - the game. URLs do not. This is the same
   doctrine as the 8421 HUD bridge: a loopback-only HTTP listener, one endpoint
   per action, driveable by anything that can open a URL. 127.0.0.1 ONLY -
   nothing outside this PC can reach it. Port 8422 (8420 server, 8421 bridge). */
const http = require('http');
function startControlServer() {
  const ACT = {
    ping:        () => 'ok',
    hud:         () => { setHudOnly(true);  return 'hud'; },
    tablet:      () => { setHudOnly(false); return 'tablet'; },
    toggle:      () => { setHudOnly(!cfg.hudOnly); return cfg.hudOnly ? 'hud' : 'tablet'; },
    hide:        () => { if (win) win.hide(); return 'hidden'; },
    show:        () => { if (win) { win.show(); } return 'shown'; },
    visible:     () => { if (win) (win.isVisible() ? win.hide() : win.show()); return 'toggled'; },
    clickthrough:() => { setClickThrough(!clickThrough); return clickThrough ? 'on' : 'off'; },
    dim25:       () => { setDim(25);  return '25'; },
    dim50:       () => { setDim(50);  return '50'; },
    dim75:       () => { setDim(75);  return '75'; },
    dim100:      () => { setDim(100); return '100'; },
    dimcycle:    () => { cycleDim(); return 'cycled'; },
    reload:      () => { if (win) win.loadURL(cfg.url); return 'reloading'; }
  };
  const srv = http.createServer((req, res) => {
    const name = (req.url || '/').replace(/^\/+/, '').split('?')[0].toLowerCase();
    const fn = ACT[name];
    res.setHeader('content-type', 'application/json');
    if (!fn) { res.statusCode = 404; res.end(JSON.stringify({ ok: false, know: Object.keys(ACT) })); return; }
    let out; try { out = fn(); } catch (e) { res.statusCode = 500; res.end(JSON.stringify({ ok: false, err: String(e).slice(0, 120) })); return; }
    res.end(JSON.stringify({ ok: true, did: name, state: out }));
  });
  srv.on('error', () => {});           /* port taken (second instance) - stay silent */
  srv.listen(8422, '127.0.0.1');
}

function actionFns() {
  return {
    toggleClickThrough: () => setClickThrough(!clickThrough),
    toggleVisible:      () => { if (win) (win.isVisible() ? win.hide() : win.show()); },
    reload:             () => { if (win) win.loadURL(cfg.url); },
    settings:           () => openSettings(),
    dimCycle:           () => cycleDim(),
    dim25:              () => setDim(25),
    dim50:              () => setDim(50),
    dim75:              () => setDim(75),
    dim100:             () => setDim(100),
    toggleHudOnly:      () => setHudOnly(!cfg.hudOnly)
  };
}

/** Register everything, and REPORT what failed instead of whispering to a console. */
function registerHotkeys() {
  globalShortcut.unregisterAll();
  const fns = actionFns();
  const bad = [];
  for (const action of Object.keys(fns)) {
    const combo = cfg.hotkeys[action];
    if (!combo) continue;
    if (!KM.isRegistrableKey(combo)) { bad.push(labelOf(action) + ': "' + combo + '" is not a key Electron accepts'); continue; }
    let ok = false;
    try { ok = globalShortcut.register(combo, fns[action]); } catch (e) { ok = false; }
    if (!ok) bad.push(labelOf(action) + ': ' + KM.pretty(combo) + ' is already taken');
  }
  const clash = [];
  if (scBinds.ok) {
    for (const action of Object.keys(fns)) {
      const c = KM.canon(cfg.hotkeys[action], false);
      const hit = c && scBinds.index.get(c);
      if (hit && hit.length) clash.push(labelOf(action) + ': ' + KM.pretty(cfg.hotkeys[action]) + ' = ' + hit[0].action);
    }
  }
  startupReport = [];
  if (bad.length)   startupReport.push('HOTKEY PROBLEM  ' + bad.join(' | ') + '  -  open HOTKEYS on the drag strip');
  if (clash.length) startupReport.push('CLASHES WITH STAR CITIZEN  ' + clash.join(' | '));
  bad.forEach(b => console.error('HOTKEY: ' + b));
  clash.forEach(c => console.error('SC CLASH: ' + c));
  return { bad, clash };
}
function labelOf(a) { return (ACTION_LABELS[a] && ACTION_LABELS[a][0]) || a; }

// ---------------------------------------------------------------------------
//  the hotkey editor window
// ---------------------------------------------------------------------------
function openSettings() {
  if (setWin && !setWin.isDestroyed()) { setWin.show(); setWin.focus(); return; }
  setWin = new BrowserWindow({
    width: 900, height: 760, title: 'CmdGlas Overlay - Hotkeys',
    backgroundColor: '#0b1017', autoHideMenuBar: true, alwaysOnTop: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload-settings.js'),
      contextIsolation: true, nodeIntegration: false
    }
  });
  setWin.loadFile(path.join(__dirname, 'settings.html'));
  setWin.on('closed', () => { setWin = null; });
}

ipcMain.handle('cg:getState', () => ({
  hotkeys: JSON.parse(JSON.stringify(cfg.hotkeys)),
  labels: ACTION_LABELS,
  order: Object.keys(ACTION_LABELS),
  sc: { ok: scBinds.ok, path: scBinds.path, count: scBinds.count || 0,
        skipped: scBinds.skipped || 0, generated: scBinds.generated || null,
        source: scBinds.source || null, error: scBinds.error || null },
  cfg: { url: cfg.url, dimTarget: cfg.dimTarget, shrinkOnCompact: cfg.shrinkOnCompact,
         clickThroughOnStart: cfg.clickThroughOnStart, showDragBar: cfg.showDragBar }
}));

ipcMain.handle('cg:check', (_e, { combo, action, draft }) => {
  return KM.checkCombo(combo, {
    selfMap: draft || cfg.hotkeys, selfAction: action, scIndex: scBinds,
    tryRegister: (c) => {
      // A combination the overlay itself already holds would look "taken" by the
      // overlay. Drop everything, test, then put it all back.
      try {
        globalShortcut.unregisterAll();
        let ok = false;
        try { ok = globalShortcut.register(c, () => {}); } catch (_) { ok = false; }
        if (ok) globalShortcut.unregister(c);
        return ok;
      } finally { registerHotkeys(); }
    }
  });
});

ipcMain.handle('cg:save', (_e, { hotkeys, options }) => {
  const before = JSON.parse(JSON.stringify(cfg.hotkeys));
  cfg.hotkeys = Object.assign({}, cfg.hotkeys, hotkeys || {});
  if (options && typeof options.shrinkOnCompact === 'boolean') cfg.shrinkOnCompact = options.shrinkOnCompact;
  if (options && ['window', 'content', 'hud'].indexOf(options.dimTarget) >= 0) cfg.dimTarget = options.dimTarget;
  const saved = saveConfig();
  if (!saved) { cfg.hotkeys = before; registerHotkeys(); return { ok: false, error: 'could not write overlay.config.json' }; }
  const r = registerHotkeys();
  applyDim(false);
  toast('HOTKEYS SAVED', false, 1600);
  return { ok: true, bad: r.bad, clash: r.clash };
});

ipcMain.handle('cg:reveal', () => { try { shell.showItemInFolder(CONFIG_FILE); } catch (_) {} });

// ---------------------------------------------------------------------------
app.whenReady().then(() => {
  startControlServer();   /* v1.2.13 - Stream Deck URL control on 127.0.0.1:8422 */
  cfg = loadConfig();
  scBinds = findScBinds();
  console.log(scBinds.ok
    ? ('keybind export: ' + scBinds.path + '  (' + scBinds.count + ' keyboard binds, ' + scBinds.skipped + ' mouse/wheel skipped)')
    : ('NO keybind export found - the Star Citizen conflict check is UNAVAILABLE, which is not the same as "no conflicts". ' + (scBinds.error || '')));
  createWindow();
  registerHotkeys();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('will-quit', () => globalShortcut.unregisterAll());
app.on('window-all-closed', () => app.quit());
