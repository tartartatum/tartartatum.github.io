// =============================================================================
//  keymap.js  -  CmdGlas Overlay v1.2
//
//  ONE canonical form for two different key languages, so "does this collide"
//  is a comparison and not an opinion.
//
//    Star Citizen writes    lctrl+ralt+1     (it knows left from right)
//    Electron writes        Control+Alt+1    (it does not, and neither does
//                                             Windows RegisterHotKey)
//
//  Because a Windows global hotkey fires on EITHER Control, lctrl+ralt+1 and
//  Control+Alt+1 are the same key press. That is exactly the collision T hit -
//  the overlay stole a weapon-group key mid-flight. So both sides are reduced to
//      sorted-modifiers | key
//  with left/right folded together, and compared as strings.
//
//  MEASURED against T's own export (MASTER_KEYBINDS.json, 716 binds):
//    6 modifier tokens   lctrl rctrl lalt ralt lshift rshift
//    87 key tokens       listed in SC2E below plus the plain letters and digits
//    383 distinct keyboard combos after folding
//    12 mouse / wheel binds, which cannot be global shortcuts and are skipped
//
//  CAUTION. The export is the ONLY thing that can be read. Star Citizen's default
//  binds live inside Data.p4k and are not readable, so if a pilot has never
//  exported their keybinds this file has nothing to check against. That case
//  reports "cannot check" - it never reports "free".
// =============================================================================
'use strict';

const MODMAP = {
  lctrl: 'ctrl', rctrl: 'ctrl', ctrl: 'ctrl', control: 'ctrl', commandorcontrol: 'ctrl',
  lalt: 'alt', ralt: 'alt', alt: 'alt', option: 'alt', altgr: 'alt',
  lshift: 'shift', rshift: 'shift', shift: 'shift',
  cmd: 'meta', command: 'meta', super: 'meta', meta: 'meta'
};

// Star Citizen token -> Electron accelerator key
const SC2E = {
  apostrophe: "'", backslash: '\\', comma: ',', equals: '=', lbracket: '[', rbracket: ']',
  minus: '-', period: '.', semicolon: ';', slash: '/', grave: '`', tilde: '`',
  pgdn: 'pagedown', pgup: 'pageup', esc: 'escape',
  np_add: 'numadd', np_subtract: 'numsub', np_multiply: 'nummult', np_divide: 'numdiv',
  np_period: 'numdec', np_enter: 'enter',
  np_0: 'num0', np_1: 'num1', np_2: 'num2', np_3: 'num3', np_4: 'num4',
  np_5: 'num5', np_6: 'num6', np_7: 'num7', np_8: 'num8', np_9: 'num9'
};
const E2E = { plus: '+', return: 'enter', esc: 'escape' };

// Every key Electron will actually accept in an accelerator. Anything outside this
// list registers as nothing at all and fails SILENTLY, which is how
// "Control+Shift+numenter" sat dead in T's config - numenter does not exist.
const VALID = new Set([
  ...'abcdefghijklmnopqrstuvwxyz0123456789'.split(''),
  'plus', 'space', 'tab', 'capslock', 'numlock', 'scrolllock', 'backspace', 'delete',
  'insert', 'enter', 'up', 'down', 'left', 'right', 'home', 'end', 'pageup', 'pagedown',
  'escape', 'printscreen', 'volumeup', 'volumedown', 'volumemute',
  'medianexttrack', 'mediaprevioustrack', 'mediastop', 'mediaplaypause',
  'numdec', 'numadd', 'numsub', 'nummult', 'numdiv',
  '`', '-', '=', '[', ']', '\\', ';', "'", ',', '.', '/',
  ...Array.from({ length: 24 }, (_, i) => 'f' + (i + 1)),
  ...Array.from({ length: 10 }, (_, i) => 'num' + i)
]);

/** Reduce either language to  "alt+ctrl+shift|key"  (modifiers sorted, lowercase). */
function canon(combo, isStarCitizen) {
  if (!combo) return null;
  let mods = new Set(), key = null;
  for (const raw of String(combo).split('+')) {
    const p = raw.trim().toLowerCase();
    if (!p) continue;
    if (MODMAP[p]) { mods.add(MODMAP[p]); continue; }
    key = isStarCitizen ? (SC2E[p] || p) : (E2E[p] || p);
  }
  if (!key) return null;
  return Array.from(mods).sort().join('+') + '|' + key;
}

function keyOf(combo, isSC) { const c = canon(combo, isSC); return c ? c.split('|')[1] : null; }
function isRegistrableKey(combo) { const k = keyOf(combo, false); return !!k && VALID.has(k); }

/** Pretty label for the UI, e.g. "Control+Shift+num8" -> "Ctrl + Shift + Num 8". */
function pretty(combo) {
  if (!combo) return '(not set)';
  return String(combo).split('+').map(p => {
    const t = p.trim();
    const l = t.toLowerCase();
    if (l === 'control' || l === 'ctrl') return 'Ctrl';
    if (l === 'commandorcontrol') return 'Ctrl';
    if (l === 'alt') return 'Alt';
    if (l === 'shift') return 'Shift';
    if (/^num\d$/.test(l)) return 'Num ' + l.slice(3);
    if (l === 'numdiv') return 'Num /';
    if (l === 'nummult') return 'Num *';
    if (l === 'numsub') return 'Num -';
    if (l === 'numadd') return 'Num +';
    if (l === 'numdec') return 'Num .';
    if (l === 'pagedown') return 'Page Down';
    if (l === 'pageup') return 'Page Up';
    if (/^f\d+$/.test(l)) return t.toUpperCase();
    if (l === '`') return '` (backtick)';
    return t.length === 1 ? t.toUpperCase() : (t[0].toUpperCase() + t.slice(1));
  }).join(' + ');
}

/**
 * Build the lookup from a MASTER_KEYBINDS.json.
 * Returns { ok, path, count, generated, source, index } - index maps canon -> [binds].
 * ok:false means the file was missing or unreadable. It NEVER means "no conflicts".
 */
function loadStarCitizenBinds(fs, filePath) {
  const out = { ok: false, path: filePath, count: 0, skipped: 0, generated: null, source: null, index: new Map(), error: null };
  try {
    const raw = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    const binds = raw.all_keyboard_binds;
    if (!binds || typeof binds !== 'object') throw new Error('all_keyboard_binds missing');
    out.generated = raw.generated || null;
    out.source = raw.source_export || null;
    for (const action of Object.keys(binds)) {
      const v = binds[action] || {};
      const k = String(v.key || '').trim().toLowerCase();
      if (!k) continue;
      if (k.indexOf('mouse') >= 0 || k.indexOf('mwheel') >= 0) { out.skipped++; continue; }
      const c = canon(k, true);
      if (!c) continue;
      if (!out.index.has(c)) out.index.set(c, []);
      out.index.get(c).push({ action, actionmap: v.actionmap || '', key: k });
      out.count++;
    }
    out.ok = true;
  } catch (e) { out.error = e.message; }
  return out;
}

/**
 * The whole verdict for one combo, in one object. Nothing is merged: each check
 * reports separately, so a PASS on one never dresses up a FAIL on another.
 */
function checkCombo(combo, opts) {
  opts = opts || {};
  const res = {
    combo, pretty: pretty(combo),
    validKey: isRegistrableKey(combo),
    hasModifier: /(?:^|\+)\s*(control|ctrl|alt|shift|super|meta|cmd|command|commandorcontrol|option)\s*(?:\+)/i.test(combo || ''),
    scChecked: false, scConflicts: [],
    selfConflict: null,
    osFree: null,
    status: 'UNKNOWN', detail: ''
  };
  const c = canon(combo, false);

  if (opts.selfMap && c) {
    for (const [action, other] of Object.entries(opts.selfMap)) {
      if (action === opts.selfAction) continue;
      if (canon(other, false) === c) { res.selfConflict = action; break; }
    }
  }
  if (opts.scIndex && opts.scIndex.ok && c) {
    res.scChecked = true;
    res.scConflicts = opts.scIndex.index.get(c) || [];
  }
  if (typeof opts.tryRegister === 'function' && res.validKey) {
    res.osFree = opts.tryRegister(combo);
  }

  if (!res.validKey) { res.status = 'INVALID'; res.detail = 'Electron will not accept that key, so the hotkey would do nothing at all.'; }
  else if (!res.hasModifier) { res.status = 'INVALID'; res.detail = 'A global hotkey needs at least one of Ctrl, Alt or Shift, or it would fire while you type.'; }
  else if (res.selfConflict) { res.status = 'IN USE'; res.detail = 'Already used by the CmdGlas action "' + res.selfConflict + '".'; }
  else if (res.scConflicts.length) {
    const f = res.scConflicts[0];
    res.status = 'SC CONFLICT';
    res.detail = res.scConflicts.length + ' Star Citizen bind' + (res.scConflicts.length > 1 ? 's' : '')
      + ' use this, starting with ' + f.action + ' (' + f.actionmap + ', bound as ' + f.key + ').';
  } else if (res.osFree === false) { res.status = 'TAKEN'; res.detail = 'Windows or another running program already owns this combination.'; }
  else if (!res.scChecked) { res.status = 'NOT CHECKED'; res.detail = 'No keybind export found, so the game side could not be checked. This is not the same as free.'; }
  else { res.status = 'FREE'; res.detail = 'Valid, not used by another CmdGlas action, and not in your Star Citizen export.'; }
  return res;
}

module.exports = { canon, pretty, isRegistrableKey, VALID, loadStarCitizenBinds, checkCombo };
