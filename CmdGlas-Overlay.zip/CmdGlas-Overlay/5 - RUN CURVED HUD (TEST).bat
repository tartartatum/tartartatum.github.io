@echo off
REM ===========================================================================
REM  CmdGlas Overlay  -  CURVED HUD (TEST)          added 11 AUG 2026
REM
REM  Same overlay app as "1 - RUN OVERLAY.bat", pointed at the curved HUD
REM  instead of the tablet:
REM        http://localhost:8421/CmdGlas_HUD_Curved.html
REM
REM  The URL is passed on the COMMAND LINE, so it is never written into
REM  overlay.config.json - main.js deletes a --url= value before saving
REM  (see saveConfig: "a test URL must never become the saved one"). Your
REM  normal launchers are untouched by running this.
REM
REM  DO NOT pass --hud here. --hud is the tablet's HUD-ONLY mode: it adds the
REM  cg-hudonly class to CmdGlas_PERSONAL.html and hides everything except the
REM  old in-page HUD. The curved HUD is already only a HUD - there is nothing
REM  for that mode to hide, and the class would do nothing.
REM
REM  Stream Deck SD 1-13 (port 8422) work against this window exactly as they
REM  do against the tablet - they act on the WINDOW, not on the page.
REM
REM  CAUTION: Star Citizen must be in BORDERLESS WINDOWED. Nothing can draw
REM  over a true exclusive-fullscreen game.
REM ===========================================================================
cd /d "%~dp0"

if not exist "node_modules\electron\dist\electron.exe" (
  echo.
  echo   Electron is not installed yet.  Run "0 - FIRST TIME SETUP.bat" once.
  echo.
  pause
  exit /b 1
)

REM The curved HUD is served by the PERSONAL server on 8421, same as the tablet.
REM A dead server here means a black window and no error, so check first.
netstat -ano | findstr ":8421" | findstr LISTENING >nul 2>&1
if errorlevel 1 (
  echo.
  echo   PERSONAL server not running on 8421.
  echo   Run "My Own Tablet\Start Tablet\1 - START SERVER.bat" first.
  echo.
  pause
  exit /b 1
)

echo Starting CmdGlas Overlay  -  CURVED HUD ...
start "" "node_modules\electron\dist\electron.exe" . --url=http://localhost:8421/CmdGlas_HUD_Curved.html
exit /b 0
