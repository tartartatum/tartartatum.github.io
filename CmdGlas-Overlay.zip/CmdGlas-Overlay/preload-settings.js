// =============================================================================
//  preload-settings.js  -  CmdGlas Overlay v1.2
//
//  The settings page runs with contextIsolation ON and no node integration. This
//  is the ONLY thing it can reach, and every one of these is a request to main -
//  the page cannot touch the filesystem, spawn anything, or read anything else.
//  Four functions is the whole surface.
// =============================================================================
'use strict';
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('cg', {
  getState: ()                          => ipcRenderer.invoke('cg:getState'),
  check:    (combo, action, draft)      => ipcRenderer.invoke('cg:check', { combo, action, draft }),
  save:     (hotkeys, options)          => ipcRenderer.invoke('cg:save', { hotkeys, options }),
  reveal:   ()                          => ipcRenderer.invoke('cg:reveal')
});
