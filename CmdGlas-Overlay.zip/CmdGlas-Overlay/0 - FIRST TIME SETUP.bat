@echo off
title CmdGlas Overlay - first time setup
color 0B
cd /d "%~dp0"
echo ============================================================
echo    CMDGLAS OVERLAY - FIRST TIME SETUP
echo    Downloads Electron into this folder. Run this ONCE.
echo ============================================================
echo.
where npm >nul 2>&1
if errorlevel 1 (
  echo  *** npm was not found on this PC.
  echo  *** Install Node.js from https://nodejs.org  then run this again.
  echo.
  pause
  exit /b 1
)
echo  Installing Electron. This downloads about 100 MB and takes a minute.
echo.
call npm install
if errorlevel 1 (
  echo.
  echo  *** INSTALL FAILED. Read the error above.
  echo  *** Nothing was changed anywhere else on this PC.
  pause
  exit /b 1
)
echo.
echo  Done. Start the overlay with "1 - RUN OVERLAY.bat".
echo.
pause
