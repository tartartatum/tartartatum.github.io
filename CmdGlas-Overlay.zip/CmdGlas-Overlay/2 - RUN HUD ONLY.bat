@echo off
REM ===========================================================================
REM  CmdGlas Overlay  -  HUD ONLY
REM
REM  Opens STRAIGHT INTO the floating HUD. No tablet, no undock step.
REM  Press Ctrl+Alt+Shift+H at any time to bring the whole tablet up, and again
REM  to go back to the HUD.
REM
REM  --hud is passed on the command line, so it is never written into
REM  overlay.config.json - the other launchers are unaffected.
REM ===========================================================================
cd /d "%~dp0"
if not exist "node_modules\electron\dist\electron.exe" (
  echo.
  echo   Electron is not installed yet.
  echo   Run "0 - FIRST TIME SETUP.bat" once, then try again.
  echo.
  pause
  exit /b 1
)
echo Starting CmdGlas HUD ...
start "" "node_modules\electron\dist\electron.exe" . --hud
exit /b 0
